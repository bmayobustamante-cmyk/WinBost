﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace WinBoost
{
    // ------------------------------------------------------------------
    // Estadisticas de tiempos de fotograma
    // ------------------------------------------------------------------

    internal sealed class FrameStats
    {
        public int Frames;
        public double DurationSec;
        public double AvgFps;
        public double Low1Fps;    // 1000 / media de los tiempos del 1 % de fotogramas más lentos
        public double AvgMs;
        public double P99Ms;      // percentil 99 del tiempo de fotograma (método del rango más cercano)
        public double MaxMs;
        public double MinMs;

        public static FrameStats Compute(IList<double> frameTimesMs)
        {
            List<double> v = new List<double>();
            for (int i = 0; i < frameTimesMs.Count; i++)
            {
                double x = frameTimesMs[i];
                if (double.IsNaN(x) || double.IsInfinity(x) || x <= 0) continue;
                v.Add(x);
            }
            if (v.Count == 0) return null;
            FrameStats s = new FrameStats();
            double sum = 0;
            for (int i = 0; i < v.Count; i++) sum += v[i];
            s.Frames = v.Count;
            s.DurationSec = sum / 1000.0;
            s.AvgMs = sum / v.Count;
            s.AvgFps = v.Count / s.DurationSec;
            List<double> asc = new List<double>(v);
            asc.Sort();
            s.MinMs = asc[0];
            s.MaxMs = asc[asc.Count - 1];
            int rank = (int)Math.Ceiling(0.99 * asc.Count) - 1;
            if (rank < 0) rank = 0;
            if (rank >= asc.Count) rank = asc.Count - 1;
            s.P99Ms = asc[rank];
            int worst = Math.Max(1, (int)Math.Ceiling(asc.Count * 0.01));
            double wsum = 0;
            for (int i = 0; i < worst; i++) wsum += asc[asc.Count - 1 - i];
            s.Low1Fps = 1000.0 / (wsum / worst);
            return s;
        }

        public Dictionary<string, double> ToMetrics()
        {
            Dictionary<string, double> m = new Dictionary<string, double>();
            m["avgFps"] = AvgFps;
            m["low1Fps"] = Low1Fps;
            m["avgMs"] = AvgMs;
            m["p99Ms"] = P99Ms;
            m["maxMs"] = MaxMs;
            m["frames"] = Frames;
            m["durationSec"] = DurationSec;
            return m;
        }
    }

    // ------------------------------------------------------------------
    // Importacion de datos de herramientas externas (PresentMon, CapFrameX, listas de ms)
    // ------------------------------------------------------------------

    internal sealed class ImportResult
    {
        public List<double> Frames = new List<double>();
        public string Game = "";
        public List<string> Notes = new List<string>();
        public string Error;
        public int Discarded;
    }

    internal static class FrameImporter
    {
        private static readonly string[] TimeColumns = new string[]
        {
            "msbetweenpresents", "frametimems", "frametime(ms)", "frametime", "msbetweenpresent"
        };

        private static readonly string[] GameColumns = new string[]
        {
            "application", "applicationname", "processname", "process", "game", "exe"
        };

        private static string Norm(string h)
        {
            if (h == null) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < h.Length; i++)
            {
                char c = h[i];
                if (c == '"' || c == ' ' || c == '_' || c == '\t' || c == '\r') continue;
                sb.Append(char.ToLowerInvariant(c));
            }
            return sb.ToString();
        }

        private static List<string> SplitCsv(string line, char delim)
        {
            List<string> r = new List<string>();
            StringBuilder cur = new StringBuilder();
            bool q = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"') { q = !q; continue; }
                if (c == delim && !q) { r.Add(cur.ToString()); cur.Length = 0; continue; }
                cur.Append(c);
            }
            r.Add(cur.ToString());
            return r;
        }

        private static bool TryNum(string s, char delim, out double v)
        {
            s = (s ?? "").Trim();
            if (delim != ',') s = s.Replace(',', '.');
            return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v);
        }

        private static char Detect(string line)
        {
            int c = 0, sc = 0, t = 0;
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == ',') c++;
                else if (line[i] == ';') sc++;
                else if (line[i] == '\t') t++;
            }
            if (sc > c && sc >= t) return ';';
            if (t > c && t > sc) return '\t';
            return ',';
        }

        private static string ShortName(string g)
        {
            g = (g ?? "").Trim();
            int i = Math.Max(g.LastIndexOf('\\'), g.LastIndexOf('/'));
            if (i >= 0) g = g.Substring(i + 1);
            return g;
        }

        public static ImportResult Parse(string text)
        {
            ImportResult r = new ImportResult();
            if (string.IsNullOrEmpty(text)) { r.Error = "El archivo está vacío."; return r; }
            string[] raw = text.Replace("\r", "").Split('\n');
            List<string> lines = new List<string>();
            for (int i = 0; i < raw.Length; i++) if (raw[i].Trim().Length > 0) lines.Add(raw[i]);
            if (lines.Count == 0) { r.Error = "El archivo está vacío."; return r; }

            // 1) Lista simple: un numero (ms) por línea.
            bool plain = true;
            int probe = Math.Min(lines.Count, 20);
            for (int i = 0; i < probe; i++)
            {
                double dv;
                if (!TryNum(lines[i], ';', out dv)) { plain = false; break; }
            }
            if (plain)
            {
                for (int i = 0; i < lines.Count; i++)
                {
                    double dv;
                    if (TryNum(lines[i], ';', out dv) && dv > 0) r.Frames.Add(dv); else r.Discarded++;
                }
                r.Notes.Add("Se interpretó como lista simple de tiempos de fotograma en milisegundos.");
                Sanity(r);
                return r;
            }

            // 2) CSV con cabecera: se busca la primera línea que contenga una columna de tiempo conocida.
            int headerIdx = -1; char delim = ','; int timeIdx = -1; int gameIdx = -1;
            int scan = Math.Min(lines.Count, 40);
            for (int i = 0; i < scan && headerIdx < 0; i++)
            {
                char d = Detect(lines[i]);
                List<string> cols = SplitCsv(lines[i], d);
                int found = -1;
                for (int k = 0; k < TimeColumns.Length && found < 0; k++)
                {
                    for (int c = 0; c < cols.Count; c++)
                    {
                        if (Norm(cols[c]) == TimeColumns[k]) { found = c; break; }
                    }
                }
                if (found >= 0)
                {
                    headerIdx = i; delim = d; timeIdx = found;
                    for (int k = 0; k < GameColumns.Length && gameIdx < 0; k++)
                    {
                        for (int c = 0; c < cols.Count; c++)
                        {
                            if (Norm(cols[c]) == GameColumns[k]) { gameIdx = c; break; }
                        }
                    }
                }
            }
            if (headerIdx < 0)
            {
                r.Error = "No se encontró una columna de tiempos de fotograma. Se esperaba MsBetweenPresents o FrameTime (PresentMon, CapFrameX) " +
                    "o una lista de milisegundos, un valor por línea.";
                return r;
            }

            List<string> apps = new List<string>();
            List<double> times = new List<double>();
            for (int i = headerIdx + 1; i < lines.Count; i++)
            {
                List<string> f = SplitCsv(lines[i], delim);
                if (f.Count <= timeIdx) { r.Discarded++; continue; }
                double v;
                if (!TryNum(f[timeIdx], delim, out v) || v <= 0) { r.Discarded++; continue; }
                times.Add(v);
                apps.Add(gameIdx >= 0 && f.Count > gameIdx ? ShortName(f[gameIdx]) : "");
            }

            if (gameIdx >= 0)
            {
                Dictionary<string, int> count = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < apps.Count; i++)
                {
                    int n; count.TryGetValue(apps[i], out n); count[apps[i]] = n + 1;
                }
                string best = ""; int bestN = 0;
                foreach (KeyValuePair<string, int> kv in count) if (kv.Value > bestN) { best = kv.Key; bestN = kv.Value; }
                if (count.Count > 1)
                {
                    r.Notes.Add("El archivo contenía " + count.Count + " aplicaciones. Se usó solo \"" + best + "\" (la que tiene más fotogramas). Para evitar ambigüedad, captura únicamente el juego.");
                    for (int i = 0; i < times.Count; i++)
                    {
                        if (string.Equals(apps[i], best, StringComparison.OrdinalIgnoreCase)) r.Frames.Add(times[i]);
                        else r.Discarded++;
                    }
                }
                else r.Frames.AddRange(times);
                r.Game = best;
            }
            else
            {
                r.Frames.AddRange(times);
                r.Notes.Add("El archivo no indica el juego; escribelo a mano.");
            }
            Sanity(r);
            return r;
        }

        private static void Sanity(ImportResult r)
        {
            if (r.Frames.Count == 0) { r.Error = "No se pudo leer ningún tiempo de fotograma válido."; return; }
            List<double> s = new List<double>(r.Frames);
            s.Sort();
            double median = s[s.Count / 2];
            if (median < 0.5)
                r.Notes.Add("Atención: los valores son muy pequeños (mediana " + median.ToString("0.###", CultureInfo.InvariantCulture) + "). Se asume milisegundos; si el archivo está en segundos, las cifras no serán válidas.");
            if (median > 200)
                r.Notes.Add("Atención: los tiempos son muy grandes (mediana " + median.ToString("0", CultureInfo.InvariantCulture) + " ms). Comprueba que la columna sea de tiempo de fotograma.");
            if (r.Discarded > 0)
                r.Notes.Add("Se descartaron " + r.Discarded + " filas no válidas o de otras aplicaciones.");
        }

        // Reduce a n puntos conservando los picos (maximo por tramo), para dibujar la gráfica.
        public static double[] DownsampleMax(IList<double> v, int n)
        {
            if (v.Count <= n)
            {
                double[] all = new double[v.Count];
                for (int i = 0; i < v.Count; i++) all[i] = v[i];
                return all;
            }
            double[] o = new double[n];
            for (int i = 0; i < n; i++)
            {
                int a = (int)((long)i * v.Count / n);
                int b = (int)((long)(i + 1) * v.Count / n);
                if (b <= a) b = a + 1;
                double mx = 0;
                for (int k = a; k < b && k < v.Count; k++) if (v[k] > mx) mx = v[k];
                o[i] = mx;
            }
            return o;
        }
    }

    // ------------------------------------------------------------------
    // Almacen de mediciones
    // ------------------------------------------------------------------

    internal sealed class BenchRecord
    {
        public string Id;
        public DateTime Created;
        public string Name;
        public string Kind;        // "fps" | "sistema"
        public string Game = "";
        public string Resolution = "";
        public string Settings = "";
        public string Notes = "";
        public string Source = "";
        public Dictionary<string, double> M = new Dictionary<string, double>();
        public double[] Frames;    // submuestreo para la gráfica (solo "fps")

        public bool Has(string key) { return M.ContainsKey(key); }
        public double Get(string key) { double v; return M.TryGetValue(key, out v) ? v : double.NaN; }
    }

    internal static class BenchStore
    {
        private static readonly object Sync = new object();

        public static string FilePath
        {
            get { return Path.Combine(AppSettings.Folder, "mediciones.tsv"); }
        }

        public static string FormatMetrics(Dictionary<string, double> m)
        {
            StringBuilder sb = new StringBuilder();
            foreach (KeyValuePair<string, double> kv in m)
            {
                if (sb.Length > 0) sb.Append(';');
                sb.Append(kv.Key).Append('=').Append(kv.Value.ToString("R", CultureInfo.InvariantCulture));
            }
            return sb.ToString();
        }

        public static Dictionary<string, double> ParseMetrics(string s)
        {
            Dictionary<string, double> m = new Dictionary<string, double>();
            if (string.IsNullOrEmpty(s)) return m;
            string[] parts = s.Split(';');
            for (int i = 0; i < parts.Length; i++)
            {
                int eq = parts[i].IndexOf('=');
                if (eq <= 0) continue;
                double v;
                if (double.TryParse(parts[i].Substring(eq + 1), NumberStyles.Float, CultureInfo.InvariantCulture, out v))
                    m[parts[i].Substring(0, eq)] = v;
            }
            return m;
        }

        private static string FormatFrames(double[] f)
        {
            if (f == null || f.Length == 0) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < f.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(f[i].ToString("0.##", CultureInfo.InvariantCulture));
            }
            return sb.ToString();
        }

        private static double[] ParseFrames(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            string[] p = s.Split(',');
            List<double> l = new List<double>();
            for (int i = 0; i < p.Length; i++)
            {
                double v;
                if (double.TryParse(p[i], NumberStyles.Float, CultureInfo.InvariantCulture, out v)) l.Add(v);
            }
            return l.ToArray();
        }

        public static List<BenchRecord> Load()
        {
            List<BenchRecord> list = new List<BenchRecord>();
            lock (Sync)
            {
                try
                {
                    if (!File.Exists(FilePath)) return list;
                    string[] lines = File.ReadAllLines(FilePath, Encoding.UTF8);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (lines[i].Length == 0) continue;
                        string[] f = Tsv.Split(lines[i]);
                        if (f.Length < 11) continue;
                        BenchRecord r = new BenchRecord();
                        r.Id = f[0];
                        DateTime t;
                        DateTime.TryParseExact(f[1], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out t);
                        r.Created = t;
                        r.Name = f[2]; r.Kind = f[3]; r.Game = f[4]; r.Resolution = f[5];
                        r.Settings = f[6]; r.Notes = f[7]; r.Source = f[8];
                        r.M = ParseMetrics(f[9]);
                        r.Frames = ParseFrames(f[10]);
                        list.Add(r);
                    }
                }
                catch
                {
                }
            }
            return list;
        }

        private static void SaveAll(List<BenchRecord> list)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < list.Count; i++)
            {
                BenchRecord r = list[i];
                sb.Append(Tsv.Line(r.Id, r.Created.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    r.Name, r.Kind, r.Game, r.Resolution, r.Settings, r.Notes, r.Source,
                    FormatMetrics(r.M), FormatFrames(r.Frames)));
                sb.Append('\n');
            }
            Tsv.WriteAllTextSafe(FilePath, sb.ToString());
        }

        public static void Add(BenchRecord r)
        {
            lock (Sync)
            {
                if (string.IsNullOrEmpty(r.Id)) r.Id = Guid.NewGuid().ToString("N").Substring(0, 12);
                if (r.Created == DateTime.MinValue) r.Created = DateTime.Now;
                List<BenchRecord> all = Load();
                all.Add(r);
                SaveAll(all);
            }
        }

        public static void Remove(string id)
        {
            lock (Sync)
            {
                List<BenchRecord> all = Load();
                all.RemoveAll(delegate(BenchRecord r) { return r.Id == id; });
                SaveAll(all);
            }
        }

        public static BenchRecord FromFrames(string name, ImportResult imp, string game, string resolution, string settings, string notes, string source)
        {
            FrameStats st = FrameStats.Compute(imp.Frames);
            if (st == null) return null;
            BenchRecord r = new BenchRecord();
            r.Name = name; r.Kind = "fps"; r.Game = game ?? ""; r.Resolution = resolution ?? "";
            r.Settings = settings ?? ""; r.Notes = notes ?? ""; r.Source = source ?? "";
            r.M = st.ToMetrics();
            r.Frames = FrameImporter.DownsampleMax(imp.Frames, 1000);
            return r;
        }
    }

    // ------------------------------------------------------------------
    // Muestra del sistema (CPU / RAM durante N segundos)
    // ------------------------------------------------------------------

    internal sealed class SystemSession
    {
        private double cpuSum, cpuMax, ramPctSum;
        private double ramUsedSum;
        private int cpuN, ramN;
        public DateTime Started = DateTime.Now;

        public void Add(double cpuPct, long ramUsed, long ramTotal)
        {
            if (cpuPct >= 0) { cpuSum += cpuPct; cpuN++; if (cpuPct > cpuMax) cpuMax = cpuPct; }
            if (ramTotal > 0)
            {
                ramPctSum += ramUsed * 100.0 / ramTotal;
                ramUsedSum += ramUsed;
                ramN++;
            }
        }

        public int Samples { get { return Math.Max(cpuN, ramN); } }

        public BenchRecord ToRecord(string name, string notes)
        {
            if (Samples == 0) return null;
            BenchRecord r = new BenchRecord();
            r.Name = name; r.Kind = "sistema"; r.Notes = notes ?? "";
            r.Source = "WinBoost (contadores de Windows)";
            if (cpuN > 0) { r.M["cpuAvg"] = cpuSum / cpuN; r.M["cpuMax"] = cpuMax; }
            if (ramN > 0) { r.M["ramAvgPct"] = ramPctSum / ramN; r.M["ramAvgGb"] = ramUsedSum / ramN / 1073741824.0; }
            r.M["samples"] = Samples;
            r.M["durationSec"] = (DateTime.Now - Started).TotalSeconds;
            return r;
        }
    }

    // ------------------------------------------------------------------
    // Comparacion antes / después
    // ------------------------------------------------------------------

    internal sealed class CompareRow
    {
        public string Metric;
        public string Before;
        public string After;
        public string Delta;
        public string Verdict;
        public string Tone;   // ok / bad / muted
    }

    internal static class BenchCompare
    {
        private sealed class Def
        {
            public string Key, Label, Unit;
            public int Dir;          // +1 más alto es mejor, -1 más bajo es mejor, 0 neutro
            public bool Relative;    // umbral de ruido relativo (%) o absoluto
            public double Noise;
            public string Fmt;
            public Def(string k, string l, string u, int d, bool rel, double noise, string fmt)
            { Key = k; Label = l; Unit = u; Dir = d; Relative = rel; Noise = noise; Fmt = fmt; }
        }

        private static readonly Def[] FpsDefs = new Def[]
        {
            new Def("avgFps", "FPS medios", "FPS", +1, true, 3, "0.0"),
            new Def("low1Fps", "FPS 1 % low", "FPS", +1, true, 3, "0.0"),
            new Def("avgMs", "Tiempo de fotograma medio", "ms", -1, true, 3, "0.00"),
            new Def("p99Ms", "Tiempo de fotograma P99", "ms", -1, true, 3, "0.00"),
            new Def("maxMs", "Fotograma más lento", "ms", -1, true, 3, "0.0"),
            new Def("durationSec", "Duración de la prueba", "s", 0, true, 0, "0.0"),
            new Def("frames", "Fotogramas analizados", "", 0, true, 0, "0")
        };

        private static readonly Def[] SysDefs = new Def[]
        {
            new Def("cpuAvg", "CPU media", "%", -1, false, 2, "0.0"),
            new Def("cpuMax", "CPU maxima", "%", -1, false, 2, "0.0"),
            new Def("ramAvgPct", "RAM usada (media)", "%", -1, false, 2, "0.0"),
            new Def("ramAvgGb", "RAM usada (media)", "GB", -1, true, 3, "0.00"),
            new Def("durationSec", "Duración de la muestra", "s", 0, true, 0, "0"),
            new Def("samples", "Muestras", "", 0, true, 0, "0")
        };

        public static List<CompareRow> Compare(BenchRecord a, BenchRecord b, List<string> warnings)
        {
            List<CompareRow> rows = new List<CompareRow>();
            if (a.Kind != b.Kind)
            {
                warnings.Add("Las dos mediciones son de tipos distintos (FPS y sistema); no se pueden comparar.");
                return rows;
            }
            Def[] defs = a.Kind == "fps" ? FpsDefs : SysDefs;
            for (int i = 0; i < defs.Length; i++)
            {
                Def d = defs[i];
                if (!a.Has(d.Key) || !b.Has(d.Key)) continue;
                double x = a.Get(d.Key), y = b.Get(d.Key);
                CompareRow r = new CompareRow();
                r.Metric = d.Label + (d.Unit.Length > 0 ? " (" + d.Unit + ")" : "");
                r.Before = x.ToString(d.Fmt, CultureInfo.InvariantCulture);
                r.After = y.ToString(d.Fmt, CultureInfo.InvariantCulture);
                double diff = y - x;
                double pct = x != 0 ? diff / Math.Abs(x) * 100.0 : 0;
                r.Delta = (diff >= 0 ? "+" : "") + diff.ToString(d.Fmt, CultureInfo.InvariantCulture)
                    + (d.Relative && x != 0 ? "  (" + (pct >= 0 ? "+" : "") + pct.ToString("0.0", CultureInfo.InvariantCulture) + " %)" : "");
                if (d.Dir == 0) { r.Verdict = ""; r.Tone = "muted"; }
                else
                {
                    double size = d.Relative ? Math.Abs(pct) : Math.Abs(diff);
                    if (size < d.Noise) { r.Verdict = "Sin diferencia concluyente"; r.Tone = "muted"; }
                    else
                    {
                        bool better = (diff * d.Dir) > 0;
                        r.Verdict = better ? "Mejor" : "Peor";
                        r.Tone = better ? "ok" : "bad";
                    }
                }
                rows.Add(r);
            }

            if (a.Id == b.Id) warnings.Add("Has elegido la misma medición como ANTES y como DESPUES.");
            if (a.Kind == "fps")
            {
                if (!string.IsNullOrEmpty(a.Game) && !string.IsNullOrEmpty(b.Game) &&
                    !string.Equals(a.Game, b.Game, StringComparison.OrdinalIgnoreCase))
                    warnings.Add("Los juegos son distintos (" + a.Game + " / " + b.Game + "): la comparación no es valida.");
                if (!string.IsNullOrEmpty(a.Resolution) && !string.IsNullOrEmpty(b.Resolution) &&
                    !string.Equals(a.Resolution, b.Resolution, StringComparison.OrdinalIgnoreCase))
                    warnings.Add("Las resoluciones indicadas son distintas.");
                if (!string.IsNullOrEmpty(a.Settings) && !string.IsNullOrEmpty(b.Settings) &&
                    !string.Equals(a.Settings.Trim(), b.Settings.Trim(), StringComparison.OrdinalIgnoreCase))
                    warnings.Add("Los ajustes gráficos anotados son distintos.");
                if (a.Get("frames") < 1000 || b.Get("frames") < 1000)
                    warnings.Add("Alguna prueba tiene menos de 1000 fotogramas: el 1 % low se basa en muy pocos fotogramas y es poco fiable.");
            }
            double da = a.Get("durationSec"), db = b.Get("durationSec");
            if (!double.IsNaN(da) && !double.IsNaN(db) && da > 0 && db > 0 && Math.Max(da, db) / Math.Min(da, db) > 1.5)
                warnings.Add("La duración de las dos pruebas difiere mucho; usa la misma escena y duración.");
            warnings.Add("Una sola prueba por configuración no demuestra una mejora: repite cada prueba varias veces con la misma escena. Las diferencias pequeñas pueden ser variación normal.");
            return rows;
        }
    }
}
