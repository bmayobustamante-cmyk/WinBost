@echo off
cd /d "%~dp0"
if not exist WinBoost.exe call build.bat
if not exist WinBoost.exe exit /b 1
start "" WinBoost.exe
