﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace WinBoost
{
    // ------------------------------------------------------------------
    // Monitor del sistema
    // ------------------------------------------------------------------

    internal sealed class MonitorPanel : Panel
    {
        private Panel header;
        private Label title;
        private Label subtitle;
        private TextBox details;
        private Panel detailsHost;
        private Label procTitle;
        private ListView procs;
        private string lastText = "";

        public MonitorPanel()
        {
            Ui.EnableDoubleBuffer(this);
            procs = Skin.NewList();
            procs.Dock = DockStyle.Fill;
            procs.Columns.Add("Proceso", 210);
            procs.Columns.Add("PID", 70);
            procs.Columns.Add("CPU", 80);
            procs.Columns.Add("RAM", 110);
            procs.Columns.Add("Tipo", 170);

            procTitle = Skin.Lbl("Procesos que más consumen (solo informativo: WinBoost no cierra procesos por consumir recursos)", 10f, true, "");
            procTitle.Dock = DockStyle.Top;
            procTitle.Height = 30;
            procTitle.Padding = new Padding(16, 6, 0, 0);

            details = new TextBox();
            details.Multiline = true;
            details.ReadOnly = true;
            details.ScrollBars = ScrollBars.Vertical;
            details.BorderStyle = BorderStyle.None;
            details.Dock = DockStyle.Fill;
            details.Font = new Font("Segoe UI", 9.5f);
            detailsHost = new Panel();
            detailsHost.Dock = DockStyle.Top;
            detailsHost.Height = 230;
            detailsHost.Padding = new Padding(16, 10, 16, 10);
            detailsHost.Tag = "card";
            detailsHost.Controls.Add(details);

            header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 78;
            header.Tag = "card";
            title = Skin.Lbl("Monitor del sistema", 20f, true, "");
            title.SetBounds(20, 10, 500, 36);
            subtitle = Skin.Lbl("Valores leídos de Windows cada pocos segundos. Lo que no se puede medir aparece como «No disponible»; nunca se estima ni se inventa.", 9.5f, false, "muted");
            subtitle.SetBounds(22, 48, 800, 22);
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Resize += delegate
            {
                subtitle.Width = Math.Max(300, header.Width - 40);
                subtitle.Height = Skin.FitHeight(subtitle, subtitle.Width);
                header.Height = Math.Max(78, subtitle.Bottom + 8);
            };

            Controls.Add(procs);
            Controls.Add(procTitle);
            Controls.Add(detailsHost);
            Controls.Add(header);
            procs.Resize += delegate
            {
                int used = procs.Columns[0].Width + procs.Columns[1].Width + procs.Columns[2].Width + procs.Columns[3].Width;
                procs.Columns[4].Width = Math.Max(120, procs.ClientSize.Width - used - 4);
            };
            details.Text = "Esperando la primera lectura…";
            ApplyTheme();
        }

        public void ApplyTheme()
        {
            Skin.Apply(this);
            BackColor = AppSettings.Current.Bg;
            details.BackColor = AppSettings.Current.Card;
            details.ForeColor = AppSettings.Current.Fg;
        }

        public void OnMetrics(Metrics m)
        {
            if (m == null) return;
            StringBuilder sb = new StringBuilder();
            string cpu = m.Cpu >= 0 ? m.Cpu.ToString("0.0", CultureInfo.CurrentCulture) + " %" : "No disponible";
            sb.Append("CPU: ").Append(string.IsNullOrEmpty(m.CpuName) ? "(modelo no disponible)" : m.CpuName);
            if (m.LogicalCores > 0) sb.Append("  ·  ").Append(m.LogicalCores).Append(" hilos");
            sb.Append("  ·  uso ").Append(cpu).Append("\r\n");

            if (m.RamTotal > 0)
                sb.Append("RAM: ").Append(Fmt.Gb(m.RamUsed)).Append(" GB usados de ").Append(Fmt.Gb(m.RamTotal))
                  .Append(" GB (").Append(m.RamLoad).Append(" %)  ·  disponible: ").Append(Fmt.Gb(m.RamTotal - m.RamUsed)).Append(" GB\r\n");
            else sb.Append("RAM: No disponible\r\n");

            if (m.Gpus.Count == 0)
            {
                sb.Append("GPU: No disponible. ").Append(m.GpuNote ?? "No se detectó ninguna GPU.").Append("\r\n");
            }
            else
            {
                for (int i = 0; i < m.Gpus.Count; i++)
                {
                    sb.Append("GPU ").Append(i + 1).Append(": ").Append(m.Gpus[i].Name);
                    if (!string.IsNullOrEmpty(m.Gpus[i].Driver)) sb.Append("  (controlador ").Append(m.Gpus[i].Driver).Append(")");
                    sb.Append("\r\n");
                }
                if (m.GpuLoad3d >= 0) sb.Append("Carga 3D de la GPU: ").Append(m.GpuLoad3d.ToString("0", CultureInfo.CurrentCulture)).Append(" %\r\n");
                else sb.Append("Carga de la GPU: No disponible. ").Append(m.GpuNote ?? "").Append("\r\n");
            }
            for (int i = 0; i < m.Nvidia.Count; i++)
            {
                NvSample n = m.Nvidia[i];
                sb.Append("NVIDIA (nvidia-smi) ").Append(n.Name).Append(": temperatura ")
                  .Append(n.TempC >= 0 ? n.TempC.ToString("0", CultureInfo.CurrentCulture) + " °C" : "No disponible")
                  .Append("  ·  uso ").Append(n.UtilPct >= 0 ? n.UtilPct.ToString("0", CultureInfo.CurrentCulture) + " %" : "No disponible");
                if (n.MemUsedMb >= 0 && n.MemTotalMb > 0)
                    sb.Append("  ·  VRAM ").Append(n.MemUsedMb.ToString("0", CultureInfo.CurrentCulture)).Append(" / ")
                      .Append(n.MemTotalMb.ToString("0", CultureInfo.CurrentCulture)).Append(" MB");
                sb.Append("\r\n");
            }
            if (!string.IsNullOrEmpty(m.TempNote)) sb.Append("Temperatura: ").Append(m.TempNote).Append("\r\n");
            sb.Append("Modo juego: ").Append(GameModeService.IsActive ? "ACTIVO (" + ChangeStore.Count + " cambios aplicados)" : "inactivo").Append("\r\n");
            if (m.Errors.Count > 0)
            {
                sb.Append("\r\nLecturas con problemas:\r\n");
                for (int i = 0; i < m.Errors.Count; i++) sb.Append("  • ").Append(m.Errors[i]).Append("\r\n");
            }
            string text = sb.ToString();
            if (text != lastText)
            {
                lastText = text;
                details.Text = text;
                details.Select(0, 0);
            }

            procs.BeginUpdate();
            procs.Items.Clear();
            for (int i = 0; i < m.Top.Count; i++)
            {
                ProcSample p = m.Top[i];
                Skin.AddRow(procs, new string[]
                {
                    p.Name, p.Pid.ToString(CultureInfo.InvariantCulture),
                    p.Cpu >= 0 ? p.Cpu.ToString("0.0", CultureInfo.CurrentCulture) + " %" : "—",
                    Fmt.Bytes(p.Memory), p.KindLabel ?? ""
                }, new object[] { "", "muted", "", "", p.KindColor });
            }
            procs.EndUpdate();
        }
    }

    // ------------------------------------------------------------------
    // Cierre OPCIONAL de aplicaciones (siempre con confirmacion expresa)
    // ------------------------------------------------------------------

    internal sealed class AppsPanel : Panel
    {
        private Panel header;
        private Label title;
        private Label subtitle;
        private Panel bar;
        private Button scanBtn;
        private Button closeBtn;
        private Label info;
        private Panel listHost;
        private ListView results;
        private List<CheckBox> boxes = new List<CheckBox>();
        private bool busy;

        public AppsPanel()
        {
            Ui.EnableDoubleBuffer(this);
            results = Skin.NewList();
            results.Dock = DockStyle.Bottom;
            results.Height = 150;
            results.Columns.Add("Resultado", 130);
            results.Columns.Add("Aplicación", 420);
            results.Columns.Add("Detalle", 420);

            listHost = new Panel();
            listHost.Dock = DockStyle.Fill;
            listHost.AutoScroll = true;
            listHost.Tag = "card";

            bar = new Panel();
            bar.Dock = DockStyle.Top;
            bar.Height = 56;
            scanBtn = Skin.Btn("Buscar aplicaciones abiertas", false);
            scanBtn.SetBounds(16, 8, 240, 40);
            closeBtn = Skin.Btn("Cerrar las marcadas…", true);
            closeBtn.SetBounds(268, 8, 220, 40);
            closeBtn.Enabled = false;
            info = Skin.Lbl("", 9.5f, false, "muted");
            info.SetBounds(500, 18, 400, 24);
            bar.Controls.Add(scanBtn);
            bar.Controls.Add(closeBtn);
            bar.Controls.Add(info);

            header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 100;
            header.Tag = "card";
            title = Skin.Lbl("Aplicaciones en segundo plano (opcional)", 20f, true, "");
            title.SetBounds(20, 10, 700, 36);
            subtitle = Skin.Lbl("WinBoost nunca cierra nada por su cuenta. Aquí puedes elegir aplicaciones concretas, ver su nombre exacto y pedirles que se cierren con normalidad (pueden preguntar si guardar). " +
                "No se listan juegos, antitrampas, componentes de Windows ni herramientas de seguridad. El cierre no se puede deshacer.", 9.5f, false, "muted");
            subtitle.SetBounds(22, 48, 800, 46);
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Resize += delegate
            {
                subtitle.Width = Math.Max(300, header.Width - 40);
                subtitle.Height = Skin.FitHeight(subtitle, subtitle.Width);
                header.Height = subtitle.Bottom + 8;
            };

            Controls.Add(listHost);
            Controls.Add(results);
            Controls.Add(bar);
            Controls.Add(header);
            listHost.Resize += delegate { LayoutBoxes(); };
            results.Resize += delegate
            {
                results.Columns[2].Width = Math.Max(200, results.ClientSize.Width - results.Columns[0].Width - results.Columns[1].Width - 4);
            };
            scanBtn.Click += delegate { Scan(); };
            closeBtn.Click += delegate { CloseSelected(); };
            ApplyTheme();
        }

        public void ApplyTheme()
        {
            Skin.Apply(this);
            BackColor = AppSettings.Current.Bg;
        }

        private void LayoutBoxes()
        {
            int y = 8;
            int w = Math.Max(200, listHost.ClientSize.Width - 30);
            for (int i = 0; i < boxes.Count; i++)
            {
                boxes[i].SetBounds(12, y, w, 24);
                y += 26;
            }
        }

        private void Scan()
        {
            if (busy) return;
            busy = true;
            scanBtn.Enabled = false;
            closeBtn.Enabled = false;
            info.Text = "Buscando…";
            Bg.Run<List<AppCandidate>>(this, delegate { return AppCloser.FindCandidates(); }, delegate(List<AppCandidate> list)
            {
                busy = false;
                scanBtn.Enabled = true;
                for (int i = 0; i < boxes.Count; i++) { listHost.Controls.Remove(boxes[i]); boxes[i].Dispose(); }
                boxes.Clear();
                if (list == null) { info.Text = "No se pudo buscar."; return; }
                for (int i = 0; i < list.Count; i++)
                {
                    AppCandidate c = list[i];
                    CheckBox cb = new CheckBox();
                    cb.AutoSize = false;
                    cb.Tag = c;
                    string t = c.Title.Length > 70 ? c.Title.Substring(0, 70) + "…" : c.Title;
                    cb.Text = c.Name + "  (PID " + c.Pid + ")  ·  " + Fmt.Bytes(c.MemoryBytes) + "  ·  \"" + t + "\"";
                    cb.CheckedChanged += delegate { UpdateButton(); };
                    boxes.Add(cb);
                    listHost.Controls.Add(cb);
                }
                info.Text = list.Count == 0 ? "No hay aplicaciones elegibles abiertas." : list.Count + " aplicaciones. Ninguna viene marcada.";
                Skin.Apply(listHost);
                LayoutBoxes();
                UpdateButton();
            });
        }

        private void UpdateButton()
        {
            int n = 0;
            for (int i = 0; i < boxes.Count; i++) if (boxes[i].Checked) n++;
            closeBtn.Enabled = n > 0 && !busy;
            closeBtn.Text = n > 0 ? "Cerrar las " + n + " marcadas…" : "Cerrar las marcadas…";
        }

        private void CloseSelected()
        {
            if (busy) return;
            List<AppCandidate> chosen = new List<AppCandidate>();
            List<string> lines = new List<string>();
            for (int i = 0; i < boxes.Count; i++)
            {
                if (!boxes[i].Checked) continue;
                AppCandidate c = (AppCandidate)boxes[i].Tag;
                chosen.Add(c);
                lines.Add("• " + c.Name + "  (PID " + c.Pid + ")  —  \"" + c.Title + "\"");
            }
            if (chosen.Count == 0) return;
            if (!Dialogs.Confirm(FindForm(), "Cerrar aplicaciones", "Vas a pedir el cierre de estas aplicaciones, y solo de estas:", lines,
                "Guarda tu trabajo antes. WinBoost solo envía la petición de cierre normal; si una aplicación no se cierra, no se fuerza. Esta acción no se puede deshacer.", "Cerrar")) return;
            busy = true;
            scanBtn.Enabled = false;
            closeBtn.Enabled = false;
            info.Text = "Cerrando…";
            Bg.Run<List<OpEntry>>(this, delegate
            {
                List<OpEntry> res = new List<OpEntry>();
                for (int i = 0; i < chosen.Count; i++) res.Add(AppCloser.CloseOne(chosen[i]));
                return res;
            }, delegate(List<OpEntry> res)
            {
                busy = false;
                scanBtn.Enabled = true;
                results.BeginUpdate();
                results.Items.Clear();
                for (int i = 0; res != null && i < res.Count; i++)
                {
                    Skin.AddRow(results, new string[] { OpText.Label(res[i].Result), res[i].Requested, res[i].Detail },
                        new string[] { OpText.Tone(res[i].Result), "", "muted" });
                }
                results.EndUpdate();
                info.Text = "Hecho. Pulsa «Buscar» para actualizar la lista.";
                UpdateButton();
            });
        }
    }

    // ------------------------------------------------------------------
    // Historial y restauracion
    // ------------------------------------------------------------------

    internal sealed class HistoryPanel : Panel
    {
        private Panel header;
        private Label title;
        private Label subtitle;
        private Panel bar;
        private Button restoreSel;
        private Button restoreAll;
        private Button exportBtn;
        private Button openBtn;
        private Button refreshBtn;
        private ListView log;
        private TextBox detail;
        private Panel detailHost;
        private Label changesTitle;
        private ListView changes;
        private bool busy;

        public HistoryPanel()
        {
            Ui.EnableDoubleBuffer(this);
            log = Skin.NewList();
            log.Dock = DockStyle.Fill;
            log.Columns.Add("Fecha", 135);
            log.Columns.Add("Operación", 125);
            log.Columns.Add("Cambio solicitado", 200);
            log.Columns.Add("Resultado", 150);
            log.Columns.Add("Anterior", 110);
            log.Columns.Add("Nuevo", 110);
            log.Columns.Add("Detalle / motivo", 200);

            detail = new TextBox();
            detail.Multiline = true;
            detail.ReadOnly = true;
            detail.ScrollBars = ScrollBars.Vertical;
            detail.BorderStyle = BorderStyle.None;
            detail.Dock = DockStyle.Fill;
            detailHost = new Panel();
            detailHost.Dock = DockStyle.Bottom;
            detailHost.Height = 84;
            detailHost.Padding = new Padding(16, 8, 16, 8);
            detailHost.Tag = "card";
            detailHost.Controls.Add(detail);

            changes = Skin.NewList();
            changes.Dock = DockStyle.Bottom;
            changes.Height = 140;
            changes.MultiSelect = true;
            changes.Columns.Add("Desde", 140);
            changes.Columns.Add("Cambio aplicado por WinBoost que se puede restaurar", 700);

            changesTitle = Skin.Lbl("Cambios activos restaurables", 11f, true, "");
            changesTitle.Dock = DockStyle.Bottom;
            changesTitle.Height = 30;
            changesTitle.Padding = new Padding(16, 6, 0, 0);

            bar = new Panel();
            bar.Dock = DockStyle.Top;
            bar.Height = 56;
            restoreSel = Skin.Btn("Restaurar seleccionados", false);
            restoreSel.SetBounds(16, 8, 200, 40);
            restoreAll = Skin.Btn("Restaurar todo", true);
            restoreAll.SetBounds(226, 8, 160, 40);
            exportBtn = Skin.Btn("Exportar registro…", false);
            exportBtn.SetBounds(396, 8, 170, 40);
            openBtn = Skin.Btn("Abrir carpeta de datos", false);
            openBtn.SetBounds(576, 8, 190, 40);
            refreshBtn = Skin.Btn("Actualizar", false);
            refreshBtn.SetBounds(776, 8, 110, 40);
            bar.Controls.Add(restoreSel);
            bar.Controls.Add(restoreAll);
            bar.Controls.Add(exportBtn);
            bar.Controls.Add(openBtn);
            bar.Controls.Add(refreshBtn);

            header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 78;
            header.Tag = "card";
            title = Skin.Lbl("Historial y restauración", 20f, true, "");
            title.SetBounds(20, 10, 600, 36);
            subtitle = Skin.Lbl("Todo cambio queda anotado en un registro local, con su resultado y el valor anterior cuando se pudo conocer. WinBoost solo restaura lo que él mismo cambió.", 9.5f, false, "muted");
            subtitle.SetBounds(22, 48, 800, 22);
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Resize += delegate
            {
                subtitle.Width = Math.Max(300, header.Width - 40);
                subtitle.Height = Skin.FitHeight(subtitle, subtitle.Width);
                header.Height = Math.Max(78, subtitle.Bottom + 8);
            };

            Controls.Add(log);
            Controls.Add(detailHost);
            Controls.Add(changesTitle);
            Controls.Add(changes);
            Controls.Add(bar);
            Controls.Add(header);

            log.Resize += delegate
            {
                int used = 0;
                for (int i = 0; i < 6; i++) used += log.Columns[i].Width;
                log.Columns[6].Width = Math.Max(240, log.ClientSize.Width - used - 4);
            };
            changes.Resize += delegate
            {
                changes.Columns[1].Width = Math.Max(300, changes.ClientSize.Width - changes.Columns[0].Width - 4);
            };
            log.SelectedIndexChanged += delegate { ShowDetail(); };
            refreshBtn.Click += delegate { Reload(); };
            restoreSel.Click += delegate { Restore(false); };
            restoreAll.Click += delegate { Restore(true); };
            exportBtn.Click += delegate { Export(); };
            openBtn.Click += delegate { OpenFolder(); };
            OpLog.Changed += delegate { Bg.Post(this, new MethodInvoker(Reload)); };
            ChangeStore.Changed += delegate { Bg.Post(this, new MethodInvoker(Reload)); };
            ApplyTheme();
            Reload();
        }

        public void ApplyTheme()
        {
            Skin.Apply(this);
            BackColor = AppSettings.Current.Bg;
            detail.BackColor = AppSettings.Current.Card;
            detail.ForeColor = AppSettings.Current.Fg;
        }

        public void Reload()
        {
            List<OpEntry> all = OpLog.ReadAll();
            log.BeginUpdate();
            log.Items.Clear();
            int shown = 0;
            for (int i = all.Count - 1; i >= 0 && shown < 500; i--, shown++)
            {
                OpEntry e = all[i];
                ListViewItem it = new ListViewItem(e.Time.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                it.UseItemStyleForSubItems = false;
                it.SubItems[0].Tag = "muted";
                it.SubItems.Add(e.Operation);
                it.SubItems.Add(e.Requested);
                ListViewItem.ListViewSubItem r = it.SubItems.Add(OpText.Label(e.Result));
                r.Tag = OpText.Tone(e.Result);
                it.SubItems.Add(e.Previous);
                it.SubItems.Add(e.New);
                ListViewItem.ListViewSubItem d = it.SubItems.Add(e.Detail);
                d.Tag = "muted";
                it.Tag = e;
                log.Items.Add(it);
            }
            log.EndUpdate();
            if (all.Count == 0 && OpLog.LastError != null) detail.Text = "No se pudo leer el registro: " + OpLog.LastError;
            else if (log.Items.Count == 0) detail.Text = "Todavía no hay operaciones registradas.";

            changes.BeginUpdate();
            changes.Items.Clear();
            List<ChangeRecord> recs = ChangeStore.All();
            for (int i = 0; i < recs.Count; i++)
            {
                ListViewItem it = new ListViewItem(recs[i].Time.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture));
                it.UseItemStyleForSubItems = false;
                it.SubItems[0].Tag = "muted";
                it.SubItems.Add(recs[i].Label);
                it.Tag = recs[i];
                changes.Items.Add(it);
            }
            if (recs.Count == 0)
            {
                Skin.AddRow(changes, new string[] { "", "No hay cambios activos: WinBoost no tiene nada pendiente de restaurar." }, new string[] { "", "muted" });
            }
            changes.EndUpdate();
            restoreAll.Enabled = recs.Count > 0 && !busy;
            restoreSel.Enabled = recs.Count > 0 && !busy;
        }

        private void ShowDetail()
        {
            if (log.SelectedItems.Count == 0) return;
            OpEntry e = log.SelectedItems[0].Tag as OpEntry;
            if (e == null) return;
            detail.Text = e.Time.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  ·  " + e.Operation + "  ·  " + OpText.Label(e.Result) + "\r\n" +
                "Solicitado: " + e.Requested + "\r\n" +
                (e.Previous.Length > 0 || e.New.Length > 0 ? "Antes: " + e.Previous + "   →   Después: " + e.New + "\r\n" : "") +
                "Detalle: " + e.Detail;
            detail.Select(0, 0);
        }

        private void Restore(bool all)
        {
            if (busy) return;
            List<ChangeRecord> targets = new List<ChangeRecord>();
            if (all) targets = ChangeStore.All();
            else
            {
                for (int i = 0; i < changes.SelectedItems.Count; i++)
                {
                    ChangeRecord r = changes.SelectedItems[i].Tag as ChangeRecord;
                    if (r != null) targets.Add(r);
                }
                if (targets.Count == 0)
                {
                    MessageBox.Show(FindForm(), "Selecciona uno o más cambios de la lista inferior, o usa «Restaurar todo».", "WinBoost");
                    return;
                }
            }
            if (targets.Count == 0) return;
            List<string> lines = new List<string>();
            for (int i = 0; i < targets.Count; i++) lines.Add("• " + targets[i].Label);
            if (!Dialogs.Confirm(FindForm(), "Restaurar cambios", "Se intentará restaurar:", lines,
                "Si el ajuste ya fue cambiado por otro medio, WinBoost no lo sobrescribirá y lo anotará como omitido.", "Restaurar")) return;

            busy = true;
            restoreAll.Enabled = false;
            restoreSel.Enabled = false;
            List<PendingElevation> pend = new List<PendingElevation>();
            Bg.Run<List<OpEntry>>(this, delegate
            {
                List<OpEntry> res = new List<OpEntry>();
                for (int i = targets.Count - 1; i >= 0; i--) res.Add(GameModeService.RevertRecord(targets[i], pend));
                return res;
            }, delegate(List<OpEntry> res)
            {
                busy = false;
                Reload();
                int bad = 0;
                for (int i = 0; res != null && i < res.Count; i++) if (res[i].Result != OpResult.Completed && res[i].Result != OpResult.Skipped) bad++;
                string msg = bad == 0 ? "Restauración terminada. Revisa el historial para ver el detalle de cada operación." :
                    bad + " operación(es) no se pudieron completar. Revisa el historial para ver el motivo.";
                MessageBox.Show(FindForm(), msg, "WinBoost");
                if (pend.Count > 0 && MessageBox.Show(FindForm(),
                    "Para restaurar " + pend.Count + " proceso(s) hace falta permiso de administrador (solo para esos procesos). ¿Quieres continuar? Windows mostrará un aviso.",
                    "WinBoost", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    busy = true;
                    List<PendingElevation> items = new List<PendingElevation>(pend);
                    Bg.Run<List<OpEntry>>(this, delegate { return GameModeService.RetryElevated(items); }, delegate(List<OpEntry> r2)
                    {
                        busy = false;
                        Reload();
                    });
                }
            });
        }

        private void Export()
        {
            try
            {
                if (!File.Exists(OpLog.FilePath))
                {
                    MessageBox.Show(FindForm(), "Todavía no hay registro que exportar.", "WinBoost");
                    return;
                }
                using (SaveFileDialog sfd = new SaveFileDialog())
                {
                    sfd.Filter = "Texto separado por tabuladores (*.tsv)|*.tsv|Todos|*.*";
                    sfd.FileName = "WinBoost-registro.tsv";
                    if (sfd.ShowDialog(FindForm()) == DialogResult.OK) File.Copy(OpLog.FilePath, sfd.FileName, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(FindForm(), "No se pudo exportar: " + ex.Message, "WinBoost");
            }
        }

        private void OpenFolder()
        {
            try
            {
                if (!Directory.Exists(AppSettings.Folder)) Directory.CreateDirectory(AppSettings.Folder);
                Process.Start(AppSettings.Folder);
            }
            catch (Exception ex)
            {
                MessageBox.Show(FindForm(), "No se pudo abrir la carpeta: " + ex.Message, "WinBoost");
            }
        }
    }
}
