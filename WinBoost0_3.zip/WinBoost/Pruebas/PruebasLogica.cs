﻿// Pruebas automaticas de la logica de WinBoost 0.3 que NO depende de Windows.
// No forman parte de la aplicacion (no las compila build.bat). Ver Pruebas\LEEME.txt
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace WinBoost
{
    internal static class TestRunner
    {
        private static int pass, fail;

        private static void Check(bool ok, string name)
        {
            if (ok) { pass++; Console.WriteLine("  OK    " + name); }
            else { fail++; Console.WriteLine("  FALLO " + name); }
        }

        private static bool Near(double a, double b, double tol) { return Math.Abs(a - b) <= tol; }

        private static int Main(string[] args)
        {
            string tmp = Path.Combine(Path.GetTempPath(), "wbtest_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(tmp);
            Environment.SetEnvironmentVariable("WINBOOST_DATA", tmp);
            string src = args.Length > 0 ? args[0] : ".";

            Console.WriteLine("== FrameStats ==");
            List<double> c = new List<double>();
            for (int i = 0; i < 1000; i++) c.Add(1000.0 / 60.0);
            FrameStats s1 = FrameStats.Compute(c);
            Check(Near(s1.AvgFps, 60, 0.01) && Near(s1.Low1Fps, 60, 0.01) && Near(s1.P99Ms, 16.6667, 0.001), "fotogramas constantes a 60 FPS");
            List<double> m = new List<double>();
            for (int i = 0; i < 990; i++) m.Add(10);
            for (int i = 0; i < 10; i++) m.Add(100);
            FrameStats s2 = FrameStats.Compute(m);
            Check(Near(s2.AvgFps, 1000 / 10.9, 0.01), "FPS medios con picos (91.74)");
            Check(Near(s2.Low1Fps, 10, 0.001), "1 % low = 10 FPS con 1 % de fotogramas a 100 ms");
            Check(Near(s2.P99Ms, 10, 0.001) && Near(s2.MaxMs, 100, 0.001), "P99 y maximo");
            Check(Near(s2.DurationSec, 10.9, 0.001), "duracion");
            Check(FrameStats.Compute(new double[] { 0, -1, double.NaN }) == null, "valores invalidos descartados -> sin estadisticas");

            Console.WriteLine("== FrameImporter ==");
            StringBuilder pm = new StringBuilder("Application,ProcessID,MsBetweenPresents,Dropped\r\n");
            for (int i = 0; i < 300; i++) pm.Append("game.exe,100,16.67,0\r\n");
            for (int i = 0; i < 50; i++) pm.Append("dwm.exe,200,8.33,0\r\n");
            ImportResult r1 = FrameImporter.Parse(pm.ToString());
            Check(r1.Error == null && r1.Frames.Count == 300 && r1.Game == "game.exe", "PresentMon: filtra la aplicacion dominante");
            Check(r1.Notes.Exists(delegate(string n) { return n.IndexOf("2 aplicaciones") >= 0; }), "PresentMon: avisa de varias aplicaciones");
            ImportResult r2 = FrameImporter.Parse("Application;FrameTime\r\nC:\\Juegos\\mi juego.exe;16,5\r\nC:\\Juegos\\mi juego.exe;17,5\r\n");
            Check(r2.Error == null && r2.Frames.Count == 2 && Near(r2.Frames[0], 16.5, 1e-9) && r2.Game == "mi juego.exe", "CSV con ; y coma decimal, ruta -> nombre");
            ImportResult r3 = FrameImporter.Parse("16.6\n16.7\n33.4\n");
            Check(r3.Error == null && r3.Frames.Count == 3, "lista simple de ms");
            Check(FrameImporter.Parse("a,b,c\n1,2,3\n").Error != null, "sin columna de tiempo -> error comprensible");
            Check(FrameImporter.Parse("").Error != null, "archivo vacio -> error");
            ImportResult r4 = FrameImporter.Parse("# Capture\n# Info\nMsBetweenPresents,Application\n10,x.exe\n10,x.exe\n");
            Check(r4.Error == null && r4.Frames.Count == 2, "cabecera precedida de metadatos");
            double[] ds = FrameImporter.DownsampleMax(new List<double>(new double[] { 1, 2, 3, 99, 5, 6, 7, 8 }), 4);
            Check(ds.Length == 4 && ds[1] == 99, "submuestreo conserva picos");

            Console.WriteLine("== Comparacion ==");
            BenchRecord a = Rec("a", 60, 1200, "Juego", 16.67);
            BenchRecord b = Rec("b", 66, 1200, "Juego", 15.15);
            List<string> w = new List<string>();
            List<CompareRow> rows = BenchCompare.Compare(a, b, w);
            Check(rows[0].Verdict == "Mejor" && rows[0].Tone == "ok", "FPS +10 % -> Mejor");
            Check(rows[2].Verdict == "Mejor", "tiempo de fotograma menor -> Mejor");
            BenchRecord noisy = Rec("n", 60.5, 1200, "Juego", 16.5);
            w = new List<string>(); rows = BenchCompare.Compare(a, noisy, w);
            Check(rows[0].Verdict == "Sin diferencia concluyente", "+0.8 % FPS -> sin diferencia concluyente");
            BenchRecord worse = Rec("w", 50, 1200, "Juego", 20);
            w = new List<string>(); rows = BenchCompare.Compare(a, worse, w);
            Check(rows[0].Verdict == "Peor" && rows[0].Tone == "bad", "FPS -17 % -> Peor");
            BenchRecord other = Rec("o", 66, 1200, "Otro juego", 15);
            w = new List<string>(); BenchCompare.Compare(a, other, w);
            Check(w.Exists(delegate(string x) { return x.IndexOf("juegos son distintos") >= 0; }), "avisa si los juegos difieren");
            BenchRecord shortRun = Rec("s", 66, 300, "Juego", 15);
            w = new List<string>(); BenchCompare.Compare(a, shortRun, w);
            Check(w.Exists(delegate(string x) { return x.IndexOf("menos de 1000") >= 0; }), "avisa de pocas muestras");
            Check(w.Exists(delegate(string x) { return x.IndexOf("Una sola prueba") >= 0; }), "siempre recuerda repetir pruebas");
            BenchRecord sys = new BenchRecord(); sys.Kind = "sistema"; sys.Id = "z";
            w = new List<string>(); rows = BenchCompare.Compare(a, sys, w);
            Check(rows.Count == 0 && w.Count > 0, "tipos distintos no se comparan");

            Console.WriteLine("== Almacen de mediciones ==");
            BenchRecord st = Rec("Prueba\tcon tab", 61.25, 1200, "Mi juego", 16.3);
            st.Notes = "linea1\nlinea2";
            BenchStore.Add(st);
            List<BenchRecord> loaded = BenchStore.Load();
            Check(loaded.Count == 1 && loaded[0].Name == "Prueba\tcon tab" && loaded[0].Notes == "linea1\nlinea2", "ida y vuelta con tabuladores y saltos");
            Check(Near(loaded[0].Get("avgFps"), 61.25, 1e-9) && loaded[0].Frames != null && loaded[0].Frames.Length > 0, "metricas y fotogramas persisten");
            BenchStore.Remove(loaded[0].Id);
            Check(BenchStore.Load().Count == 0, "eliminar medicion");

            Console.WriteLine("== Powercfg / nvidia-smi / GPU ==");
            string en = "Existing Power Schemes (* Active)\n-----------------------------------\nPower Scheme GUID: 381b4222-f694-41f0-9685-ff5bb260df2e  (Balanced) *\nPower Scheme GUID: 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c  (High performance)\n";
            List<PowerPlan> pl = PowerService.ParseList(en);
            Check(pl.Count == 2 && pl[0].Active && !pl[1].Active && pl[1].Name == "High performance", "powercfg /list (ingles)");
            string es = "Combinaciones de energia existentes (* activa)\n---\nGUID de plan de energia: 381b4222-f694-41f0-9685-ff5bb260df2e  (Equilibrado) *\nGUID de plan de energia: 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c  (Alto rendimiento)\nGUID de plan de energia: a1841308-3541-4fab-bc81-f71556f20b4a  (Economizador)\n";
            pl = PowerService.ParseList(es);
            Check(pl.Count == 3 && pl[0].Name == "Equilibrado" && pl[1].Guid == PowerService.HighPerfGuid, "powercfg /list (espanol)");
            Check(PowerService.ParseActiveGuid("GUID de plan de energia: 381b4222-f694-41f0-9685-ff5bb260df2e  (Equilibrado)") == "381b4222-f694-41f0-9685-ff5bb260df2e", "powercfg /getactivescheme");
            Check(PowerService.IsGuid("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c") && !PowerService.IsGuid("8c5e7fda & calc") && !PowerService.IsGuid(null), "validacion estricta de GUID (sin inyeccion)");
            List<NvSample> nv = NvidiaSmi.Parse("NVIDIA GeForce RTX 3060, 54, 12, 1024, 12288\nNVIDIA, Raro Name, [N/A], [Not Supported], 100, 2000\n");
            Check(nv.Count == 2 && nv[0].TempC == 54 && nv[0].UtilPct == 12 && nv[0].MemTotalMb == 12288, "nvidia-smi: valores");
            Check(nv[1].Name == "NVIDIA, Raro Name" && nv[1].TempC == -1 && nv[1].UtilPct == -1 && nv[1].MemUsedMb == 100, "nvidia-smi: [N/A] -> no disponible, nombre con coma");
            Check(NvidiaSmi.Parse("basura").Count == 0 && NvidiaSmi.Parse(null).Count == 0, "nvidia-smi: salida invalida -> sin datos");
            List<KeyValuePair<string, double>> eng = new List<KeyValuePair<string, double>>();
            eng.Add(new KeyValuePair<string, double>("pid_1_luid_0x00000000_0x0000AAAA_phys_0_eng_0_engtype_3D", 30));
            eng.Add(new KeyValuePair<string, double>("pid_2_luid_0x00000000_0x0000AAAA_phys_0_eng_0_engtype_3D", 25));
            eng.Add(new KeyValuePair<string, double>("pid_2_luid_0x00000000_0x0000AAAA_phys_0_eng_1_engtype_3D", 10));
            eng.Add(new KeyValuePair<string, double>("pid_2_luid_0x00000000_0x0000AAAA_phys_0_eng_2_engtype_Copy", 90));
            Check(Near(GpuEngine.Max3d(eng), 55, 1e-9), "GPU 3D: suma por motor entre procesos, ignora Copy");
            Check(GpuEngine.Max3d(new List<KeyValuePair<string, double>>()) == -1, "GPU sin datos -> -1 (no disponible)");

            Console.WriteLine("== Registro y cambios (E/S real en disco) ==");
            OpLog.Add("Prueba", "Cambio\tcon tab\ny salto", OpResult.Failed, "Motivo: permisos", "A", "B");
            OpLog.Add("Prueba", "Otro", OpResult.NeedsPermission, "x", "", "");
            List<OpEntry> log = OpLog.ReadAll();
            Check(log.Count == 2 && log[0].Requested == "Cambio\tcon tab\ny salto" && log[0].Result == OpResult.Failed && log[0].Previous == "A" && log[0].New == "B" && log[0].Detail == "Motivo: permisos", "registro: ida y vuelta, resultado, motivo, anterior/nuevo");
            Check(log[1].Result == OpResult.NeedsPermission && (DateTime.Now - log[1].Time).TotalMinutes < 1, "registro: fecha/hora y pendiente de permisos");
            ChangeRecord cr = new ChangeRecord();
            cr.Kind = "power"; cr.Label = "Plan de energia: A -> B"; cr.Previous = "381b4222-f694-41f0-9685-ff5bb260df2e"; cr.New = PowerService.HighPerfGuid; cr.ProcName = "x";
            ChangeStore.Add(cr);
            ChangeStore.Reload();
            Check(ChangeStore.Count == 1 && ChangeStore.All()[0].Previous == cr.Previous, "cambio activo persiste en disco y se recarga");
            Check(GameModeService.IsActive, "modo juego activo si hay cambios guardados");

            Console.WriteLine("== Modo juego (rutas sin Windows) ==");
            int before = ChangeStore.Count;
            List<OpEntry> act = GameModeService.Activate(new Optimization(), true, new List<GameCandidate>(), null);
            Check(act.Count == 1 && act[0].Result == OpResult.Skipped && act[0].Detail.IndexOf("ya está activado") >= 0 && ChangeStore.Count == before, "activar con el modo ya activo -> omitida, sin duplicar");
            ChangeStore.Remove(ChangeStore.All()[0].Id);
            List<OpEntry> none = GameModeService.Activate(new Optimization(), false, new List<GameCandidate>(), null);
            Check(none[0].Result == OpResult.Skipped && ChangeStore.Count == 0, "activar sin nada seleccionado -> omitida y no aplica nada");
            Analysis an = GameModeService.Analyze();
            Check(!an.Power.Available && !an.Priority.Available && an.Power.StatusText.StartsWith("No disponible") && an.Priority.StatusText.StartsWith("No disponible"), "analisis fuera de Windows: todo 'No disponible', sin excepciones");
            Check(!an.Power.DefaultSelected && !an.Priority.DefaultSelected, "ninguna optimizacion viene marcada por defecto");
            ChangeRecord pr = new ChangeRecord();
            pr.Kind = "priority"; pr.Pid = 999999; pr.StartTicks = 123; pr.ProcName = "fantasma.exe"; pr.Previous = "Normal"; pr.New = "AboveNormal"; pr.Label = "Prioridad de fantasma.exe";
            ChangeStore.Add(pr);
            OpEntry rv = GameModeService.RevertRecord(pr, null);
            Check(rv.Result == OpResult.Skipped && ChangeStore.Count == 0, "revertir prioridad de proceso desaparecido -> omitida y se retira el registro");
            ChangeRecord pw = new ChangeRecord();
            pw.Kind = "power"; pw.Label = "Plan"; pw.Previous = "381b4222-f694-41f0-9685-ff5bb260df2e"; pw.New = PowerService.HighPerfGuid;
            ChangeStore.Add(pw);
            OpEntry rp = GameModeService.RevertRecord(pw, null);
            Check(rp.Result == OpResult.Failed && ChangeStore.Count == 1, "si powercfg no responde, la restauracion falla y el cambio SIGUE pendiente (no se pierde)");
            ChangeStore.Remove(ChangeStore.All()[0].Id);
            Check(AppCloser.FindCandidates().Count == 0, "buscar aplicaciones fuera de Windows -> lista vacia");
            string e1, e2; int ec;
            Check(!ProcRunner.Run("/no/existe/nada", "", 1000, null, out e1, out e2, out ec) && e2.Length > 0, "ProcRunner: herramienta inexistente -> error controlado");

            Console.WriteLine("== Comprobaciones estaticas del codigo fuente ==");
            string[] files = Directory.GetFiles(src, "*.cs");
            int kills = 0; bool registry = false, ews = false, closeOnlyApps = true;
            List<string> killFiles = new List<string>();
            foreach (string f in files)
            {
                if (f.EndsWith("PruebasLogica.cs")) continue;
                string t = File.ReadAllText(f);
                foreach (Match mm in Regex.Matches(t, @"\.Kill\s*\(")) { kills++; killFiles.Add(Path.GetFileName(f)); }
                if (Regex.IsMatch(t, @"Microsoft\.Win32\.Registry|RegistryKey|\breg\s+add|reg\.exe")) registry = true;
                if (t.IndexOf("EmptyWorkingSet") >= 0) ews = true;
                if (t.IndexOf("CloseOne(") >= 0 && !f.EndsWith("Pages.cs") && !f.EndsWith("Core.cs")) closeOnlyApps = false;
            }
            Check(kills == 1 && killFiles[0] == "Core.cs", ".Kill() aparece una sola vez (en ProcRunner, solo para detener su propia herramienta auxiliar tras un tiempo limite)");
            Check(!registry, "no hay acceso al registro de Windows");
            Check(!ews, "no se usa EmptyWorkingSet");
            Check(closeOnlyApps, "CloseOne solo se invoca desde la pantalla de Aplicaciones (confirmacion previa)");
            string coreText = File.ReadAllText(Path.Combine(src, "Core.cs"));
            Check(Regex.Matches(coreText, "AppCloser\\.CloseOne").Count == 0, "el modo juego (Core) no llama a CloseOne");
            string pages = File.ReadAllText(Path.Combine(src, "Pages.cs"));
            int idxConfirm = pages.IndexOf("Dialogs.Confirm(FindForm(), \"Cerrar aplicaciones\"");
            int idxClose = pages.IndexOf("AppCloser.CloseOne(chosen[i])");
            Check(idxConfirm > 0 && idxClose > idxConfirm, "el cierre de apps solo ocurre tras el dialogo de confirmacion con nombres exactos");
            string manifest = File.ReadAllText(Path.Combine(src, "app.manifest"));
            Check(manifest.IndexOf("asInvoker") >= 0 && manifest.IndexOf("requireAdministrator") < 0, "manifiesto: asInvoker (sin administrador por defecto)");
            Console.WriteLine();
            Console.WriteLine("Resultado: " + pass + " correctas, " + fail + " fallidas.");
            try { Directory.Delete(tmp, true); } catch { }
            return fail == 0 ? 0 : 1;
        }

        private static BenchRecord Rec(string name, double fps, int frames, string game, double avgMs)
        {
            BenchRecord r = new BenchRecord();
            r.Id = name; r.Name = name; r.Kind = "fps"; r.Game = game;
            r.M["avgFps"] = fps; r.M["low1Fps"] = fps * 0.7; r.M["avgMs"] = avgMs; r.M["p99Ms"] = avgMs * 1.5; r.M["maxMs"] = avgMs * 3;
            r.M["frames"] = frames; r.M["durationSec"] = frames * avgMs / 1000.0;
            r.Frames = new double[] { avgMs, avgMs * 2, avgMs };
            return r;
        }
    }
}
