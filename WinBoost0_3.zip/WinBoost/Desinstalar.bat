@echo off
setlocal enableextensions
title Desinstalar WinBoost
echo ==================================================
echo   Desinstalar WinBoost 0.3
echo ==================================================
echo.
echo IMPORTANTE: si el modo juego esta activo, abre WinBoost, ve a "Historial"
echo y pulsa "Restaurar todo" ANTES de continuar. Este script NO restaura ajustes.
echo.
set "DATA=%APPDATA%\WinBoost"
if exist "%DATA%\cambios-activos.tsv" for %%F in ("%DATA%\cambios-activos.tsv") do if %%~zF GTR 0 echo AVISO: hay cambios de WinBoost pendientes de restaurar. Restauralos antes de seguir.
echo.
choice /c SN /m "Continuar con la desinstalacion"
if errorlevel 2 goto fin

set "DESK="
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESK=%%D"
if "%DESK%"=="" set "DESK=%USERPROFILE%\Desktop"
set "SMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"

echo.
echo Accesos directos que WinBoost pudo crear:
if exist "%DESK%\WinBoost.lnk" echo   %DESK%\WinBoost.lnk
if exist "%SMENU%\WinBoost.lnk" echo   %SMENU%\WinBoost.lnk
choice /c SN /m "Eliminar estos accesos directos"
if errorlevel 2 goto datos
if exist "%DESK%\WinBoost.lnk" del "%DESK%\WinBoost.lnk"
if exist "%SMENU%\WinBoost.lnk" del "%SMENU%\WinBoost.lnk"
echo Accesos directos eliminados.

:datos
if not exist "%DATA%" goto programa
echo.
echo Datos de WinBoost: %DATA%
echo (registro de operaciones, mediciones, tema, fondo pintado y botones)
choice /c SN /m "Guardar antes una copia de seguridad en el escritorio"
if errorlevel 2 goto borrar
xcopy "%DATA%" "%DESK%\WinBoost-copia-de-datos" /e /i /y >nul
if errorlevel 1 goto copiafallida
echo Copia creada en: %DESK%\WinBoost-copia-de-datos
goto borrar

:copiafallida
echo No se pudo crear la copia de seguridad. No se borrara nada.
goto fin

:borrar
choice /c SN /m "Borrar ahora la carpeta de datos de WinBoost"
if errorlevel 2 goto programa
rmdir /s /q "%DATA%"
echo Datos eliminados.

:programa
echo.
echo Para terminar, cierra WinBoost y borra a mano esta carpeta del programa:
echo   %~dp0

:fin
echo.
pause
endlocal
