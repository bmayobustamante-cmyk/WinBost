﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;

namespace WinBoost
{
    internal sealed class GpuInfo
    {
        public string Name;
        public string Driver;
    }

    internal sealed class NvSample
    {
        public string Name;
        public double TempC = -1;
        public double UtilPct = -1;
        public double MemUsedMb = -1;
        public double MemTotalMb = -1;
    }

    internal sealed class ProcSample
    {
        public int Pid;
        public string Name;
        public double Cpu = -1;       // -1 = no disponible
        public long Memory;
        public ProcessKind Kind;
        public string KindLabel;
        public Color KindColor;
    }

    // Instantanea de métricas. Todo valor -1 (o null) significa "no disponible", nunca un valor inventado.
    internal sealed class Metrics
    {
        public DateTime Time;
        public double Cpu = -1;
        public long RamTotal;
        public long RamUsed;
        public int RamLoad = -1;
        public string CpuName;
        public int LogicalCores;
        public List<GpuInfo> Gpus = new List<GpuInfo>();
        public double GpuLoad3d = -1;
        public List<NvSample> Nvidia = new List<NvSample>();
        public List<ProcSample> Top = new List<ProcSample>();
        public List<string> Errors = new List<string>();
        public string GpuNote;      // por que no hay GPU/carga/temperatura
        public string TempNote;     // por que no hay temperatura
    }

    internal static class CpuCounterFactory
    {
        public static PerformanceCounter Create()
        {
            if (!Platform.IsWindows) return null;
            string[] cats = new string[] { "Processor", "Procesador", "Processor Information", "Informacion del procesador", "Información del procesador" };
            string[] counters = new string[] { "% Processor Time", "% de tiempo de procesador" };
            for (int i = 0; i < cats.Length; i++)
            {
                for (int j = 0; j < counters.Length; j++)
                {
                    try
                    {
                        PerformanceCounter c = new PerformanceCounter(cats[i], counters[j], "_Total");
                        c.NextValue();
                        return c;
                    }
                    catch
                    {
                    }
                }
            }
            return null;
        }
    }

    internal static class MemoryReader
    {
        public static bool Read(out long total, out long used, out int load)
        {
            total = 0; used = 0; load = -1;
            if (!Platform.IsWindows) return false;
            try
            {
                Native.MEMORYSTATUSEX mem = new Native.MEMORYSTATUSEX();
                mem.dwLength = (uint)Marshal.SizeOf(typeof(Native.MEMORYSTATUSEX));
                if (!Native.GlobalMemoryStatusEx(ref mem) || mem.ullTotalPhys == 0) return false;
                total = (long)mem.ullTotalPhys;
                used = (long)(mem.ullTotalPhys - mem.ullAvailPhys);
                load = (int)mem.dwMemoryLoad;
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    // Lectura de nvidia-smi (solo si el controlador de NVIDIA lo incluye). Es la unica fuente de
    // temperatura de GPU que WinBoost considera verificable.
    internal static class NvidiaSmi
    {
        public static string FindExe()
        {
            if (!Platform.IsWindows) return null;
            try
            {
                string a = Path.Combine(Environment.SystemDirectory, "nvidia-smi.exe");
                if (File.Exists(a)) return a;
                string pf = Environment.GetEnvironmentVariable("ProgramFiles");
                if (!string.IsNullOrEmpty(pf))
                {
                    string b = Path.Combine(pf, "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe");
                    if (File.Exists(b)) return b;
                }
            }
            catch
            {
            }
            return null;
        }

        private static double Num(string s)
        {
            double v;
            s = (s ?? "").Trim();
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return v;
            return -1; // "[N/A]", "[Not Supported]", vacio...
        }

        // Formato esperado: name, temperature.gpu, utilization.gpu, memory.used, memory.total (csv,noheader,nounits)
        public static List<NvSample> Parse(string output)
        {
            List<NvSample> list = new List<NvSample>();
            if (string.IsNullOrEmpty(output)) return list;
            string[] lines = output.Split(new char[] { '\n' });
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length == 0) continue;
                string[] f = line.Split(',');
                if (f.Length < 5) continue;
                NvSample s = new NvSample();
                int n = f.Length;
                s.MemTotalMb = Num(f[n - 1]);
                s.MemUsedMb = Num(f[n - 2]);
                s.UtilPct = Num(f[n - 3]);
                s.TempC = Num(f[n - 4]);
                string[] nameParts = new string[n - 4];
                Array.Copy(f, 0, nameParts, 0, n - 4);
                s.Name = string.Join(",", nameParts).Trim();
                list.Add(s);
            }
            return list;
        }

        public static bool Query(out List<NvSample> samples, out string error)
        {
            samples = new List<NvSample>();
            error = null;
            string exe = FindExe();
            if (exe == null) { error = "nvidia-smi no está instalado (solo existe con controladores NVIDIA)."; return false; }
            string so, se; int code;
            if (!ProcRunner.Run(exe, "--query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits", 5000, null, out so, out se, out code))
            {
                error = "nvidia-smi no respondió a tiempo.";
                return false;
            }
            if (code != 0) { error = "nvidia-smi devolvió el código " + code + "."; return false; }
            samples = Parse(so);
            if (samples.Count == 0) { error = "nvidia-smi no devolvió datos interpretables."; return false; }
            return true;
        }
    }

    // Uso 3D de la GPU a partir de los contadores "GPU Engine" de Windows 10 1709+.
    internal static class GpuEngine
    {
        private static readonly Regex InstRx = new Regex(
            @"luid_(0x[0-9a-fA-F]+_0x[0-9a-fA-F]+)_phys_(\d+)_eng_(\d+)_engtype_(\w+)", RegexOptions.Compiled);

        // Entrada: pares (instancia, porcentaje). Se suma por motor entre procesos y se toma el motor 3D más cargado,
        // de forma analoga al Administrador de tareas. Devuelve -1 si no hay datos 3D.
        public static double Max3d(IEnumerable<KeyValuePair<string, double>> values)
        {
            Dictionary<string, double> perEngine = new Dictionary<string, double>();
            foreach (KeyValuePair<string, double> kv in values)
            {
                Match m = InstRx.Match(kv.Key ?? "");
                if (!m.Success) continue;
                if (!string.Equals(m.Groups[4].Value, "3D", StringComparison.OrdinalIgnoreCase)) continue;
                string key = m.Groups[1].Value + "_" + m.Groups[2].Value + "_" + m.Groups[3].Value;
                double cur;
                perEngine.TryGetValue(key, out cur);
                perEngine[key] = cur + Math.Max(0, kv.Value);
            }
            if (perEngine.Count == 0) return -1;
            double max = 0;
            foreach (KeyValuePair<string, double> kv in perEngine) if (kv.Value > max) max = kv.Value;
            return Math.Min(100.0, max);
        }
    }

    internal sealed class SystemMonitor : IDisposable
    {
        private struct CpuMark
        {
            public TimeSpan Total;
            public DateTime At;
        }

        public event Action<Metrics> Updated;
        public Metrics Last;
        public bool Running { get; private set; }

        private System.Threading.Timer timer;
        private int busy;
        private int tick;
        private PerformanceCounter cpu;
        private bool cpuTried;
        private bool hwLoaded;
        private string cpuName;
        private List<GpuInfo> gpus = new List<GpuInfo>();
        private string hwError;
        private Dictionary<int, CpuMark> prev = new Dictionary<int, CpuMark>();
        private Dictionary<string, CounterSample> gpuPrev = new Dictionary<string, CounterSample>();
        private string gpuCounterNote;
        private bool gpuCounterOk = true;
        private List<NvSample> lastNv = new List<NvSample>();
        private string nvError;

        public void Start(int intervalMs)
        {
            if (Running) return;
            Running = true;
            timer = new System.Threading.Timer(delegate { SampleSafe(); }, null, 100, intervalMs);
        }

        public void Stop()
        {
            Running = false;
            System.Threading.Timer t = timer;
            timer = null;
            if (t != null) t.Dispose();
        }

        public void Dispose()
        {
            Stop();
            if (cpu != null) { cpu.Dispose(); cpu = null; }
        }

        private void SampleSafe()
        {
            if (Interlocked.CompareExchange(ref busy, 1, 0) != 0) return;
            try
            {
                Metrics m = Sample();
                Last = m;
                Action<Metrics> h = Updated;
                if (h != null) h(m);
            }
            catch
            {
            }
            finally
            {
                Interlocked.Exchange(ref busy, 0);
            }
        }

        public Metrics Sample()
        {
            Metrics m = new Metrics();
            m.Time = DateTime.Now;
            m.LogicalCores = Environment.ProcessorCount;
            if (!Platform.IsWindows)
            {
                m.Errors.Add("Las métricas del sistema solo están disponibles en Windows.");
                m.GpuNote = "No disponible fuera de Windows.";
                m.TempNote = "No disponible fuera de Windows.";
                return m;
            }
            if (!hwLoaded) LoadHardware();
            m.CpuName = cpuName;
            m.Gpus = new List<GpuInfo>(gpus);
            if (hwError != null) m.Errors.Add(hwError);

            long total, used; int load;
            if (MemoryReader.Read(out total, out used, out load))
            {
                m.RamTotal = total; m.RamUsed = used; m.RamLoad = load;
            }
            else m.Errors.Add("RAM: no se pudo leer el estado de la memoria (GlobalMemoryStatusEx).");

            if (!cpuTried)
            {
                cpuTried = true;
                cpu = CpuCounterFactory.Create();
            }
            if (cpu != null)
            {
                try { m.Cpu = Math.Max(0, Math.Min(100, cpu.NextValue())); }
                catch (Exception ex) { m.Errors.Add("CPU: el contador de rendimiento falló (" + ex.Message + ")."); }
            }
            else m.Errors.Add("CPU: no se pudo abrir el contador de rendimiento de Windows.");

            // GPU: carga 3D por contadores del sistema (cada tick) y nvidia-smi (cada 3 ticks).
            m.GpuLoad3d = ReadGpuLoad();
            if (tick % 3 == 0)
            {
                List<NvSample> s; string err;
                if (NvidiaSmi.Query(out s, out err)) { lastNv = s; nvError = null; }
                else { lastNv = new List<NvSample>(); nvError = err; }
            }
            tick++;
            m.Nvidia = new List<NvSample>(lastNv);

            if (m.Gpus.Count == 0)
                m.GpuNote = "No se detectó ninguna GPU. Depende del hardware, de los controladores y de las fuentes de datos disponibles en Windows.";
            else if (m.GpuLoad3d < 0 && m.Nvidia.Count == 0)
                m.GpuNote = gpuCounterNote ?? "La carga de la GPU no está disponible en este equipo.";

            bool anyTemp = false;
            for (int i = 0; i < m.Nvidia.Count; i++) if (m.Nvidia[i].TempC >= 0) anyTemp = true;
            if (!anyTemp)
            {
                m.TempNote = "No disponible: WinBoost solo muestra temperaturas con una fuente verificable (nvidia-smi en GPU NVIDIA)."
                    + (nvError != null ? " " + nvError : "")
                    + " La temperatura de CPU no se ofrece porque Windows no la expone de forma fiable sin controladores externos.";
            }

            try { SampleProcesses(m); }
            catch (Exception ex) { m.Errors.Add("Procesos: no se pudo leer la lista (" + ex.Message + ")."); }
            return m;
        }

        private void LoadHardware()
        {
            hwLoaded = true;
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT Name FROM Win32_Processor"))
                using (ManagementObjectCollection c = s.Get())
                {
                    foreach (ManagementObject mo in c)
                    {
                        object n = mo["Name"];
                        if (n != null) { cpuName = n.ToString().Trim(); }
                        mo.Dispose();
                        break;
                    }
                }
            }
            catch
            {
            }
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT Name, DriverVersion FROM Win32_VideoController"))
                using (ManagementObjectCollection c = s.Get())
                {
                    foreach (ManagementObject mo in c)
                    {
                        GpuInfo g = new GpuInfo();
                        object n = mo["Name"];
                        object d = mo["DriverVersion"];
                        g.Name = n != null ? n.ToString().Trim() : "";
                        g.Driver = d != null ? d.ToString().Trim() : "";
                        if (g.Name.Length > 0) gpus.Add(g);
                        mo.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                hwError = "GPU: no se pudo consultar WMI (" + ex.Message + ").";
            }
        }

        private double ReadGpuLoad()
        {
            if (!gpuCounterOk) return -1;
            try
            {
                if (!PerformanceCounterCategory.Exists("GPU Engine"))
                {
                    gpuCounterOk = false;
                    gpuCounterNote = "Este Windows no ofrece los contadores \"GPU Engine\" (requiere Windows 10 1709 o posterior y controlador WDDM 2.0+).";
                    return -1;
                }
                PerformanceCounterCategory cat = new PerformanceCounterCategory("GPU Engine");
                InstanceDataCollectionCollection all = cat.ReadCategory();
                if (!all.Contains("Utilization Percentage"))
                {
                    gpuCounterOk = false;
                    gpuCounterNote = "Los contadores de GPU no incluyen el uso porcentual.";
                    return -1;
                }
                InstanceDataCollection data = all["Utilization Percentage"];
                Dictionary<string, CounterSample> now = new Dictionary<string, CounterSample>();
                List<KeyValuePair<string, double>> values = new List<KeyValuePair<string, double>>();
                foreach (DictionaryEntry de in data)
                {
                    string inst = (string)de.Key;
                    InstanceData d = (InstanceData)de.Value;
                    CounterSample cs = d.Sample;
                    now[inst] = cs;
                    CounterSample old;
                    if (gpuPrev.TryGetValue(inst, out old))
                    {
                        float v = CounterSample.Calculate(old, cs);
                        if (!float.IsNaN(v) && !float.IsInfinity(v)) values.Add(new KeyValuePair<string, double>(inst, v));
                    }
                }
                gpuPrev = now;
                return GpuEngine.Max3d(values);
            }
            catch (Exception ex)
            {
                gpuCounterOk = false;
                gpuCounterNote = "No se pudo leer la carga de la GPU (" + ex.Message + ").";
                return -1;
            }
        }

        private void SampleProcesses(Metrics m)
        {
            int self = Process.GetCurrentProcess().Id;
            int cores = Math.Max(1, Environment.ProcessorCount);
            Process[] all = Process.GetProcesses();
            DateTime now = DateTime.UtcNow;
            Dictionary<int, CpuMark> next = new Dictionary<int, CpuMark>();
            List<ProcSample> list = new List<ProcSample>(all.Length);
            for (int i = 0; i < all.Length; i++)
            {
                Process p = all[i];
                try
                {
                    ProcSample s = new ProcSample();
                    s.Pid = p.Id;
                    s.Name = p.ProcessName;
                    try { s.Memory = p.WorkingSet64; }
                    catch { s.Memory = 0; }
                    TimeSpan t;
                    bool have = false;
                    try { t = p.TotalProcessorTime; have = true; }
                    catch { t = TimeSpan.Zero; }
                    if (have)
                    {
                        CpuMark cur = new CpuMark();
                        cur.Total = t; cur.At = now;
                        next[s.Pid] = cur;
                        CpuMark old;
                        if (prev.TryGetValue(s.Pid, out old))
                        {
                            double wall = (now - old.At).TotalMilliseconds;
                            if (wall > 0)
                            {
                                double pct = (t - old.Total).TotalMilliseconds / (wall * cores) * 100.0;
                                s.Cpu = Math.Max(0, Math.Min(100, pct));
                            }
                        }
                    }
                    list.Add(s);
                }
                catch
                {
                }
                finally
                {
                    p.Dispose();
                }
            }
            prev = next;

            List<ProcSample> byCpu = new List<ProcSample>(list);
            byCpu.Sort(delegate(ProcSample a, ProcSample b)
            {
                int c = b.Cpu.CompareTo(a.Cpu);
                return c != 0 ? c : b.Memory.CompareTo(a.Memory);
            });
            List<ProcSample> byMem = new List<ProcSample>(list);
            byMem.Sort(delegate(ProcSample a, ProcSample b) { return b.Memory.CompareTo(a.Memory); });

            List<ProcSample> top = new List<ProcSample>();
            HashSet<int> seen = new HashSet<int>();
            for (int i = 0; i < byCpu.Count && top.Count < 10; i++)
            {
                if (byCpu[i].Name == "Idle" || byCpu[i].Cpu < 0) continue;
                if (seen.Add(byCpu[i].Pid)) top.Add(byCpu[i]);
            }
            for (int i = 0; i < byMem.Count && i < 8; i++)
            {
                if (seen.Add(byMem[i].Pid)) top.Add(byMem[i]);
            }
            top.Sort(delegate(ProcSample a, ProcSample b)
            {
                int c = b.Cpu.CompareTo(a.Cpu);
                return c != 0 ? c : b.Memory.CompareTo(a.Memory);
            });
            for (int i = 0; i < top.Count; i++)
            {
                ProcSample s = top[i];
                string path = Classifier.SafePathByPid(s.Pid);
                s.Kind = Classifier.ClassifyBasic(s.Pid, s.Name, path, self);
                s.KindLabel = Classifier.KindLabel(s.Kind);
                s.KindColor = Classifier.KindColor(s.Kind);
            }
            m.Top = top;
        }
    }
}
