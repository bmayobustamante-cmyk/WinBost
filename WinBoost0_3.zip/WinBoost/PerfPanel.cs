﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace WinBoost
{
    // Grafica de tiempos de fotograma (ms): menos es mejor. Dibujo estatico, sin animaciones.
    internal sealed class FrameChart : Panel
    {
        private static readonly Font F = new Font("Segoe UI", 8.5f);
        public double[] Before;
        public double[] After;

        public FrameChart()
        {
            Ui.EnableDoubleBuffer(this);
            Tag = "card";
        }

        public void SetData(double[] before, double[] after)
        {
            Before = before; After = after;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme t = AppSettings.Current;
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (SolidBrush b = new SolidBrush(t.Card)) g.FillRectangle(b, ClientRectangle);
            TextRenderer.DrawText(g, "Tiempo de fotograma (ms) · menos es mejor", F, new Rectangle(10, 6, Width - 20, 18), t.Muted,
                TextFormatFlags.Left | TextFormatFlags.NoPadding);
            bool hasB = Before != null && Before.Length > 1;
            bool hasA = After != null && After.Length > 1;
            if (!hasB && !hasA)
            {
                TextRenderer.DrawText(g, "Sin datos de fotogramas.\nSe necesitan dos mediciones de FPS importadas.", F,
                    new Rectangle(10, 30, Width - 20, Height - 40), t.Muted, TextFormatFlags.Left | TextFormatFlags.WordBreak);
                return;
            }
            double max = 33.4;
            if (hasB) foreach (double v in Before) if (v > max) max = v;
            if (hasA) foreach (double v in After) if (v > max) max = v;
            Rectangle plot = new Rectangle(44, 30, Math.Max(40, Width - 56), Math.Max(40, Height - 56));
            using (Pen axis = new Pen(Color.FromArgb(60, t.Fg)))
            {
                g.DrawRectangle(axis, plot);
                double[] marks = new double[] { 16.67, 33.33 };
                string[] names = new string[] { "60 FPS", "30 FPS" };
                for (int i = 0; i < marks.Length; i++)
                {
                    if (marks[i] >= max) continue;
                    int y = plot.Bottom - (int)(plot.Height * marks[i] / max);
                    using (Pen dash = new Pen(Color.FromArgb(70, t.Fg)))
                    {
                        dash.DashStyle = DashStyle.Dash;
                        g.DrawLine(dash, plot.Left, y, plot.Right, y);
                    }
                    TextRenderer.DrawText(g, names[i], F, new Point(plot.Right - 46, y - 15), t.Muted);
                }
            }
            TextRenderer.DrawText(g, max.ToString("0") + " ms", F, new Point(2, plot.Top - 6), t.Muted);
            TextRenderer.DrawText(g, "0", F, new Point(26, plot.Bottom - 8), t.Muted);
            if (hasB) Line(g, Before, plot, max, Color.FromArgb(170, 148, 163, 184));
            if (hasA) Line(g, After, plot, max, t.Accent);
            TextRenderer.DrawText(g, "ANTES", F, new Point(plot.Left + 6, Height - 22), Color.FromArgb(148, 163, 184));
            TextRenderer.DrawText(g, "DESPUÉS", F, new Point(plot.Left + 70, Height - 22), t.Accent);
            TextRenderer.DrawText(g, "tiempo de la prueba →", F, new Point(plot.Right - 120, Height - 22), t.Muted);
        }

        private static void Line(Graphics g, double[] v, Rectangle plot, double max, Color c)
        {
            PointF[] pts = new PointF[v.Length];
            for (int i = 0; i < v.Length; i++)
            {
                float x = plot.Left + (float)(plot.Width * (double)i / (v.Length - 1));
                float y = plot.Bottom - (float)(plot.Height * Math.Min(v[i], max) / max);
                pts[i] = new PointF(x, y);
            }
            using (Pen p = new Pen(c, 1.3f)) g.DrawLines(p, pts);
        }
    }

    internal sealed class PerfPanel : Panel
    {
        private Panel header;
        private Label title;
        private Label subtitle;
        private Panel bar;
        private Button importBtn, sysBtn, guideBtn, deleteBtn;
        private Label sysInfo;
        private ListView library;
        private Panel compare;
        private Button beforeBtn, afterBtn;
        private Label beforeLbl, afterLbl, warnLbl;
        private ListView table;
        private FrameChart chart;

        private List<BenchRecord> records = new List<BenchRecord>();
        private string beforeId, afterId;
        private Timer sysTimer;
        private SystemSession session;
        private System.Diagnostics.PerformanceCounter sysCpu;
        private int sysTicks;
        private const int SysSeconds = 30;

        public PerfPanel()
        {
            Ui.EnableDoubleBuffer(this);
            library = Skin.NewList();
            library.Dock = DockStyle.Fill;
            library.MultiSelect = false;
            library.Columns.Add("Nombre", 170);
            library.Columns.Add("Tipo", 70);
            library.Columns.Add("Juego", 140);
            library.Columns.Add("Fecha", 130);
            library.Columns.Add("FPS medios", 90);
            library.Columns.Add("1 % low", 80);
            library.Columns.Add("CPU media", 90);
            library.Columns.Add("Duración", 80);

            compare = new Panel();
            compare.Dock = DockStyle.Bottom;
            compare.Height = 330;
            compare.Tag = "card";
            beforeBtn = Skin.Btn("Usar selección como ANTES", false);
            beforeBtn.SetBounds(12, 8, 230, 34);
            beforeLbl = Skin.Lbl("ANTES: (sin elegir)", 9.5f, false, "muted");
            beforeLbl.SetBounds(250, 14, 260, 22);
            afterBtn = Skin.Btn("Usar selección como DESPUÉS", false);
            afterBtn.SetBounds(520, 8, 240, 34);
            afterLbl = Skin.Lbl("DESPUÉS: (sin elegir)", 9.5f, false, "muted");
            afterLbl.SetBounds(768, 14, 260, 22);
            warnLbl = Skin.Lbl("", 9f, false, "warn");
            table = Skin.NewList();
            table.Columns.Add("Métrica", 215);
            table.Columns.Add("Antes", 62);
            table.Columns.Add("Después", 70);
            table.Columns.Add("Diferencia", 128);
            table.Columns.Add("Lectura", 80);
            chart = new FrameChart();
            compare.Controls.Add(beforeBtn);
            compare.Controls.Add(beforeLbl);
            compare.Controls.Add(afterBtn);
            compare.Controls.Add(afterLbl);
            compare.Controls.Add(warnLbl);
            compare.Controls.Add(table);
            compare.Controls.Add(chart);
            compare.Resize += delegate { LayoutCompare(); };

            bar = new Panel();
            bar.Dock = DockStyle.Top;
            bar.Height = 56;
            importBtn = Skin.Btn("Importar CSV de fotogramas…", true);
            importBtn.SetBounds(16, 8, 250, 40);
            sysBtn = Skin.Btn("Medir sistema (30 s)", false);
            sysBtn.SetBounds(276, 8, 190, 40);
            guideBtn = Skin.Btn("Cómo medir FPS…", false);
            guideBtn.SetBounds(476, 8, 160, 40);
            deleteBtn = Skin.Btn("Quitar medición", false);
            deleteBtn.SetBounds(646, 8, 150, 40);
            sysInfo = Skin.Lbl("", 9.5f, false, "muted");
            sysInfo.SetBounds(806, 18, 300, 22);
            bar.Controls.Add(importBtn);
            bar.Controls.Add(sysBtn);
            bar.Controls.Add(guideBtn);
            bar.Controls.Add(deleteBtn);
            bar.Controls.Add(sysInfo);

            header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 100;
            header.Tag = "card";
            title = Skin.Lbl("Rendimiento: antes y después", 20f, true, "");
            title.SetBounds(20, 10, 700, 36);
            subtitle = Skin.Lbl("WinBoost no mide FPS por sí mismo y no promete que suba. Importa los datos de una herramienta externa (por ejemplo PresentMon o CapFrameX) y compara dos pruebas reales. " +
                "Sí mide de forma nativa la carga de CPU y RAM del sistema. Ajustes gráficos y resolución del juego no se detectan: se anotan a mano.", 9.5f, false, "muted");
            subtitle.SetBounds(22, 48, 800, 46);
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Resize += delegate
            {
                subtitle.Width = Math.Max(300, header.Width - 40);
                subtitle.Height = Skin.FitHeight(subtitle, subtitle.Width);
                header.Height = subtitle.Bottom + 8;
            };

            Controls.Add(library);
            Controls.Add(compare);
            Controls.Add(bar);
            Controls.Add(header);

            importBtn.Click += delegate { Import(); };
            sysBtn.Click += delegate { ToggleSystemSample(); };
            guideBtn.Click += delegate { ShowGuide(); };
            deleteBtn.Click += delegate { DeleteSelected(); };
            beforeBtn.Click += delegate { Pick(true); };
            afterBtn.Click += delegate { Pick(false); };
            library.Resize += delegate { };
            ApplyTheme();
            Reload();
        }

        public void ApplyTheme()
        {
            Skin.Apply(this);
            BackColor = AppSettings.Current.Bg;
            chart.Invalidate();
            LayoutCompare();
        }

        private void LayoutCompare()
        {
            int w = compare.ClientSize.Width;
            int h = compare.ClientSize.Height;
            warnLbl.Width = w - 24;
            int wh = Skin.FitHeight(warnLbl, w - 24);
            int maxWarn = Math.Max(40, h / 3);
            warnLbl.SetBounds(12, 48, w - 24, Math.Min(wh, maxWarn));
            int top = warnLbl.Bottom + 6;
            int tw = (int)(w * 0.55);
            table.SetBounds(12, top, tw - 12, Math.Max(60, h - top - 10));
            chart.SetBounds(tw + 6, top, Math.Max(100, w - tw - 18), Math.Max(60, h - top - 10));
        }

        // ---------- Biblioteca ----------

        public void Reload()
        {
            records = BenchStore.Load();
            records.Sort(delegate(BenchRecord a, BenchRecord b) { return b.Created.CompareTo(a.Created); });
            library.BeginUpdate();
            library.Items.Clear();
            for (int i = 0; i < records.Count; i++)
            {
                BenchRecord r = records[i];
                ListViewItem it = new ListViewItem(r.Name);
                it.UseItemStyleForSubItems = false;
                it.SubItems[0].Tag = "";
                it.SubItems.Add(r.Kind == "fps" ? "FPS" : "Sistema").Tag = "muted";
                it.SubItems.Add(r.Game).Tag = "";
                it.SubItems.Add(r.Created.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture)).Tag = "muted";
                it.SubItems.Add(Num(r, "avgFps", "0.0")).Tag = "";
                it.SubItems.Add(Num(r, "low1Fps", "0.0")).Tag = "";
                it.SubItems.Add(Num(r, "cpuAvg", "0.0") == "—" ? "—" : Num(r, "cpuAvg", "0.0") + " %").Tag = "";
                it.SubItems.Add(Num(r, "durationSec", "0") == "—" ? "—" : Num(r, "durationSec", "0") + " s").Tag = "muted";
                it.Tag = r;
                library.Items.Add(it);
            }
            if (records.Count == 0)
                Skin.AddRow(library, new string[] { "Todavía no hay mediciones", "", "", "", "", "", "", "" }, new string[] { "muted" });
            library.EndUpdate();
            if (FindRecord(beforeId) == null) beforeId = null;
            if (FindRecord(afterId) == null) afterId = null;
            RefreshCompare();
        }

        private static string Num(BenchRecord r, string key, string fmt)
        {
            return r.Has(key) ? r.Get(key).ToString(fmt, CultureInfo.CurrentCulture) : "—";
        }

        private BenchRecord FindRecord(string id)
        {
            if (id == null) return null;
            for (int i = 0; i < records.Count; i++) if (records[i].Id == id) return records[i];
            return null;
        }

        private BenchRecord Selected()
        {
            if (library.SelectedItems.Count == 0) return null;
            return library.SelectedItems[0].Tag as BenchRecord;
        }

        private void Pick(bool isBefore)
        {
            BenchRecord r = Selected();
            if (r == null) { MessageBox.Show(FindForm(), "Selecciona una medición de la lista.", "WinBoost"); return; }
            if (isBefore) beforeId = r.Id; else afterId = r.Id;
            RefreshCompare();
        }

        private void RefreshCompare()
        {
            BenchRecord a = FindRecord(beforeId), b = FindRecord(afterId);
            beforeLbl.Text = a != null ? "ANTES: " + a.Name : "ANTES: (sin elegir)";
            afterLbl.Text = b != null ? "DESPUÉS: " + b.Name : "DESPUÉS: (sin elegir)";
            table.BeginUpdate();
            table.Items.Clear();
            if (a != null && b != null)
            {
                List<string> warns = new List<string>();
                List<CompareRow> rows = BenchCompare.Compare(a, b, warns);
                for (int i = 0; i < rows.Count; i++)
                    Skin.AddRow(table, new string[] { rows[i].Metric, rows[i].Before, rows[i].After, rows[i].Delta, rows[i].Verdict },
                        new string[] { "", "", "", "", rows[i].Tone });
                warnLbl.Text = "• " + string.Join("\n• ", warns.ToArray());
                chart.SetData(a.Frames, b.Frames);
            }
            else
            {
                warnLbl.Text = "Elige una medición como ANTES y otra como DESPUÉS para compararlas. WinBoost no afirma que mejore los FPS: solo muestra lo que se midió.";
                chart.SetData(null, null);
            }
            table.EndUpdate();
            LayoutCompare();
        }

        private void DeleteSelected()
        {
            BenchRecord r = Selected();
            if (r == null) return;
            if (MessageBox.Show(FindForm(), "Se eliminará la medición «" + r.Name + "» guardada por WinBoost. Tu archivo CSV original no se toca.\n\n¿Continuar?",
                "WinBoost", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                BenchStore.Remove(r.Id);
                OpLog.Add("Medición", "Eliminar medición «" + r.Name + "»", OpResult.Completed, "Medición eliminada del almacén local.", "", "");
            }
            catch (Exception ex)
            {
                OpLog.Add("Medición", "Eliminar medición «" + r.Name + "»", OpResult.Failed, ex.Message, "", "");
                MessageBox.Show(FindForm(), "No se pudo eliminar: " + ex.Message, "WinBoost");
            }
            Reload();
        }

        // ---------- Importar ----------

        private void Import()
        {
            string path;
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Datos de fotogramas (*.csv;*.txt)|*.csv;*.txt|Todos|*.*";
                ofd.Title = "Importar tiempos de fotograma";
                if (ofd.ShowDialog(FindForm()) != DialogResult.OK) return;
                path = ofd.FileName;
            }
            Cursor = Cursors.WaitCursor;
            Bg.Run<ImportResult>(this, delegate
            {
                FileInfo fi = new FileInfo(path);
                ImportResult bad = new ImportResult();
                if (fi.Length > 200L * 1024 * 1024) { bad.Error = "El archivo es demasiado grande (más de 200 MB)."; return bad; }
                return FrameImporter.Parse(File.ReadAllText(path));
            }, delegate(ImportResult imp)
            {
                Cursor = Cursors.Default;
                if (imp == null) return;
                if (imp.Error != null)
                {
                    OpLog.Add("Medición", "Importar " + Path.GetFileName(path), OpResult.Failed, imp.Error, "", "");
                    MessageBox.Show(FindForm(), imp.Error, "No se pudo importar");
                    return;
                }
                FrameStats st = FrameStats.Compute(imp.Frames);
                if (st == null) { MessageBox.Show(FindForm(), "No hay fotogramas válidos.", "WinBoost"); return; }
                string summary = st.Frames + " fotogramas · " + st.DurationSec.ToString("0.0", CultureInfo.CurrentCulture) + " s · " +
                    st.AvgFps.ToString("0.0", CultureInfo.CurrentCulture) + " FPS medios · 1 % low " + st.Low1Fps.ToString("0.0", CultureInfo.CurrentCulture) + " FPS";
                if (imp.Notes.Count > 0) summary += "\r\n\r\n" + string.Join("\r\n", imp.Notes.ToArray());
                Screen sc = Screen.PrimaryScreen;
                string res = sc != null ? sc.Bounds.Width + "x" + sc.Bounds.Height : "";
                string name = Path.GetFileNameWithoutExtension(path);
                string game = imp.Game, settings = "", notes = "";
                if (!MetaDialog.Ask(FindForm(), "Datos de la medición", summary, true, ref name, ref game, ref res, ref settings, ref notes)) return;
                BenchRecord rec = BenchStore.FromFrames(name, imp, game, res, settings, notes, Path.GetFileName(path));
                try
                {
                    BenchStore.Add(rec);
                    OpLog.Add("Medición", "Importar " + Path.GetFileName(path), OpResult.Completed, summary.Replace("\r\n", " "), "", name);
                }
                catch (Exception ex)
                {
                    OpLog.Add("Medición", "Importar " + Path.GetFileName(path), OpResult.Failed, ex.Message, "", "");
                    MessageBox.Show(FindForm(), "No se pudo guardar la medición: " + ex.Message, "WinBoost");
                }
                Reload();
            });
        }

        // ---------- Muestra del sistema ----------

        private void ToggleSystemSample()
        {
            if (sysTimer != null) { StopSample(false); return; }
            if (!Platform.IsWindows)
            {
                MessageBox.Show(FindForm(), "La medición del sistema solo está disponible en Windows.", "WinBoost");
                return;
            }
            sysCpu = CpuCounterFactory.Create();
            session = new SystemSession();
            sysTicks = 0;
            sysTimer = new Timer();
            sysTimer.Interval = 1000;
            sysTimer.Tick += delegate { SampleTick(); };
            sysTimer.Start();
            sysBtn.Text = "Cancelar medición";
            sysInfo.Text = "Midiendo… 0/" + SysSeconds + " s. Usa el equipo como en la prueba (en reposo o jugando).";
        }

        private void SampleTick()
        {
            sysTicks++;
            double cpu = -1;
            if (sysCpu != null)
            {
                try { cpu = sysCpu.NextValue(); }
                catch { cpu = -1; }
            }
            long total, used; int load;
            if (!MemoryReader.Read(out total, out used, out load)) { total = 0; used = 0; }
            if (sysTicks > 1) session.Add(cpu, used, total);   // la primera lectura del contador de CPU no es valida
            sysInfo.Text = "Midiendo… " + sysTicks + "/" + SysSeconds + " s";
            if (sysTicks >= SysSeconds) StopSample(true);
        }

        private void StopSample(bool complete)
        {
            if (sysTimer != null) { sysTimer.Stop(); sysTimer.Dispose(); sysTimer = null; }
            if (sysCpu != null) { sysCpu.Dispose(); sysCpu = null; }
            sysBtn.Text = "Medir sistema (30 s)";
            sysInfo.Text = "";
            if (!complete) return;
            BenchRecord rec = session.ToRecord("", "");
            if (rec == null)
            {
                MessageBox.Show(FindForm(), "No se pudo leer ninguna muestra de CPU ni de RAM.", "WinBoost");
                return;
            }
            string summary = "CPU media " + (rec.Has("cpuAvg") ? rec.Get("cpuAvg").ToString("0.0", CultureInfo.CurrentCulture) + " %" : "no disponible") +
                ", máxima " + (rec.Has("cpuMax") ? rec.Get("cpuMax").ToString("0.0", CultureInfo.CurrentCulture) + " %" : "no disponible") +
                " · RAM usada media " + (rec.Has("ramAvgGb") ? rec.Get("ramAvgGb").ToString("0.0", CultureInfo.CurrentCulture) + " GB" : "no disponible");
            string name = "Sistema " + DateTime.Now.ToString("HH:mm", CultureInfo.InvariantCulture), game = "", res = "", settings = "", notes = "";
            if (!MetaDialog.Ask(FindForm(), "Guardar muestra del sistema", summary, false, ref name, ref game, ref res, ref settings, ref notes)) return;
            rec.Name = name; rec.Notes = notes;
            try
            {
                BenchStore.Add(rec);
                OpLog.Add("Medición", "Muestra del sistema (" + SysSeconds + " s)", OpResult.Completed, summary, "", name);
            }
            catch (Exception ex)
            {
                OpLog.Add("Medición", "Muestra del sistema", OpResult.Failed, ex.Message, "", "");
            }
            Reload();
        }

        // ---------- Guía ----------

        private void ShowGuide()
        {
            List<string> lines = new List<string>();
            lines.Add("WinBoost NO incluye un contador de FPS propio: medir FPS exige capturar los eventos de presentación de DirectX/Vulkan de cada juego, y WinBoost no lo hace.");
            lines.Add("Por eso no puede medir de forma nativa: FPS, tiempos de fotograma, 1 % low, resolución interna ni ajustes gráficos del juego.");
            lines.Add("Sí mide de forma nativa: carga de CPU y RAM del sistema («Medir sistema (30 s)»).");
            lines.Add("");
            lines.Add("Procedimiento con datos externos:");
            lines.Add("1. Elige una escena repetible (mismo mapa, mismo recorrido o el benchmark del propio juego), de 60 s o más.");
            lines.Add("2. Con el modo juego INACTIVO, registra una prueba con una herramienta que exporte tiempos de fotograma a CSV (por ejemplo PresentMon, CapFrameX o MSI Afterburner con RTSS). Consulta la documentación de la herramienta para exportar el CSV.");
            lines.Add("3. En WinBoost pulsa «Importar CSV de fotogramas…» y ponle un nombre (por ejemplo «Antes»). Apunta los ajustes gráficos que usaste.");
            lines.Add("4. Activa el modo juego, repite EXACTAMENTE la misma escena y vuelve a importar el resultado («Después»).");
            lines.Add("5. Repite cada prueba al menos 3 veces. Una sola pasada no demuestra nada: las diferencias pequeñas suelen ser variación normal.");
            lines.Add("6. Elige una medición como ANTES y otra como DESPUÉS y mira la comparación.");
            lines.Add("");
            lines.Add("Formatos aceptados: CSV con columna MsBetweenPresents o FrameTime (en milisegundos), o un archivo de texto con un tiempo en milisegundos por línea. Si el CSV contiene varias aplicaciones, WinBoost usa la que tiene más fotogramas.");
            lines.Add("");
            lines.Add("Cómo calcula WinBoost: FPS medios = fotogramas / duración. 1 % low = FPS equivalentes a la media del 1 % de fotogramas más lentos. P99 = percentil 99 del tiempo de fotograma.");
            Dialogs.Confirm(FindForm(), "Cómo medir FPS con datos reales", "Guía de medición", lines,
                "WinBoost no afirma que aumente los FPS: solo muestra lo que se mide en pruebas reproducibles.", "Entendido");
        }
    }

    internal static class MetaDialog
    {
        public static bool Ask(IWin32Window owner, string title, string summary, bool fps,
            ref string name, ref string game, ref string resolution, ref string settings, ref string notes)
        {
            Theme t = AppSettings.Current;
            using (Form f = new Form())
            {
                f.Text = title;
                f.StartPosition = FormStartPosition.CenterParent;
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(560, fps ? 520 : 330);
                f.BackColor = t.Card;
                f.ForeColor = t.Fg;
                f.Font = new Font("Segoe UI", 10f);
                int y = 12;
                Label sl = new Label();
                sl.AutoSize = false;
                sl.Text = summary;
                sl.ForeColor = t.Muted;
                int sh = Math.Min(130, Skin.FitHeight(sl, 528));
                sl.SetBounds(16, y, 528, sh);
                f.Controls.Add(sl);
                y += sh + 10;
                TextBox tName = Field(f, "Nombre de la medición (p. ej. «Antes» o «Después»)", name, ref y, t);
                TextBox tGame = null, tRes = null, tSet = null;
                if (fps)
                {
                    tGame = Field(f, "Juego probado", game, ref y, t);
                    tRes = Field(f, "Resolución (por defecto la del escritorio; la del juego puede ser distinta)", resolution, ref y, t);
                    tSet = Field(f, "Ajustes gráficos (anótalos a mano: WinBoost no puede detectarlos)", settings, ref y, t);
                }
                TextBox tNotes = Field(f, "Notas (escena, versión, qué estaba activado…)", notes, ref y, t);
                Button ok = Ui.MakeButton("Guardar", true);
                ok.SetBounds(560 - 16 - 140, f.ClientSize.Height - 52, 140, 38);
                ok.DialogResult = DialogResult.OK;
                Button cancel = Ui.MakeButton("Cancelar", false);
                cancel.SetBounds(560 - 16 - 140 - 130, f.ClientSize.Height - 52, 120, 38);
                cancel.DialogResult = DialogResult.Cancel;
                f.Controls.Add(ok);
                f.Controls.Add(cancel);
                f.CancelButton = cancel;
                if (f.ShowDialog(owner) != DialogResult.OK) return false;
                name = tName.Text.Trim().Length > 0 ? tName.Text.Trim() : "Medición";
                if (fps)
                {
                    game = tGame.Text.Trim(); resolution = tRes.Text.Trim(); settings = tSet.Text.Trim();
                }
                notes = tNotes.Text.Trim();
                return true;
            }
        }

        private static TextBox Field(Form f, string caption, string value, ref int y, Theme t)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Text = caption;
            l.ForeColor = t.Muted;
            l.Font = new Font("Segoe UI", 9f);
            l.SetBounds(16, y, 528, 18);
            TextBox b = new TextBox();
            b.Text = value ?? "";
            b.BackColor = t.Bg;
            b.ForeColor = t.Fg;
            b.SetBounds(16, y + 20, 528, 26);
            f.Controls.Add(l);
            f.Controls.Add(b);
            y += 54;
            return b;
        }
    }
}
