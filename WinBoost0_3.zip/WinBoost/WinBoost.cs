﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace WinBoost
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            // Modo auxiliar sin interfaz: solo cambia la prioridad de UN proceso con permisos elevados.
            if (args != null && args.Length > 0 && args[0] == Elevated.Flag) return Elevated.RunHelper(args);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            AppSettings.Load();
            Application.Run(new MainForm());
            return 0;
        }
    }

    internal enum ProcessKind
    {
        Self,
        Game,
        GameSupport,
        Critical,
        Other
    }

    internal sealed class Theme
    {
        public string Name;
        public Color Bg;
        public Color Card;
        public Color Sidebar;
        public Color Fg;
        public Color Muted;
        public Color Accent;
        public Color Danger;
        public Image Wallpaper;

        public static Theme Dark()
        {
            return Make("Oscuro", 15, 18, 24, 24, 30, 40, 11, 15, 22, 226, 232, 240, 148, 163, 184, 56, 189, 248);
        }

        public static Theme Midnight()
        {
            return Make("Medianoche", 8, 8, 18, 22, 22, 44, 6, 6, 14, 230, 230, 255, 140, 140, 180, 167, 139, 250);
        }

        public static Theme Light()
        {
            return Make("Claro", 241, 245, 249, 255, 255, 255, 226, 232, 240, 15, 23, 42, 71, 85, 105, 2, 132, 199);
        }

        public static Theme Neon()
        {
            return Make("Neon", 10, 12, 10, 20, 28, 18, 6, 10, 6, 220, 252, 231, 134, 239, 172, 52, 211, 153);
        }

        public static Theme Ember()
        {
            return Make("Brasa", 24, 12, 10, 42, 20, 16, 18, 8, 8, 254, 226, 226, 252, 165, 165, 251, 146, 60);
        }

        public static Theme FromName(string name)
        {
            if (name == "Medianoche") return Midnight();
            if (name == "Claro") return Light();
            if (name == "Neon") return Neon();
            if (name == "Brasa") return Ember();
            return Dark();
        }

        private static Theme Make(string name,
            int b1, int b2, int b3, int c1, int c2, int c3, int s1, int s2, int s3,
            int f1, int f2, int f3, int m1, int m2, int m3, int a1, int a2, int a3)
        {
            Theme t = new Theme();
            t.Name = name;
            t.Bg = Color.FromArgb(b1, b2, b3);
            t.Card = Color.FromArgb(c1, c2, c3);
            t.Sidebar = Color.FromArgb(s1, s2, s3);
            t.Fg = Color.FromArgb(f1, f2, f3);
            t.Muted = Color.FromArgb(m1, m2, m3);
            t.Accent = Color.FromArgb(a1, a2, a3);
            t.Danger = Color.FromArgb(248, 113, 113);
            return t;
        }
    }

    internal static class AppSettings
    {
        public static Theme Current = Theme.Dark();
        public static List<UserLaunch> Buttons = new List<UserLaunch>();
        public static event EventHandler ThemeChanged;

        public static string Folder
        {
            get
            {
                // WINBOOST_DATA permite redirigir los datos (usado por las pruebas automaticas).
                string over = Environment.GetEnvironmentVariable("WINBOOST_DATA");
                if (!string.IsNullOrEmpty(over)) return over;
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WinBoost");
            }
        }

        public static string WallpaperPath
        {
            get { return Path.Combine(Folder, "wallpaper.png"); }
        }

        public static void Load()
        {
            try
            {
                if (!Directory.Exists(Folder)) Directory.CreateDirectory(Folder);
                string themeFile = Path.Combine(Folder, "theme.txt");
                if (File.Exists(themeFile))
                {
                    Current = Theme.FromName(File.ReadAllText(themeFile).Trim());
                }
                if (File.Exists(WallpaperPath))
                {
                    byte[] bytes = File.ReadAllBytes(WallpaperPath);
                    using (MemoryStream ms = new MemoryStream(bytes))
                    using (Image tmp = Image.FromStream(ms))
                    {
                        Current.Wallpaper = new Bitmap(tmp);
                    }
                }
                string btnFile = Path.Combine(Folder, "buttons.txt");
                Buttons.Clear();
                if (File.Exists(btnFile))
                {
                    string[] lines = File.ReadAllLines(btnFile);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        UserLaunch u = UserLaunch.Parse(lines[i]);
                        if (u != null) Buttons.Add(u);
                    }
                }
            }
            catch
            {
            }
        }

        public static void SaveTheme()
        {
            try
            {
                if (!Directory.Exists(Folder)) Directory.CreateDirectory(Folder);
                File.WriteAllText(Path.Combine(Folder, "theme.txt"), Current.Name);
            }
            catch
            {
            }
        }

        public static void SaveButtons()
        {
            try
            {
                if (!Directory.Exists(Folder)) Directory.CreateDirectory(Folder);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < Buttons.Count; i++)
                {
                    sb.AppendLine(Buttons[i].Serialize());
                }
                File.WriteAllText(Path.Combine(Folder, "buttons.txt"), sb.ToString());
            }
            catch
            {
            }
        }

        public static void SetTheme(Theme theme, bool keepWallpaper)
        {
            Image wall = keepWallpaper ? Current.Wallpaper : null;
            Current = theme;
            Current.Wallpaper = wall;
            SaveTheme();
            if (ThemeChanged != null) ThemeChanged(null, EventArgs.Empty);
        }

        public static void SetWallpaper(Image image)
        {
            try
            {
                if (!Directory.Exists(Folder)) Directory.CreateDirectory(Folder);
                if (Current.Wallpaper != null)
                {
                    Current.Wallpaper.Dispose();
                    Current.Wallpaper = null;
                }
                using (Bitmap clone = new Bitmap(image))
                {
                    clone.Save(WallpaperPath, System.Drawing.Imaging.ImageFormat.Png);
                }
                byte[] bytes = File.ReadAllBytes(WallpaperPath);
                using (MemoryStream ms = new MemoryStream(bytes))
                using (Image tmp = Image.FromStream(ms))
                {
                    Current.Wallpaper = new Bitmap(tmp);
                }
                if (ThemeChanged != null) ThemeChanged(null, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo guardar el fondo: " + ex.Message);
            }
        }

        public static void ClearWallpaper()
        {
            try
            {
                if (Current.Wallpaper != null)
                {
                    Current.Wallpaper.Dispose();
                    Current.Wallpaper = null;
                }
                if (File.Exists(WallpaperPath)) File.Delete(WallpaperPath);
                if (ThemeChanged != null) ThemeChanged(null, EventArgs.Empty);
            }
            catch
            {
            }
        }
    }

    internal sealed class UserLaunch
    {
        public string Title;
        public string Kind;
        public string Target;
        public Color Color;

        public string Serialize()
        {
            return Title.Replace("|", "/") + "|" + Kind + "|" + Target.Replace("|", "/") + "|" + Color.ToArgb().ToString();
        }

        public static UserLaunch Parse(string line)
        {
            if (string.IsNullOrEmpty(line)) return null;
            string[] p = line.Split('|');
            if (p.Length < 3) return null;
            UserLaunch u = new UserLaunch();
            u.Title = p[0];
            u.Kind = p[1];
            u.Target = p[2];
            u.Color = Color.FromArgb(56, 189, 248);
            if (p.Length >= 4)
            {
                int argb;
                if (int.TryParse(p[3], out argb)) u.Color = Color.FromArgb(argb);
            }
            return u;
        }
    }

    internal static class Native
    {
        public const uint QueryLimited = 0x1000;
        public const uint SetInfo = 0x0200;

        [DllImport("user32.dll")]
        public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll")]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        public static extern int GetSystemMetrics(int nIndex);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

        [DllImport("kernel32.dll")]
        public static extern uint GetPriorityClass(IntPtr hProcess);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool SetPriorityClass(IntPtr hProcess, uint priorityClass);

        [DllImport("kernel32.dll")]
        public static extern bool GetProcessTimes(IntPtr hProcess, out long creation, out long exit, out long kernel, out long user);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        public static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder name, ref int size);

        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr h);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
        }
    }

    internal static class Ui
    {
        public static void EnableDoubleBuffer(Control c)
        {
            try
            {
                typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic)
                    .SetValue(c, true, null);
            }
            catch
            {
            }
        }

        public static Button MakeButton(string text, bool primary)
        {
            Theme t = AppSettings.Current;
            Button b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.Cursor = Cursors.Hand;
            b.Font = new Font("Segoe UI Semibold", 10f);
            b.BackColor = primary ? t.Accent : Color.FromArgb(70, t.Fg);
            b.ForeColor = primary ? Contrast(t.Accent) : t.Fg;
            return b;
        }

        public static Color Contrast(Color c)
        {
            int yiq = ((c.R * 299) + (c.G * 587) + (c.B * 114)) / 1000;
            return yiq >= 140 ? Color.FromArgb(15, 23, 42) : Color.White;
        }

        public static void PaintWallpaper(Control host, PaintEventArgs e)
        {
            if (AppSettings.Current.Wallpaper == null) return;
            e.Graphics.DrawImage(AppSettings.Current.Wallpaper, host.ClientRectangle);
            using (SolidBrush dim = new SolidBrush(Color.FromArgb(140, AppSettings.Current.Bg)))
            {
                e.Graphics.FillRectangle(dim, host.ClientRectangle);
            }
        }

        public static Icon LoadIcon()
        {
            try
            {
                string exe = Application.ExecutablePath;
                if (File.Exists(exe)) return Icon.ExtractAssociatedIcon(exe);
            }
            catch
            {
            }
            try
            {
                string ico = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WinBoost.ico");
                if (File.Exists(ico)) return new Icon(ico);
            }
            catch
            {
            }
            return SystemIcons.Application;
        }
    }

    internal static class ShortcutMaker
    {
        public static string CreateDesktop()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string lnk = Path.Combine(desktop, "WinBoost.lnk");
            Create(lnk);
            try
            {
                string start = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "WinBoost.lnk");
                Create(start);
            }
            catch
            {
            }
            return lnk;
        }

        private static void Create(string lnk)
        {
            string exe = Application.ExecutablePath;
            string dir = Path.GetDirectoryName(exe);
            string ico = Path.Combine(dir, "WinBoost.ico");
            Type t = Type.GetTypeFromProgID("WScript.Shell");
            object sh = Activator.CreateInstance(t);
            object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { lnk });
            Set(sc, "TargetPath", exe);
            Set(sc, "WorkingDirectory", dir);
            Set(sc, "WindowStyle", 1);
            Set(sc, "Description", "Optimizador WinBoost");
            if (File.Exists(ico)) Set(sc, "IconLocation", ico + ",0");
            else Set(sc, "IconLocation", exe + ",0");
            sc.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
        }

        private static void Set(object o, string name, object value)
        {
            o.GetType().InvokeMember(name, BindingFlags.SetProperty, null, o, new object[] { value });
        }
    }

    internal static class Classifier
    {
        private static readonly HashSet<string> Critical = NewSet(new string[]
        {
            "idle", "system", "registry", "smss", "csrss", "wininit", "winlogon",
            "services", "lsass", "lsm", "svchost", "fontdrvhost", "dwm", "conhost",
            "sihost", "taskhostw", "runtimebroker", "searchindexer",
            "searchhost", "startmenuexperiencehost", "shellexperiencehost",
            "textinputhost", "ctfmon", "dllhost", "wudfhost", "spoolsv",
            "audiodg", "secure system", "memory compression",
            "system interrupts", "applicationframehost", "systemsettings",
            "securityhealthservice", "securityhealthsystray", "smartscreen",
            "mpdefendercoreservice", "msmpeng", "nissrv", "securityhealthhost",
            "trustedinstaller", "tiworker", "wuauclt", "useroobebroker",
            "lockapp", "logonui", "userinit", "explorer",
            "nvcontainer", "nvidia share", "nvdisplay.container", "nvvadsvc",
            "amdfendrsr", "amdow", "atiesrxx", "atieclxx", "igfxem", "igfxcuiservice",
            "gamebarpresencewriter", "gamingservices", "gamingservicesnet",
            "xblauthmanager", "xblgamesave", "xboxgipsvc",
            "searchprotocolhost", "searchfilterhost", "sgrmbroker",
            "aggregatorhost", "backgroundtaskhost", "mousocoreworker",
            "filecoauth", "dataexchangehost", "rundll32", "taskmgr",
            "consent", "lsaiso", "credentialuibroker", "werfault", "wermgr",
            "winboost"
        });

        private static readonly HashSet<string> GameSupport = NewSet(new string[]
        {
            "steam", "steamservice", "steamwebhelper", "gameoverlayui",
            "epicgameslauncher", "epicwebhelper",
            "riotclientservices", "riotclientux", "leagueclient", "leagueclientux",
            "battle.net", "origin", "origini", "eadesktop",
            "uplay", "upc", "ubiservices", "galaxyclient", "galaxyclienthelper",
            "socialclubhelper", "playnite.desktopapp",
            "easyanticheat", "easyanticheat_eos", "easyanticheat_setup",
            "battleye", "beservice", "beinternal", "bedaisy",
            "vgc", "vgm", "vgtray", "vanguard",
            "faceit", "faceitclient", "faceitservice",
            "eac_launcher", "x64anticheat", "x86anticheat",
            "discord", "discordptb", "discordcanary",
            "obs64", "obs32"
        });

        private static readonly HashSet<string> AntiCheat = NewSet(new string[]
        {
            "easyanticheat", "easyanticheat_eos", "easyanticheat_setup", "eac_launcher",
            "battleye", "beservice", "beinternal", "bedaisy",
            "vgc", "vgm", "vgtray", "vanguard",
            "faceit", "faceitclient", "faceitservice",
            "x64anticheat", "x86anticheat", "gameguard", "npggnt", "xigncode", "xigncode3"
        });

        private static readonly HashSet<string> KnownGames = NewSet(new string[]
        {
            "cs2", "csgo", "dota2", "hl2", "left4dead2", "tf2",
            "valorant", "valorant-win64-shipping",
            "fortniteclient-win64-shipping", "fortnitelauncher",
            "gta5", "gtav", "playgtav", "rdr2",
            "modernwarfare", "codmw", "overwatch", "wow", "wowclassic",
            "minecraft", "javaw", "robloxplayerbeta", "roblox",
            "rocketleague", "r5apex", "eldenring", "sekiro", "darksoulsiii",
            "cyberpunk2077", "witcher3", "deadbydaylight", "phasmophobia",
            "palworld", "helldivers2", "thefinals", "rainbowsix",
            "starfield", "skyrimse", "fallout4", "destiny2", "warframe",
            "genshinimpact", "starrail", "zenlesszonezero", "osu!",
            "terraria", "tmodloader", "factorio", "rimworld", "valheim",
            "escapefromtarkov", "tslgame", "fivem", "fivem_gtaprocess",
            "vrchat", "forzahorizon5", "eurotrucks2", "rustclient", "rust",
            "bg3", "bg3_dx11", "hades", "hades2", "celeste", "hollowknight"
        });

        private static readonly string[] GamePathHints = new string[]
        {
            "\\steamapps\\common\\",
            "\\epic games\\",
            "\\xboxgames\\",
            "\\riot games\\",
            "\\ubisoft\\",
            "\\origin games\\",
            "\\ea games\\",
            "\\battle.net\\",
            "\\gog galaxy\\games\\",
            "\\rockstar games\\",
            "\\minecraft\\",
            "\\roblox\\"
        };

        public static bool IsAntiCheat(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            string n = name.ToLowerInvariant();
            if (n.IndexOf("anticheat") >= 0) return true;
            return AntiCheat.Contains(n);
        }

        public static bool IsProtectedName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            return Critical.Contains(name) || name.ToLowerInvariant() == "winboost";
        }

        // Clasificacion completa (usa el proceso para consultar sesion y ventanas).
        public static ProcessKind Classify(Process process, int selfPid, HashSet<int> gamePids)
        {
            if (process.Id == selfPid) return ProcessKind.Self;
            string name = SafeName(process);
            if (name == "winboost") return ProcessKind.Self;

            string path = SafePath(process);
            if (gamePids.Contains(process.Id) || IsKnownGame(name, path) || LooksLikeGamePath(path))
            {
                return ProcessKind.Game;
            }

            if (IsGameSupport(name, path) || IsAntiCheat(name)) return ProcessKind.GameSupport;

            int session = -1;
            try { session = process.SessionId; }
            catch { session = -1; }
            if (Critical.Contains(name) || session == 0) return ProcessKind.Critical;
            return ProcessKind.Other;
        }

        // Clasificacion ligera por nombre y ruta (para el monitor; no consulta ventanas).
        public static ProcessKind ClassifyBasic(int pid, string name, string path, int selfPid)
        {
            string n = (name ?? "").ToLowerInvariant();
            if (pid == selfPid || n == "winboost") return ProcessKind.Self;
            if (IsKnownGame(n, path) || LooksLikeGamePath(path)) return ProcessKind.Game;
            if (IsGameSupport(n, path) || IsAntiCheat(n)) return ProcessKind.GameSupport;
            if (Critical.Contains(n)) return ProcessKind.Critical;
            return ProcessKind.Other;
        }

        public static HashSet<int> DetectGamePids(Process[] processes)
        {
            HashSet<int> games = new HashSet<int>();
            Dictionary<uint, List<IntPtr>> windows = GetVisibleWindows();
            int screenW = Native.GetSystemMetrics(0);
            int screenH = Native.GetSystemMetrics(1);
            for (int i = 0; i < processes.Length; i++)
            {
                Process p = processes[i];
                try
                {
                    string name = SafeName(p);
                    string path = SafePath(p);
                    if (IsKnownGame(name, path) || LooksLikeGamePath(path))
                    {
                        games.Add(p.Id);
                        continue;
                    }
                    List<IntPtr> hwnds;
                    if (windows.TryGetValue((uint)p.Id, out hwnds))
                    {
                        for (int w = 0; w < hwnds.Count; w++)
                        {
                            if (IsFullscreen(hwnds[w], screenW, screenH) && !IsShellWindow(name))
                            {
                                games.Add(p.Id);
                                break;
                            }
                        }
                    }
                }
                catch
                {
                }
            }
            return games;
        }

        public static string KindLabel(ProcessKind kind)
        {
            switch (kind)
            {
                case ProcessKind.Self: return "WinBoost";
                case ProcessKind.Game: return "Juego";
                case ProcessKind.GameSupport: return "Soporte de juego";
                case ProcessKind.Critical: return "Protegido";
                default: return "Otro";
            }
        }

        public static Color KindColor(ProcessKind kind)
        {
            switch (kind)
            {
                case ProcessKind.Self: return Color.FromArgb(125, 211, 252);
                case ProcessKind.Game: return Color.FromArgb(74, 222, 128);
                case ProcessKind.GameSupport: return Color.FromArgb(52, 211, 153);
                case ProcessKind.Critical: return Color.FromArgb(148, 163, 184);
                default: return Color.FromArgb(203, 213, 225);
            }
        }

        private static bool IsGameSupport(string name, string path)
        {
            if (GameSupport.Contains(name)) return true;
            string lower = (path ?? "").ToLowerInvariant();
            if (name == "agent" && lower.IndexOf("battle.net") >= 0) return true;
            if (name == "launcher" && (LooksLikeGamePath(path) || lower.IndexOf("riot") >= 0)) return true;
            return false;
        }

        private static bool IsKnownGame(string name, string path)
        {
            if (name == "javaw")
            {
                string blob = ((path ?? "") + " " + name).ToLowerInvariant();
                return blob.IndexOf("minecraft") >= 0 || blob.IndexOf("technic") >= 0 || blob.IndexOf("lunar") >= 0;
            }
            if (KnownGames.Contains(name)) return true;
            return name.IndexOf("-win64-shipping", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool LooksLikeGamePath(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            string lower = path.ToLowerInvariant();
            if (lower.IndexOf("\\windowsapps\\microsoft.") >= 0) return false;
            for (int i = 0; i < GamePathHints.Length; i++)
            {
                if (lower.IndexOf(GamePathHints[i], StringComparison.Ordinal) >= 0) return true;
            }
            return false;
        }

        private static bool IsShellWindow(string name)
        {
            return name == "explorer" || name == "searchhost" || name == "shellexperiencehost"
                || name == "startmenuexperiencehost" || name == "applicationframehost"
                || name == "textinputhost" || name == "dwm";
        }

        private static bool IsFullscreen(IntPtr hwnd, int screenW, int screenH)
        {
            Native.RECT r;
            if (!Native.GetWindowRect(hwnd, out r)) return false;
            int w = r.Right - r.Left;
            int h = r.Bottom - r.Top;
            return w >= screenW - 8 && h >= screenH - 8;
        }

        private static Dictionary<uint, List<IntPtr>> GetVisibleWindows()
        {
            Dictionary<uint, List<IntPtr>> map = new Dictionary<uint, List<IntPtr>>();
            Native.EnumWindows(delegate(IntPtr hwnd, IntPtr lParam)
            {
                if (!Native.IsWindowVisible(hwnd)) return true;
                uint pid;
                Native.GetWindowThreadProcessId(hwnd, out pid);
                List<IntPtr> list;
                if (!map.TryGetValue(pid, out list))
                {
                    list = new List<IntPtr>();
                    map[pid] = list;
                }
                list.Add(hwnd);
                return true;
            }, IntPtr.Zero);
            return map;
        }

        public static string WindowTitle(int pid, Dictionary<uint, List<IntPtr>> windows)
        {
            List<IntPtr> hwnds;
            if (!windows.TryGetValue((uint)pid, out hwnds)) return "";
            StringBuilder sb = new StringBuilder(512);
            for (int i = 0; i < hwnds.Count; i++)
            {
                sb.Length = 0;
                Native.GetWindowText(hwnds[i], sb, sb.Capacity);
                string t = sb.ToString();
                if (!string.IsNullOrEmpty(t)) return t;
            }
            return "";
        }

        public static Dictionary<uint, List<IntPtr>> SnapshotWindows()
        {
            return GetVisibleWindows();
        }

        public static string SafeName(Process p)
        {
            try { return (p.ProcessName ?? "").ToLowerInvariant(); }
            catch { return ""; }
        }

        public static string SafePathByPid(int pid)
        {
            if (!Platform.IsWindows) return "";
            IntPtr h = Native.OpenProcess(Native.QueryLimited, false, pid);
            if (h == IntPtr.Zero) return "";
            try
            {
                StringBuilder sb = new StringBuilder(1024);
                int size = sb.Capacity;
                if (Native.QueryFullProcessImageName(h, 0, sb, ref size)) return sb.ToString();
            }
            finally
            {
                Native.CloseHandle(h);
            }
            return "";
        }

        public static string SafePath(Process p)
        {
            IntPtr h = Native.OpenProcess(Native.QueryLimited, false, p.Id);
            if (h == IntPtr.Zero)
            {
                try { return p.MainModule.FileName; }
                catch { return ""; }
            }
            try
            {
                StringBuilder sb = new StringBuilder(1024);
                int size = sb.Capacity;
                if (Native.QueryFullProcessImageName(h, 0, sb, ref size)) return sb.ToString();
            }
            finally
            {
                Native.CloseHandle(h);
            }
            return "";
        }

        private static HashSet<string> NewSet(string[] items)
        {
            HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < items.Length; i++) set.Add(items[i]);
            return set;
        }
    }

    internal sealed class MainForm : Form
    {
        private Panel sidebar;
        private Panel content;
        private Label brand;
        private Label version;
        private GamingPanel gaming;
        private MonitorPanel monitorPage;
        private PerfPanel perf;
        private AppsPanel apps;
        private HistoryPanel history;
        private ButtonsPanel buttons;
        private PaintPanel paint;
        private GamesHub games;
        private AppearancePanel appearance;
        private readonly List<Control> pages = new List<Control>();
        private readonly List<Button> nav = new List<Button>();
        private Control currentPage;
        private readonly SystemMonitor monitor = new SystemMonitor();
        private const int MonitorIntervalMs = 2000;

        public MainForm()
        {
            Text = "WinBoost 0.3 · Gaming Mode";
            Width = 1240;
            Height = 780;
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(1000, 660);
            Font = new Font("Segoe UI", 10f);
            KeyPreview = true;
            Icon = Ui.LoadIcon();
            Ui.EnableDoubleBuffer(this);

            sidebar = new Panel();
            sidebar.Dock = DockStyle.Left;
            sidebar.Width = 188;
            content = new Panel();
            content.Dock = DockStyle.Fill;
            content.Padding = new Padding(0);
            content.Paint += delegate(object s, PaintEventArgs e) { Ui.PaintWallpaper(content, e); };

            Controls.Add(content);
            Controls.Add(sidebar);

            gaming = new GamingPanel();
            monitorPage = new MonitorPanel();
            perf = new PerfPanel();
            apps = new AppsPanel();
            history = new HistoryPanel();
            buttons = new ButtonsPanel();
            paint = new PaintPanel();
            games = new GamesHub();
            appearance = new AppearancePanel();
            pages.AddRange(new Control[] { gaming, monitorPage, perf, apps, history, buttons, paint, games, appearance });
            for (int i = 0; i < pages.Count; i++)
            {
                pages[i].Dock = DockStyle.Fill;
                content.Controls.Add(pages[i]);
            }

            BuildSidebar();
            AppSettings.ThemeChanged += delegate { ApplyTheme(); };
            ApplyTheme();
            ShowPage(gaming, "Modo juego");
            KeyDown += OnKeyForward;

            monitor.Updated += delegate(Metrics m)
            {
                Bg.Post(this, new MethodInvoker(delegate
                {
                    gaming.OnMetrics(m);
                    monitorPage.OnMetrics(m);
                }));
            };
            Resize += delegate
            {
                if (WindowState == FormWindowState.Minimized) monitor.Stop();
                else if (!monitor.Running && IsHandleCreated) monitor.Start(MonitorIntervalMs);
            };
            Shown += delegate
            {
                monitor.Start(MonitorIntervalMs);
                gaming.RunAnalysis();
                AskFirstShortcut();
            };
            FormClosing += OnClosing;
        }

        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            if (GameModeService.IsActive)
            {
                DialogResult dr = MessageBox.Show(this,
                    "El modo juego sigue activo (" + ChangeStore.Count + " cambio(s) aplicado(s) por WinBoost).\n\n" +
                    "Sí: restaurar ahora y salir.\nNo: salir sin restaurar (podrás restaurar desde Historial la próxima vez).\nCancelar: seguir en WinBoost.",
                    "WinBoost", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Cancel) { e.Cancel = true; return; }
                if (dr == DialogResult.Yes)
                {
                    Cursor = Cursors.WaitCursor;
                    try { GameModeService.Deactivate(null); }
                    catch (Exception ex) { OpLog.Add("Modo juego", "Restaurar al salir", OpResult.Failed, ex.Message, "", ""); }
                    Cursor = Cursors.Default;
                }
            }
            monitor.Dispose();
        }

        private void OnKeyForward(object sender, KeyEventArgs e)
        {
            if (games.Visible) games.HandleKey(e);
        }

        // 0.2 creaba el acceso directo sin preguntar; ahora se pide permiso una sola vez.
        private void AskFirstShortcut()
        {
            try
            {
                string flag = Path.Combine(AppSettings.Folder, "shortcut.done");
                if (File.Exists(flag)) return;
                DialogResult dr = MessageBox.Show(this,
                    "¿Quieres crear un acceso directo de WinBoost en el escritorio y en el menú Inicio?\n\nPuedes hacerlo más tarde con el botón «Acceso directo».",
                    "WinBoost", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    string p = ShortcutMaker.CreateDesktop();
                    OpLog.Add("Acceso directo", "Crear acceso directo", OpResult.Completed, p, "", p);
                }
                if (!Directory.Exists(AppSettings.Folder)) Directory.CreateDirectory(AppSettings.Folder);
                File.WriteAllText(flag, "1");
            }
            catch (Exception ex)
            {
                OpLog.Add("Acceso directo", "Crear acceso directo", OpResult.Failed, ex.Message, "", "");
            }
        }

        private void BuildSidebar()
        {
            brand = new Label();
            brand.Name = "brand";
            brand.Text = "WinBoost";
            brand.Font = new Font("Segoe UI Semibold", 16f);
            brand.AutoSize = true;
            brand.Location = new Point(16, 14);
            sidebar.Controls.Add(brand);
            version = new Label();
            version.Name = "version";
            version.Text = "0.3 · Gaming Mode";
            version.Font = new Font("Segoe UI", 8.5f);
            version.AutoSize = true;
            version.Location = new Point(18, 46);
            sidebar.Controls.Add(version);

            int y = 76;
            AddNav("Modo juego", y, gaming); y += 44;
            AddNav("Monitor", y, monitorPage); y += 44;
            AddNav("Rendimiento", y, perf); y += 44;
            AddNav("Aplicaciones", y, apps); y += 44;
            AddNav("Historial", y, history); y += 44;
            AddNav("Mis botones", y, buttons); y += 44;
            AddNav("Paint", y, paint); y += 44;
            AddNav("Juegitos", y, games); y += 44;
            AddNav("Apariencia", y, appearance); y += 52;

            Button shortcut = Ui.MakeButton("Acceso directo", false);
            shortcut.Name = "shortcutBtn";
            shortcut.SetBounds(16, y, 156, 36);
            shortcut.Click += delegate
            {
                try
                {
                    string path = ShortcutMaker.CreateDesktop();
                    OpLog.Add("Acceso directo", "Crear acceso directo", OpResult.Completed, path, "", path);
                    MessageBox.Show(this, "Acceso creado en el escritorio:\n" + path, "WinBoost");
                }
                catch (Exception ex)
                {
                    OpLog.Add("Acceso directo", "Crear acceso directo", OpResult.Failed, ex.Message, "", "");
                    MessageBox.Show(this, "No se pudo crear el acceso: " + ex.Message, "WinBoost");
                }
            };
            sidebar.Controls.Add(shortcut);
        }

        private void AddNav(string title, int y, Control page)
        {
            Button b = new Button();
            b.Text = title;
            b.Tag = page;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.SetBounds(12, y, 164, 40);
            b.TextAlign = ContentAlignment.MiddleLeft;
            b.Padding = new Padding(12, 0, 0, 0);
            b.Cursor = Cursors.Hand;
            b.Click += delegate { ShowPage(page, title); };
            sidebar.Controls.Add(b);
            nav.Add(b);
        }

        public void OpenTool(string id)
        {
            if (id == "paint") ShowPage(paint, "Paint");
            else if (id == "games") ShowPage(games, "Juegitos");
            else if (id == "snake") { ShowPage(games, "Juegitos"); games.OpenGame("snake"); }
            else if (id == "pong") { ShowPage(games, "Juegitos"); games.OpenGame("pong"); }
            else if (id == "memory") { ShowPage(games, "Juegitos"); games.OpenGame("memory"); }
            else if (id == "buttons") ShowPage(buttons, "Mis botones");
            else if (id == "theme") ShowPage(appearance, "Apariencia");
            else ShowPage(gaming, "Modo juego");
        }

        public void ShowPage(Control page, string title)
        {
            currentPage = page;
            for (int i = 0; i < pages.Count; i++) pages[i].Visible = pages[i] == page;
            page.BringToFront();
            ApplyTheme();
            if (page == buttons) buttons.Reload();
            if (page == history) history.Reload();
            if (page == perf) perf.Reload();
            if (page == games) games.FocusHub();
        }

        private void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = t.Bg;
            ForeColor = t.Fg;
            sidebar.BackColor = t.Sidebar;
            content.BackColor = t.Bg;
            content.Invalidate();
            foreach (Control c in sidebar.Controls)
            {
                Label l = c as Label;
                if (l != null)
                {
                    l.ForeColor = l.Name == "version" ? t.Muted : t.Fg;
                    l.BackColor = t.Sidebar;
                }
                Button b = c as Button;
                if (b != null)
                {
                    bool on = b.Tag == currentPage;
                    b.BackColor = on ? t.Accent : t.Sidebar;
                    b.ForeColor = on ? Ui.Contrast(t.Accent) : t.Fg;
                    b.FlatAppearance.MouseOverBackColor = t.Card;
                }
            }
            gaming.ApplyTheme();
            monitorPage.ApplyTheme();
            perf.ApplyTheme();
            apps.ApplyTheme();
            history.ApplyTheme();
            buttons.ApplyTheme();
            paint.ApplyTheme();
            games.ApplyTheme();
            appearance.ApplyTheme();
        }
    }
}
