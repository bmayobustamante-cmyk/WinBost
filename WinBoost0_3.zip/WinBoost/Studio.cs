﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace WinBoost
{
    internal sealed class ButtonsPanel : Panel
    {
        private FlowLayoutPanel flow;
        private Label hint;

        public ButtonsPanel()
        {
            Ui.EnableDoubleBuffer(this);
            hint = new Label();
            hint.AutoSize = true;
            hint.Text = "Crea botones para abrir programas, webs o los juegitos de WinBoost.";
            hint.Location = new Point(18, 16);
            Button add = new Button();
            add.Name = "addBtn";
            add.Text = "+ Anadir boton";
            add.FlatStyle = FlatStyle.Flat;
            add.FlatAppearance.BorderSize = 0;
            add.SetBounds(18, 48, 160, 36);
            add.Click += delegate { AddNew(); };
            Controls.Add(hint);
            Controls.Add(add);
            flow = new FlowLayoutPanel();
            flow.SetBounds(18, 96, 900, 500);
            flow.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            flow.AutoScroll = true;
            Controls.Add(flow);
            Resize += delegate { flow.Size = new Size(Math.Max(200, Width - 36), Math.Max(120, Height - 114)); };
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = Color.Transparent;
            hint.ForeColor = t.Muted;
            hint.BackColor = Color.Transparent;
            foreach (Control c in Controls)
            {
                Button b = c as Button;
                if (b != null && b.Name == "addBtn")
                {
                    b.BackColor = t.Accent;
                    b.ForeColor = Ui.Contrast(t.Accent);
                }
            }
            flow.BackColor = Color.Transparent;
            Reload();
        }

        public void Reload()
        {
            flow.Controls.Clear();
            for (int i = 0; i < AppSettings.Buttons.Count; i++)
            {
                flow.Controls.Add(MakeTile(AppSettings.Buttons[i], i));
            }
        }

        private Control MakeTile(UserLaunch item, int index)
        {
            Button b = new Button();
            b.Size = new Size(168, 88);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = item.Color;
            b.ForeColor = Ui.Contrast(item.Color);
            b.Font = new Font("Segoe UI Semibold", 11f);
            b.Text = item.Title + "\n" + item.Kind;
            b.TextAlign = ContentAlignment.MiddleLeft;
            b.Padding = new Padding(12, 8, 8, 8);
            b.Margin = new Padding(8);
            b.Cursor = Cursors.Hand;
            UserLaunch captured = item;
            int capturedIndex = index;
            b.Click += delegate { Run(captured); };
            b.MouseUp += delegate(object s, MouseEventArgs e)
            {
                if (e.Button != MouseButtons.Right) return;
                if (MessageBox.Show("¿Quitar este boton?", "WinBoost", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    AppSettings.Buttons.RemoveAt(capturedIndex);
                    AppSettings.SaveButtons();
                    Reload();
                }
            };
            return b;
        }

        private void AddNew()
        {
            using (Form dlg = new Form())
            {
                Theme t = AppSettings.Current;
                dlg.Text = "Nuevo boton";
                dlg.Size = new Size(420, 280);
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.BackColor = t.Card;
                dlg.ForeColor = t.Fg;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false;
                Label l1 = new Label(); l1.Text = "Nombre"; l1.Location = new Point(16, 16); l1.AutoSize = true;
                TextBox name = new TextBox(); name.SetBounds(16, 36, 370, 26);
                Label l2 = new Label(); l2.Text = "Accion"; l2.Location = new Point(16, 72); l2.AutoSize = true;
                ComboBox kind = new ComboBox();
                kind.DropDownStyle = ComboBoxStyle.DropDownList;
                kind.SetBounds(16, 92, 370, 26);
                kind.Items.AddRange(new object[] {
                    "programa", "web", "paint", "snake", "pong", "memory", "optimizar", "apariencia"
                });
                kind.SelectedIndex = 0;
                Label l3 = new Label(); l3.Text = "Ruta o URL (si aplica)"; l3.Location = new Point(16, 128); l3.AutoSize = true;
                TextBox target = new TextBox(); target.SetBounds(16, 148, 280, 26);
                Button browse = Ui.MakeButton("...", false);
                browse.SetBounds(304, 146, 82, 28);
                browse.Click += delegate
                {
                    using (OpenFileDialog ofd = new OpenFileDialog())
                    {
                        ofd.Filter = "Programas|*.exe;*.bat;*.lnk|Todo|*.*";
                        if (ofd.ShowDialog(dlg) == DialogResult.OK) target.Text = ofd.FileName;
                    }
                };
                Button ok = Ui.MakeButton("Crear", true);
                ok.SetBounds(246, 196, 140, 34);
                Color chosen = t.Accent;
                ok.Click += delegate
                {
                    if (string.IsNullOrEmpty(name.Text.Trim()))
                    {
                        MessageBox.Show(dlg, "Ponle un nombre al boton.");
                        return;
                    }
                    UserLaunch u = new UserLaunch();
                    u.Title = name.Text.Trim();
                    u.Kind = kind.Text;
                    u.Target = target.Text.Trim();
                    u.Color = chosen;
                    AppSettings.Buttons.Add(u);
                    AppSettings.SaveButtons();
                    dlg.DialogResult = DialogResult.OK;
                };
                Button colorBtn = Ui.MakeButton("Color", false);
                colorBtn.SetBounds(16, 196, 90, 34);
                colorBtn.Click += delegate
                {
                    using (ColorDialog cd = new ColorDialog())
                    {
                        cd.Color = chosen;
                        if (cd.ShowDialog(dlg) == DialogResult.OK)
                        {
                            chosen = cd.Color;
                            colorBtn.BackColor = chosen;
                        }
                    }
                };
                dlg.Controls.Add(l1); dlg.Controls.Add(name);
                dlg.Controls.Add(l2); dlg.Controls.Add(kind);
                dlg.Controls.Add(l3); dlg.Controls.Add(target); dlg.Controls.Add(browse);
                dlg.Controls.Add(colorBtn); dlg.Controls.Add(ok);
                dlg.ShowDialog(this);
            }
            Reload();
        }

        private void Run(UserLaunch item)
        {
            try
            {
                MainForm host = FindForm() as MainForm;
                string k = (item.Kind ?? "").ToLowerInvariant();
                if (k == "programa" || k == "web")
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = item.Target;
                    psi.UseShellExecute = true;
                    Process.Start(psi);
                    return;
                }
                if (host == null) return;
                if (k == "paint") host.OpenTool("paint");
                else if (k == "snake") host.OpenTool("snake");
                else if (k == "pong") host.OpenTool("pong");
                else if (k == "memory") host.OpenTool("memory");
                else if (k == "optimizar") host.OpenTool("optimizar");
                else if (k == "apariencia") host.OpenTool("theme");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "No se pudo abrir: " + ex.Message);
            }
        }
    }

    internal sealed class AppearancePanel : Panel
    {
        private Label title;
        private Label hint;

        public AppearancePanel()
        {
            Ui.EnableDoubleBuffer(this);
            title = new Label();
            title.Text = "Apariencia";
            title.Font = new Font("Segoe UI Semibold", 20f);
            title.AutoSize = true;
            title.Location = new Point(20, 16);
            hint = new Label();
            hint.AutoSize = true;
            hint.Location = new Point(22, 54);
            hint.Text = "Elige un tema. En Paint puedes dibujar un fondo y usarlo aqui.";
            Controls.Add(title);
            Controls.Add(hint);

            AddThemeButton("Oscuro", Theme.Dark(), 20, 100);
            AddThemeButton("Medianoche", Theme.Midnight(), 170, 100);
            AddThemeButton("Claro", Theme.Light(), 320, 100);
            AddThemeButton("Neon", Theme.Neon(), 470, 100);
            AddThemeButton("Brasa", Theme.Ember(), 620, 100);

            Button wall = Ui.MakeButton("Usar ultimo dibujo de Paint", false);
            wall.SetBounds(20, 170, 240, 40);
            wall.Click += delegate
            {
                if (System.IO.File.Exists(AppSettings.WallpaperPath))
                {
                    Image img = Image.FromFile(AppSettings.WallpaperPath);
                    AppSettings.SetWallpaper(new Bitmap(img));
                    img.Dispose();
                }
                else MessageBox.Show(this, "Todavia no hay un dibujo guardado. Abre Paint, dibuja y pulsa Usar como fondo.");
            };
            Button clear = Ui.MakeButton("Quitar fondo pintado", false);
            clear.SetBounds(276, 170, 200, 40);
            clear.Click += delegate { AppSettings.ClearWallpaper(); };
            Controls.Add(wall);
            Controls.Add(clear);
        }

        private void AddThemeButton(string name, Theme theme, int x, int y)
        {
            Button b = new Button();
            b.Text = name;
            b.SetBounds(x, y, 140, 48);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = theme.Accent;
            b.ForeColor = Ui.Contrast(theme.Accent);
            b.Cursor = Cursors.Hand;
            Theme captured = theme;
            b.Click += delegate { AppSettings.SetTheme(Theme.FromName(captured.Name), true); };
            Controls.Add(b);
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            title.ForeColor = t.Fg;
            hint.ForeColor = t.Muted;
            foreach (Control c in Controls)
            {
                if (c is Label) c.BackColor = Color.Transparent;
            }
        }
    }

    internal sealed class PaintPanel : Panel
    {
        private Bitmap canvas;
        private PictureBox box;
        private Color color = Color.White;
        private int size = 8;
        private bool drawing;
        private Point last;
        private bool eraser;
        private Label status;

        public PaintPanel()
        {
            Ui.EnableDoubleBuffer(this);
            canvas = new Bitmap(1100, 620);
            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.FromArgb(18, 22, 30));
            }
            Panel tools = new Panel();
            tools.Dock = DockStyle.Top;
            tools.Height = 52;
            tools.Name = "tools";
            string[] names = new string[] { "Lapiz", "Goma", "Borrar todo", "Color", "Usar como fondo", "Guardar" };
            int x = 12;
            for (int i = 0; i < names.Length; i++)
            {
                Button b = Ui.MakeButton(names[i], i == 4);
                b.Tag = names[i];
                b.SetBounds(x, 8, i == 4 ? 160 : 110, 34);
                x += b.Width + 8;
                string n = names[i];
                b.Click += delegate { Tool(n); };
                tools.Controls.Add(b);
            }
            TrackBar tb = new TrackBar();
            tb.Minimum = 2;
            tb.Maximum = 40;
            tb.Value = 8;
            tb.SetBounds(x + 8, 8, 140, 36);
            tb.TickStyle = TickStyle.None;
            tb.Scroll += delegate { size = tb.Value; };
            tools.Controls.Add(tb);
            status = new Label();
            status.AutoSize = true;
            status.Text = "Dibuja con el raton. Luego puedes usar el dibujo como fondo de WinBoost.";
            status.Location = new Point(x + 160, 16);
            tools.Controls.Add(status);

            box = new PictureBox();
            box.Dock = DockStyle.Fill;
            box.SizeMode = PictureBoxSizeMode.Zoom;
            box.Image = canvas;
            box.BackColor = Color.Black;
            box.MouseDown += OnDown;
            box.MouseMove += OnMove;
            box.MouseUp += delegate { drawing = false; };
            Controls.Add(box);
            Controls.Add(tools);
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = t.Bg;
            status.ForeColor = t.Muted;
            foreach (Control c in Controls)
            {
                if (c.Name == "tools")
                {
                    c.BackColor = t.Card;
                    foreach (Control b in c.Controls)
                    {
                        Button btn = b as Button;
                        if (btn != null)
                        {
                            bool primary = (btn.Tag as string) == "Usar como fondo";
                            btn.BackColor = primary ? t.Accent : Color.FromArgb(80, t.Fg);
                            btn.ForeColor = primary ? Ui.Contrast(t.Accent) : t.Fg;
                        }
                    }
                }
            }
        }

        private void Tool(string name)
        {
            if (name == "Lapiz") eraser = false;
            else if (name == "Goma") eraser = true;
            else if (name == "Borrar todo")
            {
                using (Graphics g = Graphics.FromImage(canvas)) g.Clear(Color.FromArgb(18, 22, 30));
                box.Invalidate();
            }
            else if (name == "Color")
            {
                using (ColorDialog cd = new ColorDialog())
                {
                    cd.Color = color;
                    if (cd.ShowDialog(this) == DialogResult.OK) color = cd.Color;
                }
            }
            else if (name == "Usar como fondo")
            {
                AppSettings.SetWallpaper(new Bitmap(canvas));
                status.Text = "Fondo aplicado. Mira Apariencia o cualquier pestana.";
            }
            else if (name == "Guardar")
            {
                using (SaveFileDialog sfd = new SaveFileDialog())
                {
                    sfd.Filter = "PNG|*.png";
                    sfd.FileName = "winboost-dibujo.png";
                    if (sfd.ShowDialog(this) == DialogResult.OK) canvas.Save(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
        }

        private Point Map(Point p)
        {
            if (box.Image == null) return p;
            float imgAspect = (float)canvas.Width / canvas.Height;
            float boxAspect = (float)box.ClientSize.Width / Math.Max(1, box.ClientSize.Height);
            int drawW, drawH, offX, offY;
            if (boxAspect > imgAspect)
            {
                drawH = box.ClientSize.Height;
                drawW = (int)(drawH * imgAspect);
                offX = (box.ClientSize.Width - drawW) / 2;
                offY = 0;
            }
            else
            {
                drawW = box.ClientSize.Width;
                drawH = (int)(drawW / imgAspect);
                offX = 0;
                offY = (box.ClientSize.Height - drawH) / 2;
            }
            int x = (p.X - offX) * canvas.Width / Math.Max(1, drawW);
            int y = (p.Y - offY) * canvas.Height / Math.Max(1, drawH);
            return new Point(x, y);
        }

        private void OnDown(object sender, MouseEventArgs e)
        {
            drawing = true;
            last = Map(e.Location);
            Stamp(last);
        }

        private void OnMove(object sender, MouseEventArgs e)
        {
            if (!drawing) return;
            Point now = Map(e.Location);
            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (Pen pen = new Pen(eraser ? Color.FromArgb(18, 22, 30) : color, size))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    g.DrawLine(pen, last, now);
                }
            }
            last = now;
            box.Invalidate();
        }

        private void Stamp(Point p)
        {
            using (Graphics g = Graphics.FromImage(canvas))
            {
                using (SolidBrush br = new SolidBrush(eraser ? Color.FromArgb(18, 22, 30) : color))
                {
                    g.FillEllipse(br, p.X - size / 2, p.Y - size / 2, size, size);
                }
            }
            box.Invalidate();
        }
    }

    internal sealed class GamesHub : Panel
    {
        private Panel menu;
        private SnakeGame snake;
        private PongGame pong;
        private MemoryGame memory;
        private Control current;

        public GamesHub()
        {
            Ui.EnableDoubleBuffer(this);
            menu = new Panel();
            menu.Dock = DockStyle.Fill;
            Label t = new Label();
            t.Name = "title";
            t.Text = "Juegitos";
            t.Font = new Font("Segoe UI Semibold", 22f);
            t.AutoSize = true;
            t.Location = new Point(24, 20);
            Label s = new Label();
            s.Name = "sub";
            s.Text = "Minijuegos dentro de WinBoost. No cierran ni tocan procesos.";
            s.AutoSize = true;
            s.Location = new Point(26, 58);
            menu.Controls.Add(t);
            menu.Controls.Add(s);
            AddPlay("Serpiente", "snake", 24, 110);
            AddPlay("Pong", "pong", 24, 170);
            AddPlay("Memoria", "memory", 24, 230);

            snake = new SnakeGame();
            pong = new PongGame();
            memory = new MemoryGame();
            snake.Dock = DockStyle.Fill;
            pong.Dock = DockStyle.Fill;
            memory.Dock = DockStyle.Fill;
            snake.Visible = false;
            pong.Visible = false;
            memory.Visible = false;
            snake.BackRequested += delegate { ShowMenu(); };
            pong.BackRequested += delegate { ShowMenu(); };
            memory.BackRequested += delegate { ShowMenu(); };
            Controls.Add(snake);
            Controls.Add(pong);
            Controls.Add(memory);
            Controls.Add(menu);
        }

        private void AddPlay(string title, string id, int x, int y)
        {
            Button b = Ui.MakeButton(title, true);
            b.SetBounds(x, y, 220, 44);
            b.Tag = id;
            string captured = id;
            b.Click += delegate { OpenGame(captured); };
            menu.Controls.Add(b);
        }

        public void OpenGame(string id)
        {
            if (current is IGamePage) ((IGamePage)current).StopGame();
            snake.Visible = id == "snake";
            pong.Visible = id == "pong";
            memory.Visible = id == "memory";
            menu.Visible = false;
            if (id == "snake") { current = snake; snake.StartGame(); snake.Focus(); }
            else if (id == "pong") { current = pong; pong.StartGame(); pong.Focus(); }
            else { current = memory; memory.StartGame(); memory.Focus(); }
            current.BringToFront();
        }

        public void ShowMenu()
        {
            if (current is IGamePage) ((IGamePage)current).StopGame();
            snake.Visible = false;
            pong.Visible = false;
            memory.Visible = false;
            menu.Visible = true;
            menu.BringToFront();
            current = menu;
        }

        public void FocusHub()
        {
            if (current != null) current.Focus();
            else menu.Focus();
        }

        public void HandleKey(KeyEventArgs e)
        {
            if (current == snake) snake.HandleKey(e);
            else if (current == pong) pong.HandleKey(e);
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = t.Bg;
            menu.BackColor = Color.Transparent;
            foreach (Control c in menu.Controls)
            {
                if (c is Label)
                {
                    c.ForeColor = c.Name == "sub" ? t.Muted : t.Fg;
                    c.BackColor = Color.Transparent;
                }
                Button b = c as Button;
                if (b != null)
                {
                    b.BackColor = t.Accent;
                    b.ForeColor = Ui.Contrast(t.Accent);
                }
            }
            snake.ApplyTheme();
            pong.ApplyTheme();
            memory.ApplyTheme();
        }
    }

    internal interface IGamePage
    {
        void StopGame();
    }

    internal sealed class SnakeGame : Panel, IGamePage
    {
        public event EventHandler BackRequested;
        private Timer timer;
        private readonly List<Point> body = new List<Point>();
        private Point dir = new Point(1, 0);
        private Point nextDir = new Point(1, 0);
        private Point food;
        private int score;
        private bool dead;
        private const int Cell = 20;
        private Label hud;

        public SnakeGame()
        {
            Ui.EnableDoubleBuffer(this);
            TabStop = true;
            hud = new Label();
            hud.AutoSize = true;
            hud.Location = new Point(12, 8);
            Button back = Ui.MakeButton("Volver", false);
            back.Name = "back";
            back.SetBounds(12, 36, 100, 32);
            back.Click += delegate
            {
                StopGame();
                if (BackRequested != null) BackRequested(this, EventArgs.Empty);
            };
            Controls.Add(hud);
            Controls.Add(back);
            timer = new Timer();
            timer.Interval = 90;
            timer.Tick += delegate { Step(); };
            Paint += OnPaint;
            PreviewKeyDown += delegate(object s, PreviewKeyDownEventArgs e) { e.IsInputKey = true; };
            KeyDown += OnKey;
        }

        public void HandleKey(KeyEventArgs e)
        {
            OnKey(this, e);
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = t.Bg;
            hud.ForeColor = t.Fg;
            foreach (Control c in Controls)
            {
                Button b = c as Button;
                if (b != null)
                {
                    b.BackColor = t.Card;
                    b.ForeColor = t.Fg;
                }
            }
            Invalidate();
        }

        public void StartGame()
        {
            body.Clear();
            body.Add(new Point(8, 8));
            body.Add(new Point(7, 8));
            body.Add(new Point(6, 8));
            dir = new Point(1, 0);
            nextDir = dir;
            score = 0;
            dead = false;
            PlaceFood();
            hud.Text = "Flechas para mover. Puntos: 0";
            timer.Start();
            Focus();
        }

        public void StopGame()
        {
            timer.Stop();
        }

        private void PlaceFood()
        {
            Random r = new Random();
            int cols = Math.Max(10, (Width - 20) / Cell);
            int rows = Math.Max(8, (Height - 80) / Cell);
            while (true)
            {
                Point p = new Point(r.Next(cols), r.Next(rows));
                bool hit = false;
                for (int i = 0; i < body.Count; i++)
                {
                    if (body[i] == p) { hit = true; break; }
                }
                if (!hit) { food = p; return; }
            }
        }

        private void OnKey(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up && dir.Y != 1) nextDir = new Point(0, -1);
            if (e.KeyCode == Keys.Down && dir.Y != -1) nextDir = new Point(0, 1);
            if (e.KeyCode == Keys.Left && dir.X != 1) nextDir = new Point(-1, 0);
            if (e.KeyCode == Keys.Right && dir.X != -1) nextDir = new Point(1, 0);
            if (e.KeyCode == Keys.Space && dead) StartGame();
            e.Handled = true;
        }

        private void Step()
        {
            if (dead) return;
            dir = nextDir;
            Point head = body[0];
            Point n = new Point(head.X + dir.X, head.Y + dir.Y);
            int cols = Math.Max(10, (Width - 20) / Cell);
            int rows = Math.Max(8, (Height - 80) / Cell);
            if (n.X < 0 || n.Y < 0 || n.X >= cols || n.Y >= rows)
            {
                Die();
                return;
            }
            for (int i = 0; i < body.Count; i++)
            {
                if (body[i] == n) { Die(); return; }
            }
            body.Insert(0, n);
            if (n == food)
            {
                score += 10;
                hud.Text = "Flechas para mover. Puntos: " + score;
                PlaceFood();
            }
            else body.RemoveAt(body.Count - 1);
            Invalidate();
        }

        private void Die()
        {
            dead = true;
            timer.Stop();
            hud.Text = "Fin. Puntos: " + score + "  (Espacio para reiniciar)";
            Invalidate();
        }

        private void OnPaint(object sender, PaintEventArgs e)
        {
            Theme t = AppSettings.Current;
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            int ox = 16;
            int oy = 80;
            using (SolidBrush foodBr = new SolidBrush(t.Danger))
            using (SolidBrush bodyBr = new SolidBrush(t.Accent))
            using (SolidBrush headBr = new SolidBrush(t.Fg))
            {
                e.Graphics.FillRectangle(foodBr, ox + food.X * Cell, oy + food.Y * Cell, Cell - 2, Cell - 2);
                for (int i = 0; i < body.Count; i++)
                {
                    Brush br = i == 0 ? (Brush)headBr : bodyBr;
                    e.Graphics.FillRectangle(br, ox + body[i].X * Cell, oy + body[i].Y * Cell, Cell - 2, Cell - 2);
                }
            }
        }
    }

    internal sealed class PongGame : Panel, IGamePage
    {
        public event EventHandler BackRequested;
        private Timer timer;
        private float ballX = 200, ballY = 160, vx = 5, vy = 4;
        private float playerY = 120, cpuY = 120;
        private int playerScore, cpuScore;
        private Label hud;
        private const int PaddleH = 70;

        public PongGame()
        {
            Ui.EnableDoubleBuffer(this);
            TabStop = true;
            hud = new Label();
            hud.AutoSize = true;
            hud.Location = new Point(12, 8);
            Button back = Ui.MakeButton("Volver", false);
            back.SetBounds(12, 36, 100, 32);
            back.Click += delegate
            {
                StopGame();
                if (BackRequested != null) BackRequested(this, EventArgs.Empty);
            };
            Controls.Add(hud);
            Controls.Add(back);
            timer = new Timer();
            timer.Interval = 16;
            timer.Tick += delegate { Step(); };
            Paint += OnPaint;
            MouseMove += delegate(object s, MouseEventArgs e)
            {
                playerY = Math.Max(80, Math.Min(Height - PaddleH - 10, e.Y - PaddleH / 2f));
            };
            PreviewKeyDown += delegate(object s, PreviewKeyDownEventArgs e) { e.IsInputKey = true; };
            KeyDown += OnKey;
        }

        public void HandleKey(KeyEventArgs e)
        {
            OnKey(this, e);
        }

        private void OnKey(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up) playerY -= 24;
            if (e.KeyCode == Keys.Down) playerY += 24;
            if (e.KeyCode == Keys.Space) StartGame();
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = t.Bg;
            hud.ForeColor = t.Fg;
            foreach (Control c in Controls)
            {
                Button b = c as Button;
                if (b != null) { b.BackColor = t.Card; b.ForeColor = t.Fg; }
            }
        }

        public void StartGame()
        {
            playerScore = 0;
            cpuScore = 0;
            ResetBall(true);
            hud.Text = "Mueve el raton o flechas. 0 - 0";
            timer.Start();
            Focus();
        }

        public void StopGame()
        {
            timer.Stop();
        }

        private void ResetBall(bool toPlayer)
        {
            ballX = Width / 2f;
            ballY = Height / 2f;
            vx = toPlayer ? -5 : 5;
            vy = 4;
        }

        private void Step()
        {
            ballX += vx;
            ballY += vy;
            if (ballY < 80 || ballY > Height - 16) vy = -vy;
            float cpuTarget = ballY - PaddleH / 2f;
            cpuY += (cpuTarget - cpuY) * 0.09f;
            RectangleF player = new RectangleF(24, playerY, 12, PaddleH);
            RectangleF cpu = new RectangleF(Width - 40, cpuY, 12, PaddleH);
            RectangleF ball = new RectangleF(ballX, ballY, 12, 12);
            if (ball.IntersectsWith(player) && vx < 0) vx = Math.Abs(vx) + 0.3f;
            if (ball.IntersectsWith(cpu) && vx > 0) vx = -(Math.Abs(vx) + 0.3f);
            if (ballX < 0)
            {
                cpuScore++;
                ResetBall(false);
            }
            if (ballX > Width)
            {
                playerScore++;
                ResetBall(true);
            }
            hud.Text = string.Format("Tu {0}  -  CPU {1}", playerScore, cpuScore);
            Invalidate();
        }

        private void OnPaint(object sender, PaintEventArgs e)
        {
            Theme t = AppSettings.Current;
            using (SolidBrush br = new SolidBrush(t.Accent))
            using (SolidBrush fg = new SolidBrush(t.Fg))
            {
                e.Graphics.FillRectangle(fg, 24, playerY, 12, PaddleH);
                e.Graphics.FillRectangle(fg, Width - 40, cpuY, 12, PaddleH);
                e.Graphics.FillEllipse(br, ballX, ballY, 12, 12);
            }
        }
    }

    internal sealed class MemoryGame : Panel, IGamePage
    {
        public event EventHandler BackRequested;
        private readonly Button[] cards = new Button[16];
        private readonly int[] values = new int[16];
        private int first = -1;
        private int second = -1;
        private int found;
        private Label hud;
        private Timer hide;

        public MemoryGame()
        {
            Ui.EnableDoubleBuffer(this);
            hud = new Label();
            hud.AutoSize = true;
            hud.Location = new Point(12, 10);
            hud.Text = "Encuentra las parejas.";
            Button back = Ui.MakeButton("Volver", false);
            back.SetBounds(12, 36, 100, 32);
            back.Click += delegate
            {
                StopGame();
                if (BackRequested != null) BackRequested(this, EventArgs.Empty);
            };
            Controls.Add(hud);
            Controls.Add(back);
            for (int i = 0; i < 16; i++)
            {
                Button b = new Button();
                b.FlatStyle = FlatStyle.Flat;
                b.FlatAppearance.BorderSize = 0;
                b.Font = new Font("Segoe UI Semibold", 16f);
                b.Tag = i;
                int idx = i;
                b.Click += delegate { Flip(idx); };
                cards[i] = b;
                Controls.Add(b);
            }
            hide = new Timer();
            hide.Interval = 700;
            hide.Tick += delegate
            {
                hide.Stop();
                if (first >= 0 && second >= 0 && values[first] != values[second])
                {
                    cards[first].Text = "";
                    cards[second].Text = "";
                }
                first = -1;
                second = -1;
            };
            Resize += delegate { LayoutCards(); };
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            BackColor = t.Bg;
            hud.ForeColor = t.Fg;
            foreach (Control c in Controls)
            {
                Button b = c as Button;
                if (b != null)
                {
                    b.BackColor = t.Card;
                    b.ForeColor = t.Fg;
                }
            }
        }

        public void StartGame()
        {
            found = 0;
            first = -1;
            second = -1;
            int[] bag = new int[] { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7 };
            Random r = new Random();
            for (int i = bag.Length - 1; i > 0; i--)
            {
                int j = r.Next(i + 1);
                int tmp = bag[i];
                bag[i] = bag[j];
                bag[j] = tmp;
            }
            string[] glyphs = new string[] { "A", "B", "C", "D", "E", "F", "G", "H" };
            for (int i = 0; i < 16; i++)
            {
                values[i] = bag[i];
                cards[i].Text = "";
                cards[i].Enabled = true;
                cards[i].Tag = glyphs[bag[i]];
            }
            hud.Text = "Encuentra las parejas.";
            LayoutCards();
            ApplyTheme();
        }

        public void StopGame()
        {
            hide.Stop();
        }

        private void LayoutCards()
        {
            int startX = 20;
            int startY = 84;
            int gap = 10;
            int w = Math.Max(70, (Width - 50) / 4 - gap);
            int h = Math.Max(70, (Height - 110) / 4 - gap);
            for (int i = 0; i < 16; i++)
            {
                int col = i % 4;
                int row = i / 4;
                cards[i].SetBounds(startX + col * (w + gap), startY + row * (h + gap), w, h);
            }
        }

        private void Flip(int i)
        {
            if (first >= 0 && second >= 0) return;
            if (cards[i].Text != "") return;
            cards[i].Text = cards[i].Tag.ToString();
            if (first < 0) first = i;
            else
            {
                second = i;
                if (values[first] == values[second])
                {
                    found += 2;
                    cards[first].Enabled = false;
                    cards[second].Enabled = false;
                    first = -1;
                    second = -1;
                    if (found >= 16) hud.Text = "¡Completado!";
                    else hud.Text = "Parejas: " + (found / 2) + "/8";
                }
                else hide.Start();
            }
        }
    }
}
