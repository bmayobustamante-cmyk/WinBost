@echo off
setlocal
cd /d "%~dp0"
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo No se encontro el compilador de C# que incluye Windows.
  pause
  exit /b 1
)
set ICON=
if exist WinBoost.ico set ICON=/win32icon:WinBoost.ico
"%CSC%" /nologo /optimize+ /codepage:65001 /target:winexe /platform:anycpu /out:WinBoost.exe %ICON% /win32manifest:app.manifest /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Management.dll WinBoost.cs Studio.cs Core.cs Monitor.cs Perf.cs UiKit.cs GamingPanel.cs Pages.cs PerfPanel.cs
if errorlevel 1 (
  echo.
  echo Compilacion fallida. Copia el mensaje de error de arriba y enviaselo a quien te ayuda.
  pause
  exit /b 1
)
echo.
echo Listo: WinBoost.exe
endlocal
