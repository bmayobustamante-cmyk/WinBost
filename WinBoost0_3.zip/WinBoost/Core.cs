﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace WinBoost
{
    // ------------------------------------------------------------------
    // Utilidades base
    // ------------------------------------------------------------------

    internal static class Platform
    {
        public static bool IsWindows
        {
            get { return Environment.OSVersion.Platform == PlatformID.Win32NT; }
        }
    }

    internal enum OpResult
    {
        Completed,
        Skipped,
        Failed,
        NeedsPermission
    }

    internal static class OpText
    {
        public static string Label(OpResult r)
        {
            switch (r)
            {
                case OpResult.Completed: return "Completada";
                case OpResult.Skipped: return "Omitida";
                case OpResult.Failed: return "Fallida";
                default: return "Pendiente de permisos";
            }
        }

        // Tono semantico: ok / muted / bad / warn. La interfaz lo traduce a color segun el tema.
        public static string Tone(OpResult r)
        {
            switch (r)
            {
                case OpResult.Completed: return "ok";
                case OpResult.Skipped: return "muted";
                case OpResult.Failed: return "bad";
                default: return "warn";
            }
        }

        public static OpResult Parse(string s)
        {
            if (s == "Completed") return OpResult.Completed;
            if (s == "Skipped") return OpResult.Skipped;
            if (s == "Failed") return OpResult.Failed;
            return OpResult.NeedsPermission;
        }
    }

    internal static class Tsv
    {
        public static string Esc(string s)
        {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder(s.Length + 8);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '\\') sb.Append("\\\\");
                else if (c == '\t') sb.Append("\\t");
                else if (c == '\n') sb.Append("\\n");
                else if (c == '\r') { }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        public static string Unesc(string s)
        {
            if (s == null) return "";
            if (s.IndexOf('\\') < 0) return s;
            StringBuilder sb = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '\\' && i + 1 < s.Length)
                {
                    char n = s[i + 1];
                    if (n == 't') { sb.Append('\t'); i++; continue; }
                    if (n == 'n') { sb.Append('\n'); i++; continue; }
                    if (n == '\\') { sb.Append('\\'); i++; continue; }
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

        public static string Line(params string[] fields)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < fields.Length; i++)
            {
                if (i > 0) sb.Append('\t');
                sb.Append(Esc(fields[i]));
            }
            return sb.ToString();
        }

        public static string[] Split(string line)
        {
            string[] raw = line.Split('\t');
            for (int i = 0; i < raw.Length; i++) raw[i] = Unesc(raw[i]);
            return raw;
        }

        // Escritura casi atomica: archivo temporal + reemplazo.
        public static void WriteAllTextSafe(string path, string text)
        {
            string dir = Path.GetDirectoryName(path);
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            string tmp = path + ".tmp";
            File.WriteAllText(tmp, text, new UTF8Encoding(false));
            if (File.Exists(path))
            {
                try { File.Replace(tmp, path, null); }
                catch
                {
                    File.Delete(path);
                    File.Move(tmp, path);
                }
            }
            else File.Move(tmp, path);
        }
    }

    // ------------------------------------------------------------------
    // Registro local de operaciones
    // ------------------------------------------------------------------

    internal sealed class OpEntry
    {
        public DateTime Time;
        public string Operation;
        public string Requested;
        public OpResult Result;
        public string Detail;
        public string Previous;
        public string New;
    }

    internal static class OpLog
    {
        private static readonly object Sync = new object();
        private const long MaxBytes = 1024 * 1024;
        public static event EventHandler Changed;
        public static string LastError;

        public static string FilePath
        {
            get { return Path.Combine(AppSettings.Folder, "registro.tsv"); }
        }

        public static OpEntry Add(string operation, string requested, OpResult result, string detail, string previous, string newValue)
        {
            OpEntry e = new OpEntry();
            e.Time = DateTime.Now;
            e.Operation = operation ?? "";
            e.Requested = requested ?? "";
            e.Result = result;
            e.Detail = detail ?? "";
            e.Previous = previous ?? "";
            e.New = newValue ?? "";
            Append(e);
            EventHandler h = Changed;
            if (h != null)
            {
                try { h(null, EventArgs.Empty); }
                catch { }
            }
            return e;
        }

        private static void Append(OpEntry e)
        {
            try
            {
                lock (Sync)
                {
                    string path = FilePath;
                    string dir = Path.GetDirectoryName(path);
                    if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                    Rotate(path);
                    string line = Tsv.Line(
                        e.Time.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        e.Operation, e.Requested, e.Result.ToString(), e.Detail, e.Previous, e.New);
                    File.AppendAllText(path, line + "\n", new UTF8Encoding(false));
                    LastError = null;
                }
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }
        }

        private static void Rotate(string path)
        {
            try
            {
                FileInfo fi = new FileInfo(path);
                if (fi.Exists && fi.Length > MaxBytes)
                {
                    string old = Path.Combine(Path.GetDirectoryName(path), "registro.1.tsv");
                    if (File.Exists(old)) File.Delete(old);
                    File.Move(path, old);
                }
            }
            catch
            {
            }
        }

        public static List<OpEntry> ReadAll()
        {
            List<OpEntry> list = new List<OpEntry>();
            try
            {
                lock (Sync)
                {
                    string path = FilePath;
                    if (!File.Exists(path)) return list;
                    string[] lines = File.ReadAllLines(path, Encoding.UTF8);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (lines[i].Length == 0) continue;
                        string[] f = Tsv.Split(lines[i]);
                        if (f.Length < 7) continue;
                        OpEntry e = new OpEntry();
                        DateTime t;
                        if (!DateTime.TryParseExact(f[0], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out t)) continue;
                        e.Time = t;
                        e.Operation = f[1];
                        e.Requested = f[2];
                        e.Result = OpText.Parse(f[3]);
                        e.Detail = f[4];
                        e.Previous = f[5];
                        e.New = f[6];
                        list.Add(e);
                    }
                }
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }
            return list;
        }
    }

    // ------------------------------------------------------------------
    // Cambios aplicados por WinBoost que se pueden revertir
    // ------------------------------------------------------------------

    internal sealed class ChangeRecord
    {
        public string Id;
        public string Kind;      // "power" | "priority"
        public DateTime Time;
        public string Label;
        public string Previous;  // power: GUID anterior; priority: nombre de la prioridad anterior
        public string New;       // power: GUID nuevo;    priority: nombre de la prioridad nueva
        public int Pid;
        public long StartTicks;  // identifica el proceso aunque se reutilice el PID
        public string ProcName;
    }

    internal static class ChangeStore
    {
        private static readonly object Sync = new object();
        private static List<ChangeRecord> items;
        public static event EventHandler Changed;

        public static string FilePath
        {
            get { return Path.Combine(AppSettings.Folder, "cambios-activos.tsv"); }
        }

        public static void Reload()
        {
            lock (Sync) { items = null; }
        }

        private static void EnsureLoaded()
        {
            if (items != null) return;
            items = new List<ChangeRecord>();
            try
            {
                string path = FilePath;
                if (!File.Exists(path)) return;
                string[] lines = File.ReadAllLines(path, Encoding.UTF8);
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].Length == 0) continue;
                    string[] f = Tsv.Split(lines[i]);
                    if (f.Length < 9) continue;
                    ChangeRecord r = new ChangeRecord();
                    r.Id = f[0];
                    r.Kind = f[1];
                    DateTime t;
                    DateTime.TryParseExact(f[2], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out t);
                    r.Time = t;
                    r.Label = f[3];
                    r.Previous = f[4];
                    r.New = f[5];
                    int pid; int.TryParse(f[6], out pid); r.Pid = pid;
                    long ticks; long.TryParse(f[7], out ticks); r.StartTicks = ticks;
                    r.ProcName = f[8];
                    items.Add(r);
                }
            }
            catch
            {
            }
        }

        private static void Save()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < items.Count; i++)
            {
                ChangeRecord r = items[i];
                sb.Append(Tsv.Line(r.Id, r.Kind,
                    r.Time.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    r.Label, r.Previous, r.New,
                    r.Pid.ToString(CultureInfo.InvariantCulture),
                    r.StartTicks.ToString(CultureInfo.InvariantCulture),
                    r.ProcName));
                sb.Append('\n');
            }
            Tsv.WriteAllTextSafe(FilePath, sb.ToString());
        }

        public static List<ChangeRecord> All()
        {
            lock (Sync)
            {
                EnsureLoaded();
                return new List<ChangeRecord>(items);
            }
        }

        public static int Count
        {
            get { lock (Sync) { EnsureLoaded(); return items.Count; } }
        }

        public static bool Add(ChangeRecord r)
        {
            bool ok = true;
            lock (Sync)
            {
                EnsureLoaded();
                if (string.IsNullOrEmpty(r.Id)) r.Id = Guid.NewGuid().ToString("N").Substring(0, 12);
                if (r.Time == DateTime.MinValue) r.Time = DateTime.Now;
                items.Add(r);
                try { Save(); }
                catch { ok = false; }
            }
            Raise();
            return ok;
        }

        public static void Remove(string id)
        {
            lock (Sync)
            {
                EnsureLoaded();
                items.RemoveAll(delegate(ChangeRecord r) { return r.Id == id; });
                try { Save(); }
                catch { }
            }
            Raise();
        }

        private static void Raise()
        {
            EventHandler h = Changed;
            if (h != null)
            {
                try { h(null, EventArgs.Empty); }
                catch { }
            }
        }
    }

    // ------------------------------------------------------------------
    // Ejecucion de herramientas del sistema con tiempo límite
    // ------------------------------------------------------------------

    internal static class ProcRunner
    {
        public static Encoding OemEncoding()
        {
            try { return Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage); }
            catch { return null; }
        }

        public static bool Run(string file, string args, int timeoutMs, Encoding enc, out string stdout, out string stderr, out int exitCode)
        {
            stdout = "";
            stderr = "";
            exitCode = -1;
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = file;
                psi.Arguments = args;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                if (enc != null)
                {
                    psi.StandardOutputEncoding = enc;
                    psi.StandardErrorEncoding = enc;
                }
                StringBuilder so = new StringBuilder();
                StringBuilder se = new StringBuilder();
                using (Process p = new Process())
                {
                    p.StartInfo = psi;
                    p.OutputDataReceived += delegate(object s, DataReceivedEventArgs e)
                    {
                        if (e.Data != null) lock (so) { so.AppendLine(e.Data); }
                    };
                    p.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e)
                    {
                        if (e.Data != null) lock (se) { se.AppendLine(e.Data); }
                    };
                    p.Start();
                    p.BeginOutputReadLine();
                    p.BeginErrorReadLine();
                    if (!p.WaitForExit(timeoutMs))
                    {
                        // Solo se detiene la herramienta auxiliar que WinBoost acaba de lanzar (powercfg, nvidia-smi...).
                        try { p.Kill(); }
                        catch { }
                        lock (so) { stdout = so.ToString(); }
                        lock (se) { stderr = se.ToString(); }
                        return false;
                    }
                    p.WaitForExit();
                    exitCode = p.ExitCode;
                }
                lock (so) { stdout = so.ToString(); }
                lock (se) { stderr = se.ToString(); }
                return true;
            }
            catch (Exception ex)
            {
                stderr = ex.Message;
                return false;
            }
        }
    }

    // ------------------------------------------------------------------
    // Plan de energía (powercfg, sin tocar el registro)
    // ------------------------------------------------------------------

    internal sealed class PowerPlan
    {
        public string Guid;
        public string Name;
        public bool Active;
    }

    internal static class PowerService
    {
        public const string HighPerfGuid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c";
        public const string UltimateGuid = "e9a42b02-d5df-448d-aa00-03f14749eb61";

        private static readonly Regex GuidRx = new Regex(
            @"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})(?:\s*\(([^)]*)\))?\s*(\*)?",
            RegexOptions.Compiled);

        private static readonly Regex StrictGuid = new Regex(
            @"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", RegexOptions.Compiled);

        private static string Exe()
        {
            return Path.Combine(Environment.SystemDirectory, "powercfg.exe");
        }

        public static List<PowerPlan> ParseList(string output)
        {
            List<PowerPlan> plans = new List<PowerPlan>();
            if (string.IsNullOrEmpty(output)) return plans;
            string[] lines = output.Split(new char[] { '\n' });
            for (int i = 0; i < lines.Length; i++)
            {
                Match m = GuidRx.Match(lines[i]);
                if (!m.Success) continue;
                PowerPlan p = new PowerPlan();
                p.Guid = m.Groups[1].Value.ToLowerInvariant();
                p.Name = m.Groups[2].Success ? m.Groups[2].Value.Trim() : p.Guid;
                p.Active = m.Groups[3].Success;
                plans.Add(p);
            }
            return plans;
        }

        public static string ParseActiveGuid(string output)
        {
            if (string.IsNullOrEmpty(output)) return null;
            Match m = GuidRx.Match(output);
            if (!m.Success) return null;
            return m.Groups[1].Value.ToLowerInvariant();
        }

        public static bool IsGuid(string s)
        {
            return s != null && StrictGuid.IsMatch(s);
        }

        // Devuelve la lista de planes con el activo marcado. false si powercfg no responde.
        public static bool TryGetPlans(out List<PowerPlan> plans, out string error)
        {
            plans = new List<PowerPlan>();
            error = null;
            if (!Platform.IsWindows)
            {
                error = "La gestión del plan de energía solo existe en Windows.";
                return false;
            }
            string so, se; int code;
            Encoding enc = ProcRunner.OemEncoding();
            if (!ProcRunner.Run(Exe(), "/list", 6000, enc, out so, out se, out code) || code != 0)
            {
                error = "powercfg /list no respondió correctamente. " + (se ?? "").Trim();
                return false;
            }
            plans = ParseList(so);
            string so2, se2; int code2;
            string activeGuid = null;
            if (ProcRunner.Run(Exe(), "/getactivescheme", 6000, enc, out so2, out se2, out code2) && code2 == 0)
            {
                activeGuid = ParseActiveGuid(so2);
            }
            if (activeGuid != null)
            {
                for (int i = 0; i < plans.Count; i++) plans[i].Active = plans[i].Guid == activeGuid;
            }
            if (plans.Count == 0)
            {
                error = "No se pudo interpretar la lista de planes de energía.";
                return false;
            }
            return true;
        }

        public static OpResult SetActive(string guid, out string detail)
        {
            detail = "";
            if (!Platform.IsWindows) { detail = "Solo disponible en Windows."; return OpResult.Skipped; }
            if (!IsGuid(guid)) { detail = "Identificador de plan no válido."; return OpResult.Failed; }
            string so, se; int code;
            if (!ProcRunner.Run(Exe(), "/setactive " + guid, 8000, ProcRunner.OemEncoding(), out so, out se, out code))
            {
                detail = "powercfg no respondió a tiempo. " + (se ?? "").Trim();
                return OpResult.Failed;
            }
            if (code != 0)
            {
                string msg = ((se ?? "") + " " + (so ?? "")).Trim();
                detail = "powercfg devolvió el código " + code + ". " + msg;
                // Un código de acceso denegado suele indicar una directiva del sistema (p. ej. equipo gestionado).
                if (msg.ToLowerInvariant().IndexOf("acceso") >= 0 || msg.ToLowerInvariant().IndexOf("access") >= 0)
                    return OpResult.NeedsPermission;
                return OpResult.Failed;
            }
            // Verificación: leer de nuevo el plan activo.
            string so2, se2; int code2;
            if (ProcRunner.Run(Exe(), "/getactivescheme", 6000, ProcRunner.OemEncoding(), out so2, out se2, out code2) && code2 == 0)
            {
                string now = ParseActiveGuid(so2);
                if (now == guid.ToLowerInvariant()) { detail = "Plan activo verificado."; return OpResult.Completed; }
                detail = "powercfg aceptó el cambio pero el plan activo es otro; no se puede confirmar.";
                return OpResult.Failed;
            }
            detail = "Cambio enviado, pero no se pudo verificar el plan activo.";
            return OpResult.Completed;
        }

        public static bool OnBattery()
        {
            try
            {
                System.Windows.Forms.PowerStatus ps = System.Windows.Forms.SystemInformation.PowerStatus;
                bool hasBattery = (ps.BatteryChargeStatus & System.Windows.Forms.BatteryChargeStatus.NoSystemBattery) == 0
                    && ps.BatteryChargeStatus != System.Windows.Forms.BatteryChargeStatus.Unknown;
                return hasBattery && ps.PowerLineStatus == System.Windows.Forms.PowerLineStatus.Offline;
            }
            catch
            {
                return false;
            }
        }
    }

    // ------------------------------------------------------------------
    // Prioridad de proceso
    // ------------------------------------------------------------------

    internal static class PriorityService
    {
        public static string NameFromClass(uint c)
        {
            switch (c)
            {
                case 0x20: return "Normal";
                case 0x40: return "Idle";
                case 0x80: return "High";
                case 0x100: return "RealTime";
                case 0x4000: return "BelowNormal";
                case 0x8000: return "AboveNormal";
                default: return "";
            }
        }

        public static uint ClassFromName(string n)
        {
            switch (n)
            {
                case "Normal": return 0x20;
                case "Idle": return 0x40;
                case "High": return 0x80;
                case "RealTime": return 0x100;
                case "BelowNormal": return 0x4000;
                case "AboveNormal": return 0x8000;
                default: return 0;
            }
        }

        public static string Pretty(string n)
        {
            switch (n)
            {
                case "Normal": return "Normal";
                case "Idle": return "Baja";
                case "High": return "Alta";
                case "RealTime": return "Tiempo real";
                case "BelowNormal": return "Por debajo de lo normal";
                case "AboveNormal": return "Por encima de lo normal";
                default: return "desconocida";
            }
        }

        // Devuelve false si el proceso no se puede consultar (ya no existe o sin permisos de lectura).
        public static bool TryRead(int pid, out string priorityName, out long startTicks)
        {
            priorityName = "";
            startTicks = 0;
            if (!Platform.IsWindows) return false;
            IntPtr h = Native.OpenProcess(Native.QueryLimited, false, pid);
            if (h == IntPtr.Zero) return false;
            try
            {
                uint c = Native.GetPriorityClass(h);
                if (c == 0) return false;
                priorityName = NameFromClass(c);
                long creation, exit, kernel, user;
                if (!Native.GetProcessTimes(h, out creation, out exit, out kernel, out user)) return false;
                startTicks = DateTime.FromFileTimeUtc(creation).Ticks;
                return true;
            }
            finally
            {
                Native.CloseHandle(h);
            }
        }

        public static OpResult Set(int pid, long expectedStartTicks, string targetName, out string detail)
        {
            detail = "";
            if (!Platform.IsWindows) { detail = "Solo disponible en Windows."; return OpResult.Skipped; }
            uint target = ClassFromName(targetName);
            if (target == 0 || targetName == "High" || targetName == "RealTime")
            {
                detail = "WinBoost no aplica las prioridades Alta ni Tiempo real.";
                return OpResult.Skipped;
            }
            string current; long ticks;
            if (!TryRead(pid, out current, out ticks))
            {
                detail = "El proceso ya no existe o no se puede consultar.";
                return OpResult.Skipped;
            }
            if (expectedStartTicks != 0 && ticks != expectedStartTicks)
            {
                detail = "El PID ahora pertenece a otro proceso; no se modifica.";
                return OpResult.Skipped;
            }
            IntPtr h = Native.OpenProcess(Native.SetInfo | Native.QueryLimited, false, pid);
            if (h == IntPtr.Zero)
            {
                int err = System.Runtime.InteropServices.Marshal.GetLastWin32Error();
                if (err == 5)
                {
                    detail = "Windows denegó el acceso al proceso (puede estar protegido o ejecutarse como administrador).";
                    return OpResult.NeedsPermission;
                }
                detail = "No se pudo abrir el proceso (error " + err + "). Puede haberse cerrado.";
                return OpResult.Failed;
            }
            try
            {
                if (!Native.SetPriorityClass(h, target))
                {
                    int err = System.Runtime.InteropServices.Marshal.GetLastWin32Error();
                    detail = err == 5 ? "Acceso denegado al cambiar la prioridad." : "SetPriorityClass falló (error " + err + ").";
                    return err == 5 ? OpResult.NeedsPermission : OpResult.Failed;
                }
                uint now = Native.GetPriorityClass(h);
                if (now == target) { detail = "Prioridad verificada: " + Pretty(targetName) + "."; return OpResult.Completed; }
                detail = "Windows aceptó el cambio pero la prioridad leida es " + Pretty(NameFromClass(now)) + ".";
                return OpResult.Failed;
            }
            finally
            {
                Native.CloseHandle(h);
            }
        }
    }

    // ------------------------------------------------------------------
    // Elevación puntual: solo para cambiar la prioridad de UN proceso
    // ------------------------------------------------------------------

    internal static class Elevated
    {
        public const string Flag = "--set-priority";

        // Se ejecuta en el proceso auxiliar (sin interfaz). Devuelve el código de salida.
        public static int RunHelper(string[] args)
        {
            try
            {
                if (args.Length != 4) return 2;
                int pid; long ticks;
                if (!int.TryParse(args[1], out pid)) return 2;
                if (!long.TryParse(args[2], out ticks) || ticks == 0) return 2;
                string target = args[3];
                if (target != "Normal" && target != "AboveNormal" && target != "BelowNormal") return 2;
                string name = "";
                try
                {
                    using (Process p = Process.GetProcessById(pid)) { name = Classifier.SafeName(p); }
                }
                catch { return 3; }
                if (Classifier.IsProtectedName(name) || Classifier.IsAntiCheat(name)) return 4;
                string detail;
                OpResult r = PriorityService.Set(pid, ticks, target, out detail);
                if (r == OpResult.Completed) return 0;
                if (r == OpResult.Skipped) return 3;
                return 5;
            }
            catch
            {
                return 5;
            }
        }

        public static OpResult TrySetPriority(int pid, long startTicks, string target, out string detail)
        {
            detail = "";
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = Assembly.GetEntryAssembly().Location;
                psi.Arguments = Flag + " " + pid.ToString(CultureInfo.InvariantCulture) + " "
                    + startTicks.ToString(CultureInfo.InvariantCulture) + " " + target;
                psi.UseShellExecute = true;
                psi.Verb = "runas";
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                using (Process p = Process.Start(psi))
                {
                    if (p == null) { detail = "No se pudo iniciar el proceso auxiliar."; return OpResult.Failed; }
                    if (!p.WaitForExit(20000)) { detail = "El proceso auxiliar tardó demasiado."; return OpResult.Failed; }
                    switch (p.ExitCode)
                    {
                        case 0: detail = "Cambio aplicado con permisos de administrador solo para este proceso."; return OpResult.Completed;
                        case 3: detail = "El proceso ya no existe o cambio; no se modifica."; return OpResult.Skipped;
                        case 4: detail = "Proceso protegido: WinBoost no lo modifica."; return OpResult.Skipped;
                        default: detail = "El proceso auxiliar no pudo completar el cambio (código " + p.ExitCode + ")."; return OpResult.Failed;
                    }
                }
            }
            catch (Win32Exception ex)
            {
                if (ex.NativeErrorCode == 1223)
                {
                    detail = "Elevación cancelada en el aviso de Windows (UAC). No se hizo ningún cambio.";
                    return OpResult.NeedsPermission;
                }
                detail = "No se pudo solicitar permisos: " + ex.Message;
                return OpResult.Failed;
            }
            catch (Exception ex)
            {
                detail = "No se pudo solicitar permisos: " + ex.Message;
                return OpResult.Failed;
            }
        }
    }

    // ------------------------------------------------------------------
    // Modo juego: análisis, activacion y restauración
    // ------------------------------------------------------------------

    internal sealed class GameCandidate
    {
        public int Pid;
        public string Name;
        public string Title;
        public long StartTicks;
        public string CurrentPriority;
        public bool Selectable;
        public string Reason;
    }

    internal sealed class Optimization
    {
        public string Id;
        public string Name;
        public string Description;
        public string Risk;
        public bool Available;
        public bool AlreadyActive;
        public string StatusText;
        public bool DefaultSelected;
        // Plan de energía
        public string TargetGuid;
        public string TargetName;
        public string CurrentGuid;
        public string CurrentName;
    }

    internal sealed class Analysis
    {
        public Optimization Power = new Optimization();
        public Optimization Priority = new Optimization();
        public List<GameCandidate> Games = new List<GameCandidate>();
    }

    internal sealed class PendingElevation
    {
        public int Pid;
        public long StartTicks;
        public string ProcName;
        public string Target;     // prioridad que se quiere dejar
        public string Previous;   // prioridad que había
        public string RecordId;   // si viene de una restauración, id del registro a cerrar
        public string Label;
    }

    internal static class GameModeService
    {
        public const string PriorityTarget = "AboveNormal";

        public static bool IsActive
        {
            get { return ChangeStore.Count > 0; }
        }

        public static Analysis Analyze()
        {
            Analysis a = new Analysis();
            AnalyzePower(a.Power);
            AnalyzePriority(a);
            return a;
        }

        private static void AnalyzePower(Optimization o)
        {
            o.Id = "power";
            o.Name = "Plan de energía de alto rendimiento";
            o.Description = "Cambia el plan de energía activo a uno de alto rendimiento que ya exista en Windows. WinBoost no crea planes nuevos ni toca el registro.";
            o.Risk = "Más consumo y más calor, sobre todo en portátiles. Se restaura al plan anterior al desactivar el modo juego. Mejora no garantizada: depende del equipo.";
            o.DefaultSelected = false;
            if (!Platform.IsWindows)
            {
                o.StatusText = "No disponible: solo funciona en Windows.";
                return;
            }
            List<PowerPlan> plans; string err;
            if (!PowerService.TryGetPlans(out plans, out err))
            {
                o.StatusText = "No disponible: " + err;
                return;
            }
            PowerPlan cur = plans.Find(delegate(PowerPlan p) { return p.Active; });
            if (cur == null)
            {
                o.StatusText = "No disponible: no se pudo determinar el plan actual y, sin el, no se podría restaurar.";
                return;
            }
            o.CurrentGuid = cur.Guid;
            o.CurrentName = cur.Name;
            if (cur.Guid == PowerService.HighPerfGuid || cur.Guid == PowerService.UltimateGuid)
            {
                o.AlreadyActive = true;
                o.StatusText = "Omitida: ya está activo un plan de alto rendimiento (" + cur.Name + ").";
                return;
            }
            PowerPlan target = plans.Find(delegate(PowerPlan p) { return p.Guid == PowerService.HighPerfGuid; });
            if (target == null) target = plans.Find(delegate(PowerPlan p) { return p.Guid == PowerService.UltimateGuid; });
            if (target == null)
            {
                o.StatusText = "No disponible: este equipo no expone un plan de alto rendimiento. WinBoost no lo crea.";
                return;
            }
            if (PowerService.OnBattery())
            {
                o.StatusText = "No disponible: el equipo funciona con batería. Conecta el cargador y vuelve a analizar.";
                return;
            }
            o.TargetGuid = target.Guid;
            o.TargetName = target.Name;
            o.Available = true;
            o.StatusText = "Disponible: " + cur.Name + " -> " + target.Name;
        }

        private static void AnalyzePriority(Analysis a)
        {
            Optimization o = a.Priority;
            o.Id = "priority";
            o.Name = "Prioridad de los juegos detectados";
            o.Description = "Sube la prioridad de los juegos que marques a \"" + PriorityService.Pretty(PriorityTarget) + "\" (no a Alta). Solo toca los juegos que elijas de la lista, nunca procesos del sistema ni antitrampas.";
            o.Risk = "Una prioridad mayor no garantiza más FPS y puede restar tiempo de CPU a audio, red o grabación. Se restaura al desactivar el modo juego (y Windows la restablece sola al cerrar el juego).";
            o.DefaultSelected = false;
            if (!Platform.IsWindows)
            {
                o.StatusText = "No disponible: solo funciona en Windows.";
                return;
            }
            Process[] all = null;
            try
            {
                all = Process.GetProcesses();
                HashSet<int> games = Classifier.DetectGamePids(all);
                int self = Process.GetCurrentProcess().Id;
                List<string> anti = new List<string>();
                for (int i = 0; i < all.Length; i++)
                {
                    Process p = all[i];
                    string name = Classifier.SafeName(p);
                    if (Classifier.IsAntiCheat(name) && !anti.Contains(name)) anti.Add(name);
                    if (!games.Contains(p.Id) || p.Id == self) continue;
                    GameCandidate g = new GameCandidate();
                    g.Pid = p.Id;
                    g.Name = p.ProcessName + ".exe";
                    g.Title = "";
                    string cur; long ticks;
                    if (!PriorityService.TryRead(p.Id, out cur, out ticks))
                    {
                        g.Selectable = false;
                        g.Reason = "no se puede consultar este proceso";
                    }
                    else
                    {
                        g.StartTicks = ticks;
                        g.CurrentPriority = cur;
                        if (cur != "Normal")
                        {
                            g.Selectable = false;
                            g.Reason = "ya tiene prioridad " + PriorityService.Pretty(cur) + "; no se modifica";
                        }
                        else g.Selectable = true;
                    }
                    a.Games.Add(g);
                }
                if (a.Games.Count == 0)
                {
                    o.StatusText = "No disponible: no se detectó ningún juego en ejecución. Abre el juego y pulsa Analizar.";
                    return;
                }
                if (anti.Count > 0)
                {
                    o.StatusText = "No disponible: se detectó software antitrampas (" + string.Join(", ", anti.ToArray()) + "). WinBoost no toca juegos protegidos.";
                    for (int i = 0; i < a.Games.Count; i++)
                    {
                        a.Games[i].Selectable = false;
                        a.Games[i].Reason = "antitrampas activo";
                    }
                    return;
                }
                bool any = a.Games.Exists(delegate(GameCandidate g) { return g.Selectable; });
                if (!any)
                {
                    o.StatusText = "Omitida: ningún juego detectado admite el cambio.";
                    return;
                }
                o.Available = true;
                o.StatusText = "Disponible: " + a.Games.Count + " juego(s) detectado(s). Marca los que quieras.";
            }
            catch (Exception ex)
            {
                o.StatusText = "No disponible: error al analizar procesos (" + ex.Message + ").";
            }
            finally
            {
                if (all != null)
                {
                    for (int i = 0; i < all.Length; i++) all[i].Dispose();
                }
            }
        }

        // ---------------- Activacion ----------------

        public static List<OpEntry> Activate(Optimization power, bool wantPower, List<GameCandidate> games, List<PendingElevation> pending)
        {
            List<OpEntry> res = new List<OpEntry>();
            if (IsActive)
            {
                res.Add(OpLog.Add("Modo juego", "Activar modo juego", OpResult.Skipped,
                    "El modo juego ya está activado; no se repiten los cambios. Desactivalo primero para volver a aplicarlo.", "", ""));
                return res;
            }
            if (!wantPower && (games == null || games.Count == 0))
            {
                res.Add(OpLog.Add("Modo juego", "Activar modo juego", OpResult.Skipped,
                    "No había ninguna optimización seleccionada.", "", ""));
                return res;
            }
            if (wantPower) res.Add(ApplyPower(power));
            if (games != null)
            {
                for (int i = 0; i < games.Count; i++) res.Add(ApplyPriority(games[i], pending));
            }
            int ok = 0, fail = 0, perm = 0, skip = 0;
            for (int i = 0; i < res.Count; i++)
            {
                switch (res[i].Result)
                {
                    case OpResult.Completed: ok++; break;
                    case OpResult.Failed: fail++; break;
                    case OpResult.NeedsPermission: perm++; break;
                    default: skip++; break;
                }
            }
            OpResult overall = ok > 0 ? OpResult.Completed : (perm > 0 ? OpResult.NeedsPermission : (fail > 0 ? OpResult.Failed : OpResult.Skipped));
            res.Add(OpLog.Add("Modo juego", "Activar modo juego", overall,
                string.Format("Completadas: {0}. Omitidas: {1}. Fallidas: {2}. Pendientes de permisos: {3}.", ok, skip, fail, perm), "", ""));
            return res;
        }

        private static OpEntry ApplyPower(Optimization o)
        {
            const string op = "Plan de energía";
            if (o == null || string.IsNullOrEmpty(o.TargetGuid))
                return OpLog.Add(op, "Cambiar a alto rendimiento", OpResult.Skipped, "Optimización no disponible en este equipo.", "", "");
            List<PowerPlan> plans; string err;
            if (!PowerService.TryGetPlans(out plans, out err))
                return OpLog.Add(op, "Cambiar a alto rendimiento", OpResult.Failed, err, "", "");
            PowerPlan cur = plans.Find(delegate(PowerPlan p) { return p.Active; });
            PowerPlan target = plans.Find(delegate(PowerPlan p) { return p.Guid == o.TargetGuid; });
            if (cur == null)
                return OpLog.Add(op, "Cambiar a alto rendimiento", OpResult.Skipped, "No se pudo leer el plan actual; sin el no se podría restaurar.", "", "");
            if (target == null)
                return OpLog.Add(op, "Cambiar a alto rendimiento", OpResult.Skipped, "El plan de destino ya no está disponible.", cur.Name + " (" + cur.Guid + ")", "");
            if (cur.Guid == target.Guid)
                return OpLog.Add(op, "Cambiar a " + target.Name, OpResult.Skipped, "Ese plan ya estaba activo.", cur.Name + " (" + cur.Guid + ")", target.Name + " (" + target.Guid + ")");
            string detail;
            OpResult r = PowerService.SetActive(target.Guid, out detail);
            string prev = cur.Name + " (" + cur.Guid + ")";
            string nw = target.Name + " (" + target.Guid + ")";
            if (r == OpResult.Completed)
            {
                ChangeRecord rec = new ChangeRecord();
                rec.Kind = "power";
                rec.Label = "Plan de energía: " + cur.Name + " -> " + target.Name;
                rec.Previous = cur.Guid;
                rec.New = target.Guid;
                rec.ProcName = target.Name + "|" + cur.Name;
                if (!ChangeStore.Add(rec)) detail += " Aviso: no se pudo guardar el punto de restauración en disco.";
            }
            return OpLog.Add(op, "Cambiar a " + target.Name, r, detail, prev, nw);
        }

        private static OpEntry ApplyPriority(GameCandidate g, List<PendingElevation> pending)
        {
            const string op = "Prioridad de juego";
            string req = "Prioridad de " + g.Name + " (PID " + g.Pid + ") a " + PriorityService.Pretty(PriorityTarget);
            string cur; long ticks;
            if (!PriorityService.TryRead(g.Pid, out cur, out ticks))
                return OpLog.Add(op, req, OpResult.Skipped, "El proceso ya no existe o no se puede consultar.", "", "");
            if (g.StartTicks != 0 && ticks != g.StartTicks)
                return OpLog.Add(op, req, OpResult.Skipped, "El PID ahora pertenece a otro proceso; no se modifica.", "", "");
            if (cur != "Normal")
                return OpLog.Add(op, req, OpResult.Skipped, "Ya tiene prioridad " + PriorityService.Pretty(cur) + "; no se modifica.", PriorityService.Pretty(cur), "");
            string detail;
            OpResult r = PriorityService.Set(g.Pid, ticks, PriorityTarget, out detail);
            if (r == OpResult.Completed)
            {
                AddPriorityRecord(g.Pid, ticks, g.Name, "Normal", PriorityTarget);
            }
            else if (r == OpResult.NeedsPermission && pending != null)
            {
                PendingElevation pe = new PendingElevation();
                pe.Pid = g.Pid; pe.StartTicks = ticks; pe.ProcName = g.Name;
                pe.Target = PriorityTarget; pe.Previous = "Normal";
                pe.Label = req;
                pending.Add(pe);
            }
            return OpLog.Add(op, req, r, detail, PriorityService.Pretty("Normal"), r == OpResult.Completed ? PriorityService.Pretty(PriorityTarget) : "");
        }

        private static void AddPriorityRecord(int pid, long ticks, string name, string prev, string nw)
        {
            ChangeRecord rec = new ChangeRecord();
            rec.Kind = "priority";
            rec.Pid = pid;
            rec.StartTicks = ticks;
            rec.ProcName = name;
            rec.Previous = prev;
            rec.New = nw;
            rec.Label = "Prioridad de " + name + " (PID " + pid + "): " + PriorityService.Pretty(prev) + " -> " + PriorityService.Pretty(nw);
            ChangeStore.Add(rec);
        }

        // Reintento con permisos de administrador para procesos concretos (activacion).
        public static List<OpEntry> RetryElevated(List<PendingElevation> items)
        {
            List<OpEntry> res = new List<OpEntry>();
            for (int i = 0; i < items.Count; i++)
            {
                PendingElevation pe = items[i];
                string detail;
                OpResult r = Elevated.TrySetPriority(pe.Pid, pe.StartTicks, pe.Target, out detail);
                if (r == OpResult.Completed)
                {
                    if (string.IsNullOrEmpty(pe.RecordId)) AddPriorityRecord(pe.Pid, pe.StartTicks, pe.ProcName, pe.Previous, pe.Target);
                    else ChangeStore.Remove(pe.RecordId);
                }
                res.Add(OpLog.Add("Prioridad de juego", (pe.Label ?? "") + " (con administrador)", r, detail,
                    PriorityService.Pretty(pe.Previous), r == OpResult.Completed ? PriorityService.Pretty(pe.Target) : ""));
            }
            return res;
        }

        // ---------------- Restauración ----------------

        public static List<OpEntry> Deactivate(List<PendingElevation> pending)
        {
            List<OpEntry> res = new List<OpEntry>();
            List<ChangeRecord> all = ChangeStore.All();
            if (all.Count == 0)
            {
                res.Add(OpLog.Add("Modo juego", "Desactivar modo juego", OpResult.Skipped, "No había cambios de WinBoost que restaurar.", "", ""));
                return res;
            }
            // Orden inverso: se deshace lo ultimo primero.
            for (int i = all.Count - 1; i >= 0; i--) res.Add(RevertRecord(all[i], pending));
            int ok = 0, bad = 0;
            for (int i = 0; i < res.Count; i++)
            {
                if (res[i].Result == OpResult.Completed || res[i].Result == OpResult.Skipped) ok++;
                else bad++;
            }
            res.Add(OpLog.Add("Modo juego", "Desactivar modo juego", bad == 0 ? OpResult.Completed : OpResult.Failed,
                string.Format("Restauraciones resueltas: {0}. Pendientes o fallidas: {1}.", ok, bad), "", ""));
            return res;
        }

        public static OpEntry RevertRecord(ChangeRecord r, List<PendingElevation> pending)
        {
            if (r.Kind == "power") return RevertPower(r);
            if (r.Kind == "priority") return RevertPriority(r, pending);
            ChangeStore.Remove(r.Id);
            return OpLog.Add("Restauración", r.Label, OpResult.Skipped, "Tipo de cambio desconocido; se descarta el registro.", "", "");
        }

        private static OpEntry RevertPower(ChangeRecord r)
        {
            const string op = "Restaurar plan de energía";
            List<PowerPlan> plans; string err;
            if (!PowerService.TryGetPlans(out plans, out err))
                return OpLog.Add(op, r.Label, OpResult.Failed, err + " El cambio sigue pendiente de restaurar.", "", "");
            PowerPlan cur = plans.Find(delegate(PowerPlan p) { return p.Active; });
            PowerPlan prev = plans.Find(delegate(PowerPlan p) { return p.Guid == r.Previous; });
            if (cur != null && cur.Guid == r.Previous)
            {
                ChangeStore.Remove(r.Id);
                return OpLog.Add(op, r.Label, OpResult.Skipped, "El plan anterior ya estaba activo.", "", cur.Name);
            }
            if (cur != null && cur.Guid != r.New)
            {
                ChangeStore.Remove(r.Id);
                return OpLog.Add(op, r.Label, OpResult.Skipped, "El plan activo ya no es el que aplico WinBoost (" + cur.Name + "); no se modifica.", cur.Name, "");
            }
            if (prev == null)
            {
                ChangeStore.Remove(r.Id);
                return OpLog.Add(op, r.Label, OpResult.Failed, "El plan anterior ya no existe en Windows; no se puede restaurar automáticamente. Elige un plan en Configuración > Sistema > Inicio/apagado y suspensión.", "", "");
            }
            string detail;
            OpResult res = PowerService.SetActive(prev.Guid, out detail);
            if (res == OpResult.Completed) ChangeStore.Remove(r.Id);
            return OpLog.Add(op, r.Label, res, detail, cur != null ? cur.Name : "", prev.Name);
        }

        private static OpEntry RevertPriority(ChangeRecord r, List<PendingElevation> pending)
        {
            const string op = "Restaurar prioridad";
            string cur; long ticks;
            if (!PriorityService.TryRead(r.Pid, out cur, out ticks) || ticks != r.StartTicks)
            {
                ChangeStore.Remove(r.Id);
                return OpLog.Add(op, r.Label, OpResult.Skipped, "El proceso ya no existe; Windows restablece la prioridad al cerrarse.", "", "");
            }
            if (cur != r.New)
            {
                ChangeStore.Remove(r.Id);
                return OpLog.Add(op, r.Label, OpResult.Skipped, "La prioridad ya fue cambiada por otro medio (" + PriorityService.Pretty(cur) + "); no se modifica.", "", "");
            }
            string detail;
            OpResult res = PriorityService.Set(r.Pid, r.StartTicks, r.Previous, out detail);
            if (res == OpResult.Completed || res == OpResult.Skipped) ChangeStore.Remove(r.Id);
            else if (res == OpResult.NeedsPermission && pending != null)
            {
                PendingElevation pe = new PendingElevation();
                pe.Pid = r.Pid; pe.StartTicks = r.StartTicks; pe.ProcName = r.ProcName;
                pe.Target = r.Previous; pe.Previous = r.New; pe.RecordId = r.Id;
                pe.Label = "Restaurar " + r.Label;
                pending.Add(pe);
            }
            return OpLog.Add(op, r.Label, res, detail, PriorityService.Pretty(r.New), res == OpResult.Completed ? PriorityService.Pretty(r.Previous) : "");
        }
    }

    // ------------------------------------------------------------------
    // Cierre OPCIONAL de aplicaciones, siempre con confirmacion del usuario
    // ------------------------------------------------------------------

    internal sealed class AppCandidate
    {
        public int Pid;
        public string Name;
        public string Title;
        public long MemoryBytes;
    }

    internal static class AppCloser
    {
        // Solo aplicaciones con ventana visible, de la sesion del usuario, que no sean
        // juegos, soporte de juegos, antitrampas, componentes de Windows ni WinBoost.
        public static List<AppCandidate> FindCandidates()
        {
            List<AppCandidate> list = new List<AppCandidate>();
            if (!Platform.IsWindows) return list;
            Process[] all = Process.GetProcesses();
            try
            {
                int self = Process.GetCurrentProcess().Id;
                int mySession = Process.GetCurrentProcess().SessionId;
                HashSet<int> games = Classifier.DetectGamePids(all);
                Dictionary<uint, List<IntPtr>> windows = Classifier.SnapshotWindows();
                for (int i = 0; i < all.Length; i++)
                {
                    Process p = all[i];
                    try
                    {
                        if (p.Id == self || p.SessionId != mySession || p.SessionId == 0) continue;
                        string title = Classifier.WindowTitle(p.Id, windows);
                        if (string.IsNullOrEmpty(title)) continue;
                        string name = Classifier.SafeName(p);
                        ProcessKind kind = Classifier.Classify(p, self, games);
                        bool discord = name == "discord" || name == "discordptb" || name == "discordcanary";
                        if (kind != ProcessKind.Other && !discord) continue;
                        if (Classifier.IsProtectedName(name) || Classifier.IsAntiCheat(name)) continue;
                        AppCandidate c = new AppCandidate();
                        c.Pid = p.Id;
                        c.Name = p.ProcessName + ".exe";
                        c.Title = title;
                        try { c.MemoryBytes = p.WorkingSet64; }
                        catch { }
                        list.Add(c);
                    }
                    catch
                    {
                    }
                }
            }
            finally
            {
                for (int i = 0; i < all.Length; i++) all[i].Dispose();
            }
            list.Sort(delegate(AppCandidate a, AppCandidate b) { return b.MemoryBytes.CompareTo(a.MemoryBytes); });
            return list;
        }

        // Cierre amable (CloseMainWindow): la aplicación puede pedir guardar. Nunca se fuerza.
        public static OpEntry CloseOne(AppCandidate c)
        {
            const string op = "Cierre de aplicación";
            string req = "Cerrar " + c.Name + " (PID " + c.Pid + ") - \"" + c.Title + "\"";
            try
            {
                using (Process p = Process.GetProcessById(c.Pid))
                {
                    if (p.HasExited) return OpLog.Add(op, req, OpResult.Skipped, "La aplicación ya estaba cerrada.", "", "");
                    if (!p.CloseMainWindow())
                        return OpLog.Add(op, req, OpResult.Failed, "La aplicación no aceptó la petición de cierre. WinBoost no fuerza el cierre.", "", "");
                    if (p.WaitForExit(6000))
                        return OpLog.Add(op, req, OpResult.Completed, "Aplicación cerrada. Este cierre no se puede deshacer desde WinBoost.", "", "");
                    return OpLog.Add(op, req, OpResult.Failed, "La aplicación sigue abierta (puede estar pidiendo guardar cambios o no responder). WinBoost no fuerza el cierre.", "", "");
                }
            }
            catch (ArgumentException)
            {
                return OpLog.Add(op, req, OpResult.Skipped, "El proceso ya no existe.", "", "");
            }
            catch (Exception ex)
            {
                return OpLog.Add(op, req, OpResult.Failed, ex.Message, "", "");
            }
        }
    }
}
