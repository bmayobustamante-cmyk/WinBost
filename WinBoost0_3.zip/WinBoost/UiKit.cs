﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WinBoost
{
    internal static class Skin
    {
        private static readonly Font HeaderFont = new Font("Segoe UI Semibold", 9f);

        public static Color ToneColor(string tone)
        {
            Theme t = AppSettings.Current;
            switch (tone)
            {
                case "ok": return Color.FromArgb(74, 222, 128);
                case "warn": return Color.FromArgb(251, 146, 60);
                case "bad": return t.Danger;
                case "muted": return t.Muted;
                case "accent": return t.Accent;
                default: return t.Fg;
            }
        }

        public static Label Lbl(string text, float size, bool bold, string tone)
        {
            Label l = new Label();
            l.Text = text;
            l.AutoSize = false;
            l.Font = new Font(bold ? "Segoe UI Semibold" : "Segoe UI", size);
            l.Tag = tone;
            return l;
        }

        public static Button Btn(string text, bool primary)
        {
            Button b = Ui.MakeButton(text, primary);
            b.Tag = primary ? "primary" : "";
            return b;
        }

        public static int FitHeight(Control c, int width)
        {
            Size s = TextRenderer.MeasureText(c.Text, c.Font, new Size(Math.Max(20, width), 0),
                TextFormatFlags.WordBreak | TextFormatFlags.NoPadding);
            return s.Height + 4;
        }

        // Coloca una etiqueta con ajuste de linea y devuelve la siguiente coordenada Y.
        public static int Place(Label l, int x, int y, int w)
        {
            int h = FitHeight(l, w);
            l.SetBounds(x, y, w, h);
            return y + h + 4;
        }

        public static void Apply(Control root)
        {
            Theme t = AppSettings.Current;
            ApplyOne(root, t, true);
            ApplyChildren(root, t);
        }

        private static void ApplyChildren(Control parent, Theme t)
        {
            foreach (Control c in parent.Controls)
            {
                ApplyOne(c, t, false);
                ApplyChildren(c, t);
            }
        }

        private static void ApplyOne(Control c, Theme t, bool isRoot)
        {
            string tag = c.Tag as string;
            Label lb = c as Label;
            if (lb != null)
            {
                lb.BackColor = Color.Transparent;
                lb.ForeColor = ToneColor(string.IsNullOrEmpty(tag) ? "" : tag);
                return;
            }
            CheckBox cb = c as CheckBox;
            if (cb != null)
            {
                cb.BackColor = Color.Transparent;
                cb.ForeColor = cb.Enabled ? t.Fg : t.Muted;
                return;
            }
            Button b = c as Button;
            if (b != null)
            {
                bool primary = tag == "primary";
                b.BackColor = primary ? t.Accent : Color.FromArgb(70, t.Fg);
                b.ForeColor = primary ? Ui.Contrast(t.Accent) : t.Fg;
                return;
            }
            ListView lv = c as ListView;
            if (lv != null)
            {
                lv.BackColor = t.Card;
                lv.ForeColor = t.Fg;
                lv.Invalidate();
                return;
            }
            TextBox tb = c as TextBox;
            if (tb != null)
            {
                tb.BackColor = t.Card;
                tb.ForeColor = t.Fg;
                return;
            }
            ComboBox cmb = c as ComboBox;
            if (cmb != null)
            {
                cmb.BackColor = t.Card;
                cmb.ForeColor = t.Fg;
                return;
            }
            MeterCard mc = c as MeterCard;
            if (mc != null) { mc.Invalidate(); return; }
            if (c is Panel || c is TableLayoutPanel)
            {
                if (isRoot) c.BackColor = t.Bg;
                else if (tag == "card") c.BackColor = t.Card;
                else if (tag == "bar") c.BackColor = t.Sidebar;
                else if (tag == "bg") c.BackColor = t.Bg;
                else c.BackColor = Color.Transparent;
                return;
            }
            if (c is PictureBox) return;
        }

        // Lista con dibujo propio que respeta el tema. El color de cada celda se decide por SubItem.Tag
        // ("ok", "warn", "bad", "muted", "accent" o un Color).
        public static ListView NewList()
        {
            ListView list = new ListView();
            list.View = View.Details;
            list.FullRowSelect = true;
            list.BorderStyle = BorderStyle.None;
            list.OwnerDraw = true;
            list.HideSelection = false;
            list.UseCompatibleStateImageBehavior = false;
            list.DrawColumnHeader += DrawHeader;
            list.DrawItem += delegate(object s, DrawListViewItemEventArgs e) { e.DrawDefault = false; };
            list.DrawSubItem += DrawSub;
            Ui.EnableDoubleBuffer(list);
            list.Resize += delegate { StretchLast(list); };
            return list;
        }

        // La ultima columna rellena el ancho disponible (si no, la cabecera dibujada a mano deja un hueco claro).
        public static void StretchLast(ListView lv)
        {
            if (lv.Columns.Count == 0) return;
            int used = 0;
            for (int i = 0; i < lv.Columns.Count - 1; i++) used += lv.Columns[i].Width;
            ColumnHeader last = lv.Columns[lv.Columns.Count - 1];
            if (!(last.Tag is int)) last.Tag = last.Width;
            int w = Math.Max((int)last.Tag, lv.ClientSize.Width - used - 2);
            if (last.Width != w) last.Width = w;
        }

        public static void AddRow(ListView list, string[] cells, object[] tones)
        {
            ListViewItem it = new ListViewItem(cells[0]);
            it.UseItemStyleForSubItems = false;
            it.SubItems[0].Tag = tones != null && tones.Length > 0 ? tones[0] : "";
            for (int i = 1; i < cells.Length; i++)
            {
                ListViewItem.ListViewSubItem si = it.SubItems.Add(cells[i]);
                si.Tag = tones != null && tones.Length > i ? tones[i] : "";
            }
            list.Items.Add(it);
        }

        private static void DrawHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            Theme t = AppSettings.Current;
            using (SolidBrush brush = new SolidBrush(t.Sidebar))
            {
                e.Graphics.FillRectangle(brush, e.Bounds);
            }
            TextRenderer.DrawText(e.Graphics, e.Header.Text, HeaderFont, e.Bounds, t.Muted,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }

        private static void DrawSub(object sender, DrawListViewSubItemEventArgs e)
        {
            Theme t = AppSettings.Current;
            Color back = (e.ItemIndex % 2 == 0) ? t.Card : t.Bg;
            if (e.Item.Selected) back = Color.FromArgb(80, t.Accent);
            using (SolidBrush brush = new SolidBrush(back))
            {
                e.Graphics.FillRectangle(brush, e.Bounds);
            }
            Color color = t.Fg;
            object tag = e.SubItem.Tag;
            if (tag is string) color = ToneColor((string)tag);
            else if (tag is Color) color = (Color)tag;
            TextRenderer.DrawText(e.Graphics, e.SubItem.Text, ((ListView)sender).Font, e.Bounds, color,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }
    }

    // Tarjeta de metrica dibujada a mano: sin hijos, sin animaciones, se adapta al tamano.
    internal sealed class MeterCard : Panel
    {
        private static readonly Font CapFont = new Font("Segoe UI", 9f);
        private static readonly Font ValFont = new Font("Segoe UI Semibold", 20f);
        private static readonly Font SubFont = new Font("Segoe UI", 8.5f);

        private string caption = "";
        private string value = "--";
        private string sub = "";
        private double percent = -1;
        private string tone = "";

        public MeterCard(string cap)
        {
            caption = cap;
            Ui.EnableDoubleBuffer(this);
            Tag = "card";
        }

        public void SetValues(string v, string s, double pct, string toneName)
        {
            if (v == value && s == sub && pct == percent && toneName == tone) return;
            value = v; sub = s; percent = pct; tone = toneName ?? "";
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme t = AppSettings.Current;
            Graphics g = e.Graphics;
            using (SolidBrush b = new SolidBrush(t.Card)) g.FillRectangle(b, ClientRectangle);
            int w = ClientSize.Width;
            int h = ClientSize.Height;
            TextRenderer.DrawText(g, caption, CapFont, new Rectangle(12, 8, w - 24, 20), t.Muted,
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            Color vc = string.IsNullOrEmpty(tone) ? t.Fg : Skin.ToneColor(tone);
            TextRenderer.DrawText(g, value, ValFont, new Rectangle(12, 28, w - 24, 38), vc,
                TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.VerticalCenter);
            int barH = percent >= 0 ? 6 : 0;
            int subTop = 66;
            int subH = Math.Max(14, h - subTop - barH - 12);
            TextRenderer.DrawText(g, sub, SubFont, new Rectangle(12, subTop, w - 24, subH), t.Muted,
                TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
            if (percent >= 0)
            {
                Rectangle track = new Rectangle(12, h - 12, w - 24, barH);
                using (SolidBrush tb = new SolidBrush(Color.FromArgb(50, t.Fg))) g.FillRectangle(tb, track);
                int fw = (int)Math.Round(track.Width * Math.Max(0, Math.Min(100, percent)) / 100.0);
                Color fc = percent >= 90 ? Skin.ToneColor("warn") : t.Accent;
                using (SolidBrush fb = new SolidBrush(fc)) g.FillRectangle(fb, new Rectangle(track.X, track.Y, fw, track.Height));
            }
        }
    }

    internal static class Fmt
    {
        public static string Bytes(long bytes)
        {
            if (bytes < 0) bytes = 0;
            double mb = bytes / 1024.0 / 1024.0;
            if (mb < 1024) return mb.ToString("0.0", CultureInfo.CurrentCulture) + " MB";
            return (mb / 1024.0).ToString("0.00", CultureInfo.CurrentCulture) + " GB";
        }

        public static string Gb(long bytes)
        {
            return (bytes / 1073741824.0).ToString("0.0", CultureInfo.CurrentCulture);
        }
    }

    internal static class Dialogs
    {
        // Dialogo de confirmacion con lista exacta de lo que se va a hacer.
        public static bool Confirm(IWin32Window owner, string title, string intro, IList<string> lines, string footer, string okText)
        {
            Theme t = AppSettings.Current;
            using (Form f = new Form())
            {
                f.Text = title;
                f.StartPosition = FormStartPosition.CenterParent;
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(620, 440);
                f.BackColor = t.Card;
                f.ForeColor = t.Fg;
                f.Font = new Font("Segoe UI", 10f);

                Label il = new Label();
                il.AutoSize = false;
                il.Text = intro;
                il.SetBounds(16, 14, 588, 20);
                il.Height = Skin.FitHeight(il, 588);
                il.ForeColor = t.Fg;

                TextBox box = new TextBox();
                box.Multiline = true;
                box.ReadOnly = true;
                box.ScrollBars = ScrollBars.Vertical;
                box.BorderStyle = BorderStyle.FixedSingle;
                box.BackColor = t.Bg;
                box.ForeColor = t.Fg;
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < lines.Count; i++) sb.Append(lines[i]).Append("\r\n");
                box.Text = sb.ToString();
                int top = il.Bottom + 8;

                Label fl = new Label();
                fl.AutoSize = false;
                fl.Text = footer;
                fl.ForeColor = t.Muted;
                int fh = Skin.FitHeight(fl, 588);
                fl.SetBounds(16, 440 - 64 - fh - 8, 588, fh);
                box.SetBounds(16, top, 588, fl.Top - top - 8);
                box.Select(0, 0);

                Button ok = Ui.MakeButton(okText, true);
                ok.SetBounds(604 - 190, 440 - 52, 190, 38);
                ok.DialogResult = DialogResult.OK;
                Button cancel = Ui.MakeButton("Cancelar", false);
                cancel.SetBounds(604 - 190 - 130, 440 - 52, 120, 38);
                cancel.DialogResult = DialogResult.Cancel;

                f.Controls.Add(il);
                f.Controls.Add(box);
                f.Controls.Add(fl);
                f.Controls.Add(ok);
                f.Controls.Add(cancel);
                f.AcceptButton = cancel;
                f.CancelButton = cancel;
                return f.ShowDialog(owner) == DialogResult.OK;
            }
        }
    }

    // Ejecuta trabajo en segundo plano y entrega el resultado en el hilo de la interfaz.
    internal static class Bg
    {
        public static void Run<T>(Control host, Func<T> work, Action<T> done)
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                T result = default(T);
                Exception error = null;
                try { result = work(); }
                catch (Exception ex) { error = ex; }
                if (error != null)
                {
                    OpLog.Add("Error interno", "Tarea en segundo plano", OpResult.Failed, error.GetType().Name + ": " + error.Message, "", "");
                }
                try
                {
                    if (host.IsDisposed || !host.IsHandleCreated) return;
                    host.BeginInvoke(new MethodInvoker(delegate
                    {
                        if (error != null)
                        {
                            MessageBox.Show(host.FindForm(), "Se produjo un error inesperado: " + error.Message + "\n\nQueda anotado en el historial.",
                                "WinBoost", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            done(default(T));
                        }
                        else done(result);
                    }));
                }
                catch
                {
                }
            });
        }

        public static void Post(Control host, MethodInvoker action)
        {
            try
            {
                if (host.IsDisposed || !host.IsHandleCreated) return;
                host.BeginInvoke(action);
            }
            catch
            {
            }
        }
    }
}
