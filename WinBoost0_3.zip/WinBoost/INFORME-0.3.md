﻿# WinBoost 0.3 Gaming Mode — Informe de cambios

**Estado: versión EXPERIMENTAL. Compilada y probada en Linux (Mono); no ejecutada en Windows real.**

## 1. Qué había en la 0.2 y por qué se ha cambiado

| Comportamiento de 0.2 | Riesgo | En 0.3 |
|---|---|---|
| «Optimizar ahora» cerraba con `Kill()` todo proceso que no fuera crítico (incluidos programas del usuario, con trabajo sin guardar) | Pérdida de datos, cierre de herramientas útiles | **Eliminado.** El modo juego no cierra nada. Existe una pantalla *Aplicaciones* opcional: nombre exacto, confirmación expresa y cierre normal (`CloseMainWindow`), nunca forzado |
| Manifiesto `requireAdministrator` | Toda la app con privilegios máximos | `asInvoker`. La elevación (UAC) solo se pide para cambiar la prioridad de **un** proceso concreto, a petición del usuario |
| Plan «Alto rendimiento» activado por defecto, sin guardar el anterior | Más consumo/calor, sin vuelta atrás | Opcional, desmarcado, solo si el equipo ya tiene ese plan y no va con batería; se guarda el anterior y se restaura |
| Prioridad **Alta** a los juegos, activada por defecto | Puede restar CPU a audio/red | Opcional, desmarcada, por juego marcado, nivel «Por encima de lo normal»; no se aplica con antitrampas activos; se restaura |
| `EmptyWorkingSet` presentado como «RAM liberada» | La RAM vuelve en segundos; puede empeorar el rendimiento | **Eliminado** |
| Texto «~X MB de RAM liberada» | Cifra engañosa | Eliminado |
| Acceso directo creado en silencio al primer inicio | Cambio no solicitado | Se pregunta una sola vez |
| Casillas «Mantener Discord / Explorador» | Existían porque se cerraba todo | Eliminadas (ya no hay cierre automático; el Explorador está protegido) |
| Sin registro ni restauración | — | Registro local + restauración |

## 2. Qué se ha conservado
Nombre e identidad visual, los 5 temas, fondo pintado, **Mis botones**, **Paint**, **Juegitos** (Studio.cs sin cambios de contenido), acceso directo, clasificador de procesos (ampliado con antitrampas), icono, `build.bat`/`Iniciar.bat` (ampliados). Los datos de 0.2 (tema, botones, fondo) se reutilizan: misma carpeta `%APPDATA%\WinBoost`.

## 3. Funciones realmente implementadas

- **Modo juego**: análisis, vista previa de cambios, confirmación, activación, resultado por operación (completada / omitida / fallida / pendiente de permisos), anti-duplicado, desactivación y restauración. Aviso al salir con el modo activo.
- **Optimizaciones**: plan de energía (powercfg, sin registro), prioridad de juegos (API de Windows), reintento con UAC para un proceso.
- **Monitor**: CPU, RAM total/usada/disponible, nombre y controlador de GPU (WMI), carga 3D de GPU (contadores «GPU Engine»), temperatura/uso/VRAM solo vía `nvidia-smi` si existe, procesos por CPU/RAM, estado del modo juego, lista de lecturas con error. Actualización en un hilo aparte cada 2 s, en pausa si la ventana está minimizada. Todo lo no medible muestra «No disponible» con el motivo. **No hay temperatura de CPU** (no existe fuente fiable sin controladores externos) y no se inventa ninguna.
- **Rendimiento**: importar CSV de PresentMon/CapFrameX o lista de ms; FPS medios, 1 % low, tiempos de fotograma (medio, P99, máximo), duración, juego, resolución (por defecto la del escritorio, editable) y ajustes (a mano); comparación antes/después con gráfica y avisos de validez; muestra de CPU/RAM de 30 s medida de forma nativa; guía paso a paso.
- **Historial/Restauración**: registro `registro.tsv` (fecha, operación, solicitado, resultado, motivo, anterior, nuevo; rotación a 1 MB), exportación, restauración individual o total.
- **Aplicaciones**: cierre opcional con confirmación (ver arriba).

**Lo que WinBoost NO hace** (y no afirma): medir FPS por sí mismo, subir FPS, cerrar procesos solos, tocar registro/servicios/antivirus/actualizaciones/antitrampas, overclock/voltajes.

## 4. Pruebas realizadas

**Ejecutadas (Linux + Mono 6.8):**
- Compilación de todo el proyecto con `mcs -langversion:5` (sin avisos), es decir, sin sintaxis posterior a C# 5, que es la que entiende el `csc` incluido en Windows.
- 53 pruebas automáticas de lógica (todas correctas): estadísticas de fotogramas (con valores calculados a mano), importación (PresentMon con varias aplicaciones, `;` y coma decimal, lista simple, errores), comparación (mejor/peor/ruido, avisos), almacén de mediciones, lectura de salidas de `powercfg` (inglés/español) y `nvidia-smi` (incluido `[N/A]`), agregado de contadores GPU, registro y cambios con escritura real en disco, anti-duplicado, «ninguna optimización marcada por defecto», restauración que no pierde el cambio si falla, y rutas sin Windows que devuelven «No disponible» sin excepciones.
- Comprobaciones estáticas: un único `.Kill()` (en `ProcRunner`, solo para detener su propia herramienta auxiliar `powercfg`/`nvidia-smi` si no responde); sin acceso al registro; sin `EmptyWorkingSet`; el cierre de aplicaciones solo existe tras el diálogo de confirmación; manifiesto `asInvoker`.
- Prueba de interfaz con la ventana real bajo Xvfb: recorre las 7 pantallas nuevas/modificadas, con capturas revisadas. Se detectaron y corrigieron 3 errores de maquetación.

**No ejecutadas (requieren Windows real):**
- Compilación con el `csc.exe` de Microsoft y arranque de `WinBoost.exe` con el manifiesto.
- `powercfg /setactive` y su verificación (solo probé el análisis de texto con ejemplos, no la ejecución).
- `SetPriorityClass`, lectura de prioridad/hora de inicio, y el proceso auxiliar con UAC (`runas`).
- Contadores de CPU y «GPU Engine» (el cálculo de `CounterSample` en GPU es lo más incierto), WMI, `nvidia-smi` real, detección de batería.
- Detección de juegos (heurística heredada de 0.2) y comportamiento con antitrampas reales.
- Apariencia real en Windows (mis capturas son de Mono/GTK), DPI altos, tema Claro.
- Creación de accesos directos y `Desinstalar.bat`.
- Que el ejecutable se compile limpio con `build.bat`.

## 4b. Limitaciones conocidas
- Con el modo activo, un juego abierto después no recibe prioridad (hay que desactivar y reactivar).
- El plan de energía solo se ofrece si Windows ya lo expone; muchos equipos modernos no lo muestran y entonces aparece «No disponible».
- La carga de GPU por contadores puede no estar disponible en algunos equipos; sin NVIDIA no hay temperatura.
- No se detectan los ajustes gráficos ni la resolución interna del juego.
- Soportado: Windows 10 (1809 o posterior) y Windows 11. En versiones anteriores algunas métricas saldrán «No disponible».
- Se distribuye sin ejecutable: se compila en el primer inicio. El `.exe` de 0.2 se ha retirado a propósito (pedía administrador y cerraba procesos).

## 5. Veredicto técnico
**Versión experimental (beta), no lista para uso general todavía.** El diseño es más seguro que el de 0.2 y la lógica comprobable está probada, pero ninguna de las funciones que tocan Windows se ha ejecutado en un equipo real. Antes de recomendarla hace falta, como mínimo, la «Primera comprobación en tu PC» del LEEME en un ordenador de pruebas. Probar con un juego sin antitrampas la primera vez. No hay pruebas de que mejore los FPS: por diseño, WinBoost solo ofrece medirlo.
