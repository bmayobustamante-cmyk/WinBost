﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace WinBoost
{
    // Tarjeta de una optimización: casilla, estado, descripción y riesgos. Se maquetea a mano para adaptarse al ancho.
    internal sealed class OptionCard : Panel
    {
        public CheckBox Check = new CheckBox();
        public Label Status;
        public Label Desc;
        public Label Risk;
        public List<CheckBox> Extras = new List<CheckBox>();

        public OptionCard(string title)
        {
            Tag = "card";
            Ui.EnableDoubleBuffer(this);
            Check.Text = title;
            Check.AutoSize = false;
            Check.Font = new Font("Segoe UI Semibold", 11f);
            Status = Skin.Lbl("", 9.5f, false, "muted");
            Desc = Skin.Lbl("", 9.5f, false, "");
            Risk = Skin.Lbl("", 9f, false, "muted");
            Controls.Add(Check);
            Controls.Add(Status);
            Controls.Add(Desc);
            Controls.Add(Risk);
        }

        public void SetExtras(List<CheckBox> boxes)
        {
            for (int i = 0; i < Extras.Count; i++)
            {
                Controls.Remove(Extras[i]);
                Extras[i].Dispose();
            }
            Extras = boxes;
            for (int i = 0; i < Extras.Count; i++) Controls.Add(Extras[i]);
        }

        public void Relayout(int width)
        {
            Width = width;
            int w = Math.Max(120, width - 28);
            int y = 10;
            Check.SetBounds(12, y, w, 28);
            y += 30;
            y = Skin.Place(Status, 14, y, w - 2);
            y = Skin.Place(Desc, 14, y, w - 2);
            y = Skin.Place(Risk, 14, y, w - 2);
            for (int i = 0; i < Extras.Count; i++)
            {
                Extras[i].SetBounds(30, y, Math.Max(100, w - 20), 24);
                y += 26;
            }
            Height = y + 8;
        }
    }

    internal sealed class GamingPanel : Panel
    {
        private Panel header;
        private Label title;
        private Label subtitle;
        private Label statePill;
        private Panel cards;
        private MeterCard cpuCard;
        private MeterCard ramCard;
        private MeterCard gpuCard;
        private MeterCard modeCard;
        private Panel bottom;
        private Button analyzeBtn;
        private Button elevBtn;
        private Button activateBtn;
        private Label busyLabel;
        private Panel body;
        private Panel left;
        private Panel right;
        private OptionCard powerCard;
        private OptionCard prioCard;
        private Label previewTitle;
        private TextBox previewBox;
        private Label resultsTitle;
        private ListView results;

        private Analysis analysis;
        private bool busy;
        private bool suppress;
        private List<PendingElevation> pending = new List<PendingElevation>();

        public GamingPanel()
        {
            Ui.EnableDoubleBuffer(this);
            Build();
            ChangeStore.Changed += delegate { Bg.Post(this, new MethodInvoker(RefreshState)); };
        }

        private void Build()
        {
            body = new Panel();
            body.Dock = DockStyle.Fill;
            left = new Panel();
            left.AutoScroll = true;
            right = new Panel();
            body.Controls.Add(left);
            body.Controls.Add(right);

            powerCard = new OptionCard("Plan de energía de alto rendimiento");
            prioCard = new OptionCard("Prioridad de los juegos detectados (opcional)");
            left.Controls.Add(powerCard);
            left.Controls.Add(prioCard);
            powerCard.Check.CheckedChanged += delegate { UpdatePreview(); };
            prioCard.Check.CheckedChanged += delegate
            {
                if (suppress) return;
                suppress = true;
                for (int i = 0; i < prioCard.Extras.Count; i++)
                    if (prioCard.Extras[i].Enabled) prioCard.Extras[i].Checked = prioCard.Check.Checked;
                suppress = false;
                UpdatePreview();
            };

            previewTitle = Skin.Lbl("Qué se aplicará", 11f, true, "");
            previewBox = new TextBox();
            previewBox.Multiline = true;
            previewBox.ReadOnly = true;
            previewBox.ScrollBars = ScrollBars.Vertical;
            previewBox.BorderStyle = BorderStyle.None;
            resultsTitle = Skin.Lbl("Resultado de cada operación", 11f, true, "");
            results = Skin.NewList();
            results.Columns.Add("Resultado", 120);
            results.Columns.Add("Operación", 120);
            results.Columns.Add("Cambio solicitado", 190);
            results.Columns.Add("Detalle", 140);
            right.Controls.Add(previewTitle);
            right.Controls.Add(previewBox);
            right.Controls.Add(resultsTitle);
            right.Controls.Add(results);

            bottom = new Panel();
            bottom.Dock = DockStyle.Bottom;
            bottom.Height = 64;
            bottom.Tag = "card";
            analyzeBtn = Skin.Btn("Analizar equipo", false);
            analyzeBtn.Size = new Size(160, 40);
            elevBtn = Skin.Btn("Reintentar con administrador…", false);
            elevBtn.Size = new Size(230, 40);
            elevBtn.Visible = false;
            activateBtn = Skin.Btn("Activar modo juego", true);
            activateBtn.Size = new Size(220, 40);
            busyLabel = Skin.Lbl("", 9.5f, false, "muted");
            bottom.Controls.Add(analyzeBtn);
            bottom.Controls.Add(elevBtn);
            bottom.Controls.Add(activateBtn);
            bottom.Controls.Add(busyLabel);
            bottom.Resize += delegate { LayoutBottom(); };
            analyzeBtn.Click += delegate { RunAnalysis(); };
            activateBtn.Click += delegate { OnActivateClick(); };
            elevBtn.Click += delegate { OnElevClick(); };

            cards = new Panel();
            cards.Dock = DockStyle.Top;
            cards.Height = 134;
            cpuCard = new MeterCard("CPU");
            ramCard = new MeterCard("Memoria RAM");
            gpuCard = new MeterCard("GPU");
            modeCard = new MeterCard("Modo juego");
            cards.Controls.Add(cpuCard);
            cards.Controls.Add(ramCard);
            cards.Controls.Add(gpuCard);
            cards.Controls.Add(modeCard);
            cards.Resize += delegate { LayoutCards(); };

            header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 78;
            header.Tag = "card";
            title = Skin.Lbl("Modo juego", 20f, true, "");
            title.SetBounds(20, 10, 400, 36);
            subtitle = Skin.Lbl("Prepara el equipo para jugar con cambios medibles y reversibles. No cierra programas ni toca servicios, registro o antivirus.", 9.5f, false, "muted");
            subtitle.SetBounds(22, 48, 600, 22);
            statePill = Skin.Lbl("", 11f, true, "muted");
            statePill.TextAlign = ContentAlignment.MiddleRight;
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Controls.Add(statePill);
            header.Resize += delegate
            {
                statePill.SetBounds(Math.Max(300, header.Width - 340), 16, 320, 28);
                subtitle.Width = Math.Max(300, header.Width - 40);
            };

            Controls.Add(body);
            Controls.Add(bottom);
            Controls.Add(cards);
            Controls.Add(header);

            body.Resize += delegate { LayoutBody(); };
            left.Resize += delegate { LayoutOptions(); };
            right.Resize += delegate { LayoutRight(); };

            powerCard.Status.Text = "Pulsa «Analizar equipo» para comprobar si está disponible.";
            prioCard.Status.Text = "Pulsa «Analizar equipo» para comprobar si está disponible.";
            powerCard.Check.Enabled = false;
            prioCard.Check.Enabled = false;
            LayoutCards();
            LayoutBottom();
            RefreshState();
            ApplyTheme();
        }

        // ---------- Maquetación ----------

        private void LayoutCards()
        {
            int gap = 12;
            int w = Math.Max(120, (cards.ClientSize.Width - 24 - gap * 3) / 4);
            int h = cards.ClientSize.Height - 16;
            cpuCard.SetBounds(12, 8, w, h);
            ramCard.SetBounds(12 + (w + gap), 8, w, h);
            gpuCard.SetBounds(12 + (w + gap) * 2, 8, w, h);
            modeCard.SetBounds(12 + (w + gap) * 3, 8, w, h);
        }

        private void LayoutBottom()
        {
            int w = bottom.ClientSize.Width;
            analyzeBtn.Location = new Point(16, 12);
            activateBtn.Location = new Point(Math.Max(200, w - 236), 12);
            elevBtn.Location = new Point(Math.Max(190, w - 236 - 244), 12);
            busyLabel.SetBounds(190, 22, Math.Max(40, elevBtn.Left - 200), 22);
        }

        private void LayoutBody()
        {
            int w = body.ClientSize.Width;
            int h = body.ClientSize.Height;
            int lw = (int)(w * 0.55);
            left.SetBounds(0, 0, lw, h);
            right.SetBounds(lw, 0, w - lw, h);
        }

        private void LayoutOptions()
        {
            int sb = left.VerticalScroll.Visible ? SystemInformation.VerticalScrollBarWidth : 0;
            int w = Math.Max(240, left.ClientSize.Width - 24 - sb);
            int y = 10;
            OptionCard[] cs = new OptionCard[] { powerCard, prioCard };
            for (int i = 0; i < cs.Length; i++)
            {
                cs[i].Left = 12;
                cs[i].Top = y;
                cs[i].Relayout(w);
                y += cs[i].Height + 10;
            }
        }

        private void LayoutRight()
        {
            int w = right.ClientSize.Width - 24;
            int h = right.ClientSize.Height;
            previewTitle.SetBounds(12, 10, w, 24);
            int ph = Math.Max(90, (int)(h * 0.38));
            previewBox.SetBounds(12, 38, w, ph);
            resultsTitle.SetBounds(12, 38 + ph + 12, w, 24);
            int top = resultsTitle.Bottom + 4;
            results.SetBounds(12, top, w, Math.Max(60, h - top - 10));
            int used = results.Columns[0].Width + results.Columns[1].Width + results.Columns[2].Width;
            results.Columns[3].Width = Math.Max(120, w - used - 4);
        }

        public void ApplyTheme()
        {
            Theme t = AppSettings.Current;
            Skin.Apply(this);
            BackColor = t.Bg;
            previewBox.BackColor = t.Card;
            previewBox.ForeColor = t.Fg;
            RefreshState();
            LayoutOptions();
            LayoutRight();
        }

        // ---------- Datos en vivo ----------

        public void OnMetrics(Metrics m)
        {
            if (m == null) return;
            if (m.Cpu >= 0)
                cpuCard.SetValues(m.Cpu.ToString("0", CultureInfo.CurrentCulture) + " %",
                    (m.CpuName ?? "") + (m.LogicalCores > 0 ? "  ·  " + m.LogicalCores + " hilos" : ""), m.Cpu, "");
            else
                cpuCard.SetValues("No disponible", FirstError(m, "CPU") ?? "Sin lectura de CPU.", -1, "muted");

            if (m.RamTotal > 0)
            {
                long avail = m.RamTotal - m.RamUsed;
                ramCard.SetValues(Fmt.Gb(m.RamUsed) + " / " + Fmt.Gb(m.RamTotal) + " GB",
                    m.RamLoad + " % en uso  ·  " + Fmt.Gb(avail) + " GB disponibles", m.RamLoad, "");
            }
            else ramCard.SetValues("No disponible", FirstError(m, "RAM") ?? "Sin lectura de RAM.", -1, "muted");

            if (m.Gpus.Count == 0)
            {
                gpuCard.SetValues("No disponible", "No se detectó la GPU. Depende del hardware y de los datos que ofrezca Windows.", -1, "muted");
            }
            else
            {
                string name = m.Gpus[0].Name + (m.Gpus.Count > 1 ? "  (+" + (m.Gpus.Count - 1) + ")" : "");
                string temp = "";
                double load = m.GpuLoad3d;
                for (int i = 0; i < m.Nvidia.Count; i++)
                {
                    if (m.Nvidia[i].TempC >= 0) { temp = "  ·  " + m.Nvidia[i].TempC.ToString("0", CultureInfo.CurrentCulture) + " °C"; break; }
                }
                if (load < 0)
                {
                    for (int i = 0; i < m.Nvidia.Count; i++) if (m.Nvidia[i].UtilPct >= 0) { load = m.Nvidia[i].UtilPct; break; }
                }
                if (load >= 0) gpuCard.SetValues(load.ToString("0", CultureInfo.CurrentCulture) + " %", name + temp, load, "");
                else gpuCard.SetValues("Detectada", name + "  ·  carga no disponible", -1, "");
            }
        }

        private static string FirstError(Metrics m, string prefix)
        {
            for (int i = 0; i < m.Errors.Count; i++)
                if (m.Errors[i].StartsWith(prefix, StringComparison.Ordinal)) return m.Errors[i];
            if (m.Errors.Count > 0 && !Platform.IsWindows) return m.Errors[0];
            return null;
        }

        // ---------- Estado ----------

        private bool HasRecord(string kind)
        {
            List<ChangeRecord> all = ChangeStore.All();
            for (int i = 0; i < all.Count; i++) if (all[i].Kind == kind) return true;
            return false;
        }

        public void RefreshState()
        {
            bool active = GameModeService.IsActive;
            int n = ChangeStore.Count;
            activateBtn.Text = active ? "Desactivar y restaurar" : "Activar modo juego";
            activateBtn.Tag = active ? "" : "primary";
            Theme t = AppSettings.Current;
            activateBtn.BackColor = active ? Color.FromArgb(70, t.Fg) : t.Accent;
            activateBtn.ForeColor = active ? t.Fg : Ui.Contrast(t.Accent);
            statePill.Text = active ? "● ACTIVO · " + n + (n == 1 ? " cambio aplicado" : " cambios aplicados") : "○ Inactivo";
            statePill.ForeColor = active ? Skin.ToneColor("ok") : t.Muted;
            modeCard.SetValues(active ? "Activo" : "Inactivo",
                active ? n + (n == 1 ? " cambio aplicado y restaurable" : " cambios aplicados y restaurables") : "No hay cambios de WinBoost aplicados",
                -1, active ? "ok" : "");
            if (analysis != null) ShowAnalysis();
            UpdatePreview();
        }

        private void SetBusy(bool on, string text)
        {
            busy = on;
            analyzeBtn.Enabled = !on;
            activateBtn.Enabled = !on;
            elevBtn.Enabled = !on;
            busyLabel.Text = on ? text : "";
            Cursor = on ? Cursors.WaitCursor : Cursors.Default;
        }

        // ---------- Análisis ----------

        public void RunAnalysis()
        {
            if (busy) return;
            SetBusy(true, "Analizando el equipo…");
            Bg.Run<Analysis>(this, delegate { return GameModeService.Analyze(); }, delegate(Analysis a)
            {
                SetBusy(false, "");
                if (a == null) return;
                analysis = a;
                ShowAnalysis();
            });
        }

        private void ShowAnalysis()
        {
            if (analysis == null) return;
            bool active = GameModeService.IsActive;
            suppress = true;

            Optimization p = analysis.Power;
            powerCard.Desc.Text = p.Description;
            powerCard.Risk.Text = "Riesgos: " + p.Risk;
            if (active && HasRecord("power"))
            {
                powerCard.Status.Text = "Aplicada por WinBoost. Se restaura al desactivar el modo juego.";
                powerCard.Status.Tag = "ok";
                powerCard.Check.Enabled = false;
                powerCard.Check.Checked = true;
            }
            else
            {
                powerCard.Status.Text = p.StatusText;
                powerCard.Status.Tag = p.Available ? "ok" : "muted";
                bool can = p.Available && !active;
                if (!can) powerCard.Check.Checked = false;
                powerCard.Check.Enabled = can;
            }

            Optimization o = analysis.Priority;
            prioCard.Desc.Text = o.Description;
            prioCard.Risk.Text = "Riesgos: " + o.Risk;
            bool prioApplied = active && HasRecord("priority");
            prioCard.Status.Text = prioApplied ? "Aplicada por WinBoost a los juegos marcados. Se restaura al desactivar el modo juego." : o.StatusText;
            prioCard.Status.Tag = prioApplied || o.Available ? "ok" : "muted";
            prioCard.Check.Enabled = o.Available && !active;
            if (!prioCard.Check.Enabled) prioCard.Check.Checked = false;

            List<int> previousPids = new List<int>();
            for (int i = 0; i < prioCard.Extras.Count; i++)
            {
                GameCandidate old = prioCard.Extras[i].Tag as GameCandidate;
                if (old != null && prioCard.Extras[i].Checked) previousPids.Add(old.Pid);
            }
            List<CheckBox> boxes = new List<CheckBox>();
            for (int i = 0; i < analysis.Games.Count; i++)
            {
                GameCandidate g = analysis.Games[i];
                CheckBox cb = new CheckBox();
                cb.AutoSize = false;
                cb.Tag = g;
                cb.Text = g.Name + "  (PID " + g.Pid + ")  —  " +
                    (g.Selectable ? "prioridad actual: " + PriorityService.Pretty(g.CurrentPriority) : "no se modifica: " + g.Reason);
                cb.Enabled = g.Selectable && o.Available && !active;
                cb.Checked = cb.Enabled && previousPids.Contains(g.Pid);
                cb.CheckedChanged += delegate { if (!suppress) UpdatePreview(); };
                boxes.Add(cb);
            }
            prioCard.SetExtras(boxes);
            suppress = false;
            Skin.Apply(left);
            LayoutOptions();
            UpdatePreview();
        }

        private List<string> PreviewLines(out bool anything)
        {
            List<string> l = new List<string>();
            anything = false;
            if (GameModeService.IsActive)
            {
                l.Add("El modo juego está ACTIVO. Cambios aplicados por WinBoost:");
                List<ChangeRecord> all = ChangeStore.All();
                for (int i = 0; i < all.Count; i++) l.Add("• " + all[i].Label);
                l.Add("");
                l.Add("«Desactivar y restaurar» los devolverá a su valor anterior cuando Windows lo permita.");
                return l;
            }
            if (analysis == null)
            {
                l.Add("Pulsa «Analizar equipo» para ver qué optimizaciones están disponibles en este ordenador.");
                return l;
            }
            if (powerCard.Check.Checked && analysis.Power.Available)
            {
                l.Add("• Plan de energía: «" + analysis.Power.CurrentName + "» → «" + analysis.Power.TargetName + "». Se restaurará al desactivar.");
                anything = true;
            }
            for (int i = 0; i < prioCard.Extras.Count; i++)
            {
                CheckBox cb = prioCard.Extras[i];
                GameCandidate g = cb.Tag as GameCandidate;
                if (g != null && cb.Checked && cb.Enabled)
                {
                    l.Add("• Prioridad de «" + g.Name + "» (PID " + g.Pid + "): Normal → " + PriorityService.Pretty(GameModeService.PriorityTarget) + ". Se restaurará al desactivar.");
                    anything = true;
                }
            }
            if (!anything)
            {
                l.Add("No hay ninguna optimización seleccionada.");
                l.Add("Marca las que quieras aplicar. Ninguna viene activada por defecto.");
            }
            else
            {
                l.Add("");
                l.Add("No se cerrará ningún programa ni proceso. No se modificarán servicios, registro, antivirus, actualizaciones ni antitrampas.");
            }
            return l;
        }

        private void UpdatePreview()
        {
            bool any;
            List<string> l = PreviewLines(out any);
            previewBox.Text = string.Join("\r\n", l.ToArray());
            previewBox.Select(0, 0);
        }

        // ---------- Acciones ----------

        private void OnActivateClick()
        {
            if (busy) return;
            if (GameModeService.IsActive) Deactivate();
            else Activate();
        }

        private void Activate()
        {
            if (analysis == null)
            {
                MessageBox.Show(FindForm(), "Primero pulsa «Analizar equipo» para ver qué optimizaciones están disponibles.", "WinBoost");
                return;
            }
            bool any;
            List<string> lines = PreviewLines(out any);
            if (!any)
            {
                MessageBox.Show(FindForm(), "No hay ninguna optimización seleccionada. Marca al menos una (ninguna viene activada por defecto).", "WinBoost");
                return;
            }
            if (!Dialogs.Confirm(FindForm(), "Activar modo juego", "Se aplicarán exactamente estos cambios:", lines,
                "Cada cambio queda anotado en el historial y se puede restaurar. WinBoost no cierra ninguna aplicación.", "Aplicar cambios")) return;

            bool wantPower = powerCard.Check.Checked && analysis.Power.Available;
            List<GameCandidate> games = new List<GameCandidate>();
            for (int i = 0; i < prioCard.Extras.Count; i++)
            {
                GameCandidate g = prioCard.Extras[i].Tag as GameCandidate;
                if (g != null && prioCard.Extras[i].Checked && prioCard.Extras[i].Enabled) games.Add(g);
            }
            Optimization power = analysis.Power;
            List<PendingElevation> pend = new List<PendingElevation>();
            SetBusy(true, "Aplicando cambios…");
            Bg.Run<List<OpEntry>>(this, delegate { return GameModeService.Activate(power, wantPower, games, pend); }, delegate(List<OpEntry> res)
            {
                SetBusy(false, "");
                pending = pend;
                ShowResults(res);
                RefreshState();
            });
        }

        private void Deactivate()
        {
            List<ChangeRecord> all = ChangeStore.All();
            List<string> lines = new List<string>();
            for (int i = 0; i < all.Count; i++) lines.Add("• " + all[i].Label);
            if (!Dialogs.Confirm(FindForm(), "Desactivar y restaurar", "Se intentará restaurar estos cambios:", lines,
                "Si Windows o el programa afectado ya cambió el ajuste por otro medio, WinBoost no lo sobrescribirá y lo anotará como omitido.", "Restaurar")) return;
            List<PendingElevation> pend = new List<PendingElevation>();
            SetBusy(true, "Restaurando…");
            Bg.Run<List<OpEntry>>(this, delegate { return GameModeService.Deactivate(pend); }, delegate(List<OpEntry> res)
            {
                SetBusy(false, "");
                pending = pend;
                ShowResults(res);
                RefreshState();
                RunAnalysis();
            });
        }

        private void OnElevClick()
        {
            if (busy || pending.Count == 0) return;
            List<string> lines = new List<string>();
            for (int i = 0; i < pending.Count; i++)
                lines.Add("• " + pending[i].ProcName + " (PID " + pending[i].Pid + "): prioridad → " + PriorityService.Pretty(pending[i].Target));
            if (!Dialogs.Confirm(FindForm(), "Permisos de administrador", "Windows mostrará un aviso (UAC). Solo se cambiará la prioridad de:", lines,
                "WinBoost seguirá ejecutándose sin permisos de administrador; solo se eleva un proceso auxiliar para estas operaciones.", "Continuar")) return;
            List<PendingElevation> items = new List<PendingElevation>(pending);
            SetBusy(true, "Esperando permisos…");
            Bg.Run<List<OpEntry>>(this, delegate { return GameModeService.RetryElevated(items); }, delegate(List<OpEntry> res)
            {
                SetBusy(false, "");
                pending = new List<PendingElevation>();
                for (int i = 0; res != null && i < res.Count; i++)
                    if (res[i].Result == OpResult.NeedsPermission) { }
                ShowResults(res);
                RefreshState();
            });
        }

        private void ShowResults(List<OpEntry> res)
        {
            results.BeginUpdate();
            results.Items.Clear();
            if (res != null)
            {
                for (int i = 0; i < res.Count; i++)
                {
                    OpEntry e = res[i];
                    Skin.AddRow(results,
                        new string[] { OpText.Label(e.Result), e.Operation, e.Requested, e.Detail },
                        new string[] { OpText.Tone(e.Result), "", "", "muted" });
                }
            }
            results.EndUpdate();
            elevBtn.Visible = pending.Count > 0;
        }
    }
}
